<?php include "include/header/header.php"; ?>


                <?php include "include/header/navigation-2.php"; ?>


  
                <div class="nicdark_section nicdark_background_size_cover nicdark_background_position_center_bottom" style="background-image:url(img/parallax/img6.png);">

                    <div class="nicdark_section nicdark_bg_greydark_alpha_gradient_2">

                        


                        <!--start nicdark_container-->
                        <div class="nicdark_container nicdark_clearfix">


                            <div class="nicdark_section nicdark_height_200"></div>

                            <div class="grid grid_12">
                                <strong class="nicdark_color_white nicdark_font_size_60 nicdark_first_font">Checkout</strong>
                                <div class="nicdark_section nicdark_height_20"></div>
                            </div>


                        </div>
                        <!--end container-->

                    </div>

                </div>




               
                <div class="nicdark_section nicdark_bg_grey nicdark_border_bottom_1_solid_grey">

                    <!--start nicdark_container-->
                    <div class="nicdark_container nicdark_clearfix">

                        <div class="grid grid_12">


                            
                            <a href="#">Home</a>
                            <img alt="" class="nicdark_margin_left_10 nicdark_margin_right_10" width="10" src="img/icons/icon-next-grey.svg">
                            <a href="#">Courses</a>
                            <img alt="" class="nicdark_margin_left_10 nicdark_margin_right_10" width="10" src="img/icons/icon-next-grey.svg">
                            <a href="#">Checkout</a>
                            


                        </div>

                
                    </div>
                    <!--end container-->

                </div>




                <div class="nicdark_section nicdark_height_50"></div>



                    
                <div class="nicdark_section ">

                    <!--start nicdark_container-->
                    <div class="nicdark_container nicdark_clearfix">

                        <div class="grid grid_8">


                            <!--START main details-->
                            <div class="nicdark_section nicdark_box_sizing_border_box">
                                <h2><strong>Main Details :</strong></h2>
                                <div class="nicdark_section nicdark_height_20"></div>
                            </div>


                            <div class="nicdark_section nicdark_box_sizing_border_box">
                                <div class="nicdark_section">
                                
                                    <div class="nicdark_section">
                                        <div class="nicdark_width_100_percentage nicdark_box_sizing_border_box nicdark_float_left nicdark_position_relative">
                                            <input class=" nicdark_border_width_2 nicdark_background_none nicdark_border_top_width_0 nicdark_border_right_width_0 nicdark_border_left_width_0" type="text" placeholder="Email">
                                        </div>
                                        <div class="nicdark_section nicdark_height_20"></div>
                                        <div class="nicdark_width_100_percentage nicdark_box_sizing_border_box nicdark_float_left nicdark_position_relative">
                                            <input class=" nicdark_border_width_2 nicdark_background_none nicdark_border_top_width_0 nicdark_border_right_width_0 nicdark_border_left_width_0" type="text" placeholder="First Name">
                                        </div>
                                        <div class="nicdark_section nicdark_height_20"></div>
                                        <div class="nicdark_width_100_percentage nicdark_box_sizing_border_box nicdark_float_left nicdark_position_relative">
                                            <input class=" nicdark_border_width_2 nicdark_background_none nicdark_border_top_width_0 nicdark_border_right_width_0 nicdark_border_left_width_0" type="text" placeholder="Last Name">
                                        </div>
                                    </div>

                                </div>

                            </div>
                            <!--END main details-->


                            <div class="nicdark_section nicdark_height_50"></div>


                            <!--START main details-->
                            <div class="nicdark_section nicdark_box_sizing_border_box">
                                <h2><strong>Other Details :</strong></h2>
                                <div class="nicdark_section nicdark_height_20"></div>
                            </div>


                            <div class="nicdark_section nicdark_box_sizing_border_box">
                                <div class="nicdark_section">
                                
                                    <div class="nicdark_section">
                                        <div class="nicdark_width_100_percentage nicdark_box_sizing_border_box nicdark_float_left">
                                            <input class=" nicdark_border_width_2 nicdark_background_none nicdark_border_top_width_0 nicdark_border_right_width_0 nicdark_border_left_width_0" type="text" placeholder="Country">
                                        </div>
                                        <div class="nicdark_section nicdark_height_20"></div>
                                        <div class="nicdark_width_100_percentage nicdark_box_sizing_border_box nicdark_float_left">
                                            <input class=" nicdark_border_width_2 nicdark_background_none nicdark_border_top_width_0 nicdark_border_right_width_0 nicdark_border_left_width_0" type="text" placeholder="Adress">
                                        </div>
                                        <div class="nicdark_section nicdark_height_20"></div>
                                        <div class="nicdark_width_100_percentage nicdark_box_sizing_border_box nicdark_float_left">
                                            <input class=" nicdark_border_width_2 nicdark_background_none nicdark_border_top_width_0 nicdark_border_right_width_0 nicdark_border_left_width_0" type="text" placeholder="City">
                                        </div>
                                        <div class="nicdark_section nicdark_height_20"></div>
                                        <div class="nicdark_width_100_percentage nicdark_box_sizing_border_box nicdark_float_left">
                                            <input class=" nicdark_border_width_2 nicdark_background_none nicdark_border_top_width_0 nicdark_border_right_width_0 nicdark_border_left_width_0" type="text" placeholder="ZIP Code">
                                        </div>
                                        <div class="nicdark_section nicdark_height_20"></div>
                                        <div class="nicdark_width_100_percentage nicdark_box_sizing_border_box nicdark_float_left">
                                            <textarea rows="5" class="nicdark_border_width_2 nicdark_background_none nicdark_border_top_width_0 nicdark_border_right_width_0 nicdark_border_left_width_0" placeholder="Additional Notes"></textarea>
                                        </div>


                                    </div>

                                </div>

                            </div>
                            <!--END main details-->

                            <div class="nicdark_section nicdark_height_20"></div>

                            <div class="nicdark_section">
                                <div class="nicdark_width_100_percentage nicdark_box_sizing_border_box nicdark_float_left">
                                    <a class="nicdark_display_inline_block nicdark_text_align_center nicdark_box_sizing_border_box nicdark_color_white nicdark_bg_green nicdark_first_font nicdark_padding_10_20 nicdark_border_radius_3 " href="thankyou.php">PAY NOW</a>   
                                </div>
                            </div> 




                        </div>

                        <div class="grid grid_4">

                            <div class="nicdark_section nicdark_bg_grey nicdark_border_1_solid_grey nicdark_padding_20 nicdark_box_sizing_border_box">


                                <table class="nicdark_section">
                                    <thead>
                                        <tr class="nicdark_border_bottom_2_solid_grey">
                                            <td class="nicdark_padding_20_10 nicdark_width_25_percentage">
                                                <h6 class="nicdark_text_transform_uppercase">CART</h6>    
                                            </td>
                                            <td class="nicdark_padding_20_10 nicdark_width_40_percentage">   
                                            </td>
                                            <td class="nicdark_padding_20_10 nicdark_width_35_percentage">   
                                            </td>
                                        </tr>
                                    </thead>
                                    <tbody>


                                        <tr class="nicdark_border_bottom_2_solid_grey">
                                            <td class="nicdark_padding_20_10">
                                                <img alt="" class="nicdark_section" src="img/courses/img1.png">   
                                            </td>
                                            <td class="nicdark_padding_20_10"> 
                                                <h5><strong>Learn Sushi</strong></h5>  
                                            </td>
                                            <td class="nicdark_padding_20_10 nicdark_text_align_right">  
                                                <p>( 1 ) $ 50,00</p> 
                                            </td>
                                        </tr>

                                        <tr class="nicdark_border_bottom_2_solid_grey">
                                            <td class="nicdark_padding_20_10">
                                                <img alt="" class="nicdark_section" src="img/courses/img2.png">   
                                            </td>
                                            <td class="nicdark_padding_20_10"> 
                                                <h5><strong>Maccheroni</strong></h5>  
                                            </td>
                                            <td class="nicdark_padding_20_10 nicdark_text_align_right">  
                                                <p>( 2 ) $ 30,00</p> 
                                            </td>
                                        </tr>

                                        <tr class="">
                                            <td class="nicdark_padding_20_10">
                                                <img alt="" class="nicdark_section" src="img/courses/img2.png">   
                                            </td>
                                            <td class="nicdark_padding_20_10"> 
                                                <h5><strong>Italian Pizza</strong></h5>  
                                            </td>
                                            <td class="nicdark_padding_20_10 nicdark_text_align_right">  
                                                <p>( 1 ) $ 70,00</p> 
                                            </td>
                                        </tr>

                                       
                                    </tbody>
                                </table>





                                <table class="nicdark_section">
                                    <thead>
                                        <tr class="nicdark_border_bottom_2_solid_grey">
                                            <td class="nicdark_padding_20_10 nicdark_width_25_percentage">
                                                <h6 class="nicdark_text_transform_uppercase">ORDER</h6>    
                                            </td>
                                            <td class="nicdark_padding_20_10 nicdark_width_40_percentage">   
                                            </td>
                                            <td class="nicdark_padding_20_10 nicdark_width_35_percentage">   
                                            </td>
                                        </tr>
                                    </thead>
                                    <tbody>


                            
                                        <tr class="">
                                            <td class="nicdark_padding_20_10">
                                                <p>Subtotal</p>   
                                            </td>
                                            <td class="nicdark_padding_20_10"> 
                                                  
                                            </td>
                                            <td class="nicdark_padding_20_10 nicdark_text_align_right">  
                                                <p class="nicdark_color_greydark">$ 50,00</p> 
                                            </td>
                                        </tr>
                                        <tr class="nicdark_border_bottom_2_solid_grey">
                                            <td class="nicdark_padding_20_10">
                                                <p>Method</p>   
                                            </td>
                                            <td class="nicdark_padding_20_10"> 
                                                  
                                            </td>
                                            <td class="nicdark_padding_20_10 nicdark_text_align_right">  
                                                <p class="nicdark_color_greydark">Paypal</p> 
                                            </td>
                                        </tr>
                                        <tr class="">
                                            <td class="nicdark_padding_20_10">
                                                <p>Total</p>   
                                            </td>
                                            <td class="nicdark_padding_20_10"> 
                                                  
                                            </td>
                                            <td class="nicdark_padding_20_10 nicdark_text_align_right">  
                                                <h3><strong>$ 50,00</strong></h3> 
                                            </td>
                                        </tr>

                                    </tbody>
                                </table>




                                <div class="nicdark_section">
                                        <div class="nicdark_width_100_percentage nicdark_padding_10 nicdark_box_sizing_border_box nicdark_float_left">
                                            <a class="nicdark_display_inline_block nicdark_text_align_center nicdark_box_sizing_border_box nicdark_width_100_percentage nicdark_color_white nicdark_bg_orange nicdark_first_font nicdark_padding_10_20 nicdark_border_radius_3 " href="cart.php">RETURN TO CART</a>   
                                        </div>
                                    </div> 


                            </div>
                        
                        </div>

                    </div>
                    <!--end container-->

                </div>


                <div class="nicdark_section nicdark_height_50"></div>



                <?php include "include/footer/footer-2.php"; ?>









                


            </div>
        </div>


        
        <?php include "include/footer/footer.php"; ?>