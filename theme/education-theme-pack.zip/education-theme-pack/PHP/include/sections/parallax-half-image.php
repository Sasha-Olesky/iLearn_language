<div class="nicdark_section nicdark_bg_greydark nicdark_display_table">

    <div class="nicdark_width_50_percentage nicdark_position_relative nicdark_display_none_all_iphone nicdark_bg_grey nicdark_display_table_cell nicdark_vertical_align_middle nicdark_background_size_cover nicdark_background_position_center" style="background-image:url(img/parallax/img12.png);">
        


        <div class="nicdark_bg_greydark_alpha nicdark_position_absolute nicdark_left_0 nicdark_top_0 nicdark_height_100_percentage nicdark_width_100_percentage  "></div>



    </div>

    <div class="nicdark_width_50_percentage nicdark_width_100_percentage_all_iphone nicdark_display_table_cell nicdark_vertical_align_middle nicdark_padding_100 nicdark_padding_40_all_iphone nicdark_box_sizing_border_box">

        <h1 class="nicdark_color_white nicdark_font_size_40"><strong>Find Out</strong></h1>
        <h1 class="nicdark_color_white nicdark_font_size_40"><strong><span class="nicdark_color_green">more</span> about us</strong></h1>
        <div class="nicdark_section nicdark_height_20"></div>
        <p>Phasellus enim libero, blandit vel sapien vitae, condimentum ultricies magna et. Quisque euismod orci ut et lobortis. Blandit vel sapien vitae, condimentum ultricies magna et orci ut et lobortis, Phasellus enim libero, blandit vel sapien vitae, condimentum ultricies magna et. Quisque euismod orci ut et lobortis. Blandit vel sapien vitae, condimentum ultricies magna et orci ut et lobortis.</p>
        <div class="nicdark_section nicdark_height_20"></div>
        <a href="courses.php"><img alt="" class="nicdark_padding_10 nicdark_border_radius_3 nicdark_border_1_solid_grey_2 nicdark_margin_right_20" width="30" src="img/icons/icon-fish.svg"></a>
        <a href="courses.php"><img alt="" class="nicdark_padding_10 nicdark_border_radius_3 nicdark_border_1_solid_grey_2 nicdark_margin_right_20" width="30" src="img/icons/icon-sushi.svg"></a>
        <a href="courses.php"><img alt="" class="nicdark_padding_10 nicdark_border_radius_3 nicdark_border_1_solid_grey_2 nicdark_margin_right_20" width="30" src="img/icons/icon-dessert.svg"></a>

    </div>

</div>