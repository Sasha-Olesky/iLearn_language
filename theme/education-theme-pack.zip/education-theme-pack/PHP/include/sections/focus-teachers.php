<div class="nicdark_section ">

    <div class="nicdark_container nicdark_clearfix">

    

        <div class="grid grid_5 nicdark_text_align_right nicdark_text_align_center_responsive">
            <h1 class="nicdark_font_size_40 nicdark_line_height_50 nicdark_padding_10"><strong>Hello. Our school has been present for over 20 years in the market. We make the most of all our students.</strong></h1>
        </div>

        <div class="grid grid_7 ">
            

            <div class="nicdark_width_50_percentage nicdark_width_100_percentage_all_iphone nicdark_float_left nicdark_padding_10 nicdark_box_sizing_border_box">
                <div class="nicdark_section nicdark_box_sizing_border_box">
                

                    <div class="nicdark_section nicdark_position_relative">
                            
                        <img alt="" class="nicdark_section" src="img/avatar/avatar-chef-3.png">

                        <div class="nicdark_bg_greydark_alpha_gradient_3 nicdark_position_absolute nicdark_left_0 nicdark_height_100_percentage nicdark_width_100_percentage nicdark_box_sizing_border_box">
                            
                            <div class="nicdark_position_absolute nicdark_bottom_30 nicdark_width_100_percentage nicdark_padding_botttom_0 nicdark_padding_50 nicdark_box_sizing_border_box nicdark_text_align_center">
                                <h2 class="nicdark_color_white"><strong>Jane Grey</strong></h2>
                                <div class="nicdark_section nicdark_height_10"></div>
                                
                                
                                
                                <div class="nicdark_section nicdark_height_10 nicdark_display_none_all_iphone"></div>
                                <div class="nicdark_display_inline_block">
                                    <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-twitter-white.svg">
                                    <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-pinterest-white.svg">
                                    <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-linkedin-white.svg">
                                    <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-google-white.svg">
                                    <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-instagram-white.svg">
                                </div>
                            </div>

                        </div>

                    </div>



                </div>
            </div>
            

            <div class="nicdark_width_50_percentage nicdark_width_100_percentage_all_iphone nicdark_float_left nicdark_padding_10 nicdark_box_sizing_border_box">
                <div class="nicdark_section nicdark_box_sizing_border_box">
                

                    <div class="nicdark_section nicdark_position_relative">
                            
                        <img alt="" class="nicdark_section" src="img/avatar/avatar-chef-5.png">

                        <div class="nicdark_bg_greydark_alpha_gradient_3 nicdark_position_absolute nicdark_left_0 nicdark_height_100_percentage nicdark_width_100_percentage nicdark_box_sizing_border_box">
                            
                            <div class="nicdark_position_absolute nicdark_bottom_30 nicdark_width_100_percentage nicdark_padding_botttom_0 nicdark_padding_50 nicdark_box_sizing_border_box nicdark_text_align_center">
                                <h2 class="nicdark_color_white"><strong>John Doe</strong></h2>
                                <div class="nicdark_section nicdark_height_10"></div>
                                
                                
                                
                                <div class="nicdark_section nicdark_height_10 nicdark_display_none_all_iphone"></div>
                                <div class="nicdark_display_inline_block">
                                    <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-twitter-white.svg">
                                    <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-pinterest-white.svg">
                                    <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-linkedin-white.svg">
                                    <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-google-white.svg">
                                    <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-instagram-white.svg">
                                </div>
                            </div>

                        </div>

                    </div>



                </div>
            </div>


        </div>



    </div>

            
</div>