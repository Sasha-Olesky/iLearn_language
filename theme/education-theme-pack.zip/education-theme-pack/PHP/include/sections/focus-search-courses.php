<div class="nicdark_section">


    <div class="nicdark_container nicdark_clearfix nicdark_border_top_1_solid_grey">

        

        <div class="nicdark_section nicdark_height_50"></div>


        <div class="grid grid_5">

            <div class="nicdark_section nicdark_height_10"></div>
            
            <!--form-->
            <div class="nicdark_section nicdark_bg_white nicdark_border_1_solid_grey">

              <div class="nicdark_section nicdark_padding_20 nicdark_box_sizing_border_box nicdark_bg_grey nicdark_border_bottom_1_solid_grey nicdark_text_align_center">
                <h6 class="nicdark_second_font nicdark_bg_orange nicdark_padding_5 nicdark_border_radius_3 nicdark_color_white nicdark_display_inline_block">43 COURSES</h6>
                <div class="nicdark_section nicdark_height_5"></div>
                <h1 class=""><strong>Search Now</strong></h1>
              </div>
              <div class="nicdark_section nicdark_padding_20_25 nicdark_box_sizing_border_box">
                
                
                
                
                <div class="nicdark_section">
                
                    <div class="nicdark_section">
                        <div class="nicdark_width_100_percentage nicdark_width_100_percentage_all_iphone nicdark_padding_10 nicdark_box_sizing_border_box nicdark_float_left nicdark_position_relative">
                            <img alt="" class="nicdark_position_absolute nicdark_top_0 nicdark_left_0 nicdark_margin_top_20 nicdark_margin_left_10" width="15" src="img/icons/icon-pen.svg">
                            <input class="nicdark_padding_left_25 nicdark_border_width_2 nicdark_background_none nicdark_border_top_width_0 nicdark_border_right_width_0 nicdark_border_left_width_0" type="text" placeholder="Keyword">
                        </div>
                        <div class="nicdark_width_100_percentage nicdark_width_100_percentage_all_iphone nicdark_padding_10 nicdark_box_sizing_border_box nicdark_float_left nicdark_position_relative">
                            <img alt="" class="nicdark_position_absolute nicdark_top_0 nicdark_left_0 nicdark_margin_top_20 nicdark_margin_left_10" width="15" src="img/icons/icon-list.svg">
                            <input class="nicdark_padding_left_25 nicdark_border_width_2 nicdark_background_none nicdark_border_top_width_0 nicdark_border_right_width_0 nicdark_border_left_width_0" type="text" placeholder="Food Courses">
                        </div>
                        <div class="nicdark_width_100_percentage nicdark_width_100_percentage_all_iphone nicdark_padding_10 nicdark_box_sizing_border_box nicdark_float_left nicdark_position_relative">
                            <img alt="" class="nicdark_position_absolute nicdark_top_0 nicdark_left_0 nicdark_margin_top_20 nicdark_margin_left_10" width="15" src="img/icons/icon-star.svg">
                            <input class="nicdark_padding_left_25 nicdark_border_width_2 nicdark_background_none nicdark_border_top_width_0 nicdark_border_right_width_0 nicdark_border_left_width_0" type="text" placeholder="Premium">
                        </div>
                        <div class="nicdark_width_100_percentage nicdark_width_100_percentage_all_iphone nicdark_padding_10 nicdark_box_sizing_border_box nicdark_float_left nicdark_position_relative">
                            <a class="nicdark_bg_white_hover nicdark_color_green_hover nicdark_border_2_solid_green nicdark_transition_all_08_ease nicdark_display_inline_block nicdark_text_align_center nicdark_box_sizing_border_box nicdark_width_100_percentage nicdark_color_white nicdark_bg_green nicdark_first_font nicdark_padding_10_20 nicdark_border_radius_3 " href="courses.php">SEARCH</a>   
                        </div>
                    </div>

                </div>

              </div>  

            </div>
            <!--form-->

        </div>

        

        <div class="grid grid_7 ">
            
            

            <div class="nicdark_width_50_percentage nicdark_width_100_percentage_all_iphone nicdark_float_left nicdark_padding_10 nicdark_box_sizing_border_box">
                
                <div class="nicdark_section nicdark_position_relative">
                        
                    <img alt="" class="nicdark_section" src="img/courses/vertical/img39.png">

                    <div class="nicdark_bg_greydark_alpha_4 nicdark_position_absolute nicdark_left_0 nicdark_height_100_percentage nicdark_width_100_percentage nicdark_padding_30 nicdark_box_sizing_border_box">
            

                        <a class="nicdark_position_absolute nicdark_right_20 nicdark_top_20 nicdark_display_inline_block nicdark_color_white nicdark_bg_green nicdark_first_font nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="#">USD 150</a>

                        <div class="nicdark_display_table nicdark_width_100_percentage nicdark_height_100_percentage nicdark_text_align_center">
            
                            <div class="nicdark_display_table_cell nicdark_vertical_align_middle">
                
                                <h2 class="nicdark_color_white"><a class="nicdark_color_white nicdark_first_font" href="single-course.php"><strong>Asian Courses</strong></a></h2>
                                <div class="nicdark_section nicdark_height_10"></div>
                                <div class="nicdark_section ">
                                    <img alt="" class="" width="15" src="img/icons/icon-star-full-white.svg">
                                    <img alt="" class="" width="15" src="img/icons/icon-star-full-white.svg">
                                    <img alt="" class="" width="15" src="img/icons/icon-star-full-white.svg">
                                    <img alt="" class="" width="15" src="img/icons/icon-star-full-white.svg">
                                    
                                    <img alt="" class="nicdark_margin_right_10" width="15" src="img/icons/icon-star-half-white.svg">
                                </div>

                            </div>

                        </div>


                    </div>

                </div>

            </div>



            <div class="nicdark_width_50_percentage nicdark_width_100_percentage_all_iphone nicdark_float_left nicdark_padding_10 nicdark_box_sizing_border_box">
                
                <div class="nicdark_section nicdark_position_relative">
                        
                    <img alt="" class="nicdark_section" src="img/courses/vertical/img43.png">

                    <div class="nicdark_bg_greydark_alpha_4 nicdark_position_absolute nicdark_left_0 nicdark_height_100_percentage nicdark_width_100_percentage nicdark_padding_30 nicdark_box_sizing_border_box">
            
                        <a class="nicdark_position_absolute nicdark_right_20 nicdark_top_20 nicdark_display_inline_block nicdark_color_white nicdark_bg_green nicdark_first_font nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="#">FREE COURSE</a>

                        <div class="nicdark_display_table nicdark_width_100_percentage nicdark_height_100_percentage nicdark_text_align_center">
            
                            <div class="nicdark_display_table_cell nicdark_vertical_align_middle">
                
                                <h2 class="nicdark_color_white"><a class="nicdark_color_white nicdark_first_font" href="single-course.php"><strong>Pasta Courses</strong></a></h2>
                                <div class="nicdark_section nicdark_height_10"></div>
                                
                                <div class="nicdark_section ">
                                    <img alt="" class="" width="15" src="img/icons/icon-star-full-white.svg">
                                    <img alt="" class="" width="15" src="img/icons/icon-star-full-white.svg">
                                    <img alt="" class="" width="15" src="img/icons/icon-star-full-white.svg">
                                    <img alt="" class="" width="15" src="img/icons/icon-star-full-white.svg">
                                    
                                    <img alt="" class="nicdark_margin_right_10" width="15" src="img/icons/icon-star-white.svg">
                                </div>

                            </div>

                        </div>

                    </div>

                </div>
            </div>


        </div>


    
    </div>

</div>