<div class="nicdark_section nicdark_background_size_cover nicdark_background_position_center" style="background-image:url(img/parallax/img38.png);">
    <div class="nicdark_section nicdark_bg_greydark_alpha_gradient_5">

        
        <div class="nicdark_container nicdark_clearfix">


            <div class="nicdark_section nicdark_height_80"></div>

            <div class="grid grid_7 nicdark_position_relative">
                <img alt="" class="nicdark_position_absolute" width="55" src="img/icons/icon-check-white.svg">
                <h1 class="nicdark_color_white nicdark_font_size_40 nicdark_padding_left_80 nicdark_line_height_50"><strong><span class="nicdark_border_bottom_4_solid_white">Doing the right thing,</span><br/> at the right time.</strong></h1>    
            </div>

            <div class="nicdark_section nicdark_height_40"></div>

            <div class="grid grid_2 nicdark_text_align_center">
                <h1 class="nicdark_font_size_50 nicdark_color_white"><strong>15</strong></h1>
                <div class="nicdark_section nicdark_height_20"></div>
                <p class="nicdark_color_white">TEACHERS</p>
            </div>

            <div class="grid grid_2 nicdark_text_align_center">
                <h1 class="nicdark_font_size_50 nicdark_color_white"><strong>+ 10 K</strong></h1>
                <div class="nicdark_section nicdark_height_20"></div>
                <p class="nicdark_color_white">CUSTOMERS</p>
            </div>

            <div class="grid grid_2 nicdark_text_align_center">
                <h1 class="nicdark_font_size_50 nicdark_color_white"><strong>+ 47</strong></h1>
                <div class="nicdark_section nicdark_height_20"></div>
                <p class="nicdark_color_white">COURSES</p>
            </div>

            <div class="grid grid_2 nicdark_text_align_center">
                <h1 class="nicdark_font_size_50 nicdark_color_white"><strong>10</strong></h1>
                <div class="nicdark_section nicdark_height_20"></div>
                <p class="nicdark_color_white">YEARS</p>
            </div>

            <div class="nicdark_section nicdark_height_80"></div>

    
        </div>
        

    </div>
</div>