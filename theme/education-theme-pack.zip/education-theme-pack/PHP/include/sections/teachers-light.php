<div class="nicdark_section">

                
    <!--start nicdark_container-->
    <div class="nicdark_container nicdark_clearfix">

    


        <div class="grid grid_12">

            <h1 class="nicdark_font_size_50"><strong>Our Teachers</strong></h1>
            <div class="nicdark_section nicdark_height_10"></div>
            <h3 class=" nicdark_color_grey">Best Chef In Our School</h3>
            <div class="nicdark_section nicdark_height_10"></div>

        </div>



    <div class="grid grid_6">
        
        <!--START teacher-->
        <div class="nicdark_section">
            <div class="nicdark_float_left nicdark_width_35_percentage nicdark_width_100_percentage_all_iphone">
            
                <!--START image-->
                <div class="nicdark_section nicdark_box_sizing_border_box">

                    <div class="nicdark_section nicdark_position_relative">
                            
                        <img alt="" class="nicdark_section" src="img/avatar/avatar-chef-2.png">

                        <div class="nicdark_bg_greydark_alpha_gradient nicdark_position_absolute nicdark_left_0 nicdark_height_100_percentage nicdark_width_100_percentage nicdark_box_sizing_border_box">
                            
                            <div class="nicdark_position_absolute nicdark_bottom_20 nicdark_width_100_percentage nicdark_padding_botttom_0 nicdark_box_sizing_border_box nicdark_text_align_center">
                                <div class="nicdark_display_inline_block">
                                    <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-twitter-white.svg">
                                    <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-pinterest-white.svg">
                                    <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-linkedin-white.svg">
                                    <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-google-white.svg">
                                    <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-instagram-white.svg">
                                </div>
                            </div>

                        </div>

                    </div>


                </div>
                <!--END image-->

            </div>
            <div class="nicdark_float_left nicdark_width_65_percentage nicdark_width_100_percentage_all_iphone">
            

                <div class="nicdark_section nicdark_padding_left_20 nicdark_padding_left_0_all_iphone nicdark_box_sizing_border_box">

                    <h2 class="nicdark_margin_top_20_all_iphone"><strong>John Mcallister</strong></h2>
                    <div class="nicdark_section nicdark_height_10"></div>
                    <h6 class="nicdark_text_transform_uppercase nicdark_color_grey nicdark_second_font">Food Teacher</h6>
                    <div class="nicdark_section nicdark_height_20"></div>
                    <p class="nicdark_color_grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean egestas magna at porttitor vehicula nullam augue.</p>
                    <div class="nicdark_section nicdark_height_10"></div>
                    <a class="nicdark_display_inline_block nicdark_color_grey nicdark_color_greydark_hover nicdark_bg_white_hover nicdark_transition_all_08_ease nicdark_border_1_solid_grey_2 nicdark_first_font nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="single-teacher.php">KNOW ME</a>
                </div>


            </div>
        </div>
        <!--END teacher-->

    </div>




    <div class="grid grid_6">
        
        <!--START teacher-->
        <div class="nicdark_section">
            <div class="nicdark_float_left nicdark_width_35_percentage nicdark_width_100_percentage_all_iphone">
            
                <!--START image-->
                <div class="nicdark_section nicdark_box_sizing_border_box">

                    <div class="nicdark_section nicdark_position_relative">
                            
                        <img alt="" class="nicdark_section" src="img/avatar/avatar-chef-3.png">

                        <div class="nicdark_bg_greydark_alpha_gradient nicdark_position_absolute nicdark_left_0 nicdark_height_100_percentage nicdark_width_100_percentage nicdark_box_sizing_border_box">
                            
                            <div class="nicdark_position_absolute nicdark_bottom_20 nicdark_width_100_percentage nicdark_padding_botttom_0 nicdark_box_sizing_border_box nicdark_text_align_center">
                                <div class="nicdark_display_inline_block">
                                    <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-twitter-white.svg">
                                    <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-pinterest-white.svg">
                                    <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-linkedin-white.svg">
                                    <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-google-white.svg">
                                    <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-instagram-white.svg">
                                </div>
                            </div>

                        </div>

                    </div>


                </div>
                <!--END image-->

            </div>
            <div class="nicdark_float_left nicdark_width_65_percentage nicdark_width_100_percentage_all_iphone">
            

                <div class="nicdark_section nicdark_padding_left_20 nicdark_padding_left_0_all_iphone nicdark_box_sizing_border_box">

                    <h2 class="nicdark_margin_top_20_all_iphone"><strong>Jane Doe</strong></h2>
                    <div class="nicdark_section nicdark_height_10"></div>
                    <h6 class="nicdark_text_transform_uppercase nicdark_color_grey nicdark_second_font">VEGAN TEACHER</h6>
                    <div class="nicdark_section nicdark_height_20"></div>
                    <p class="nicdark_color_grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean egestas magna at porttitor vehicula nullam augue.</p>
                    <div class="nicdark_section nicdark_height_10"></div>
                    <a class="nicdark_display_inline_block nicdark_color_grey nicdark_color_greydark_hover nicdark_bg_white_hover nicdark_transition_all_08_ease nicdark_border_1_solid_grey_2 nicdark_first_font nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="single-teacher.php">KNOW ME</a>
                </div>


            </div>
        </div>
        <!--END teacher-->

    </div>



    <div class="grid grid_6">
        
        <!--START teacher-->
        <div class="nicdark_section">
            <div class="nicdark_float_left nicdark_width_35_percentage nicdark_width_100_percentage_all_iphone">
            
                <!--START image-->
                <div class="nicdark_section nicdark_box_sizing_border_box">

                    <div class="nicdark_section nicdark_position_relative">
                            
                        <img alt="" class="nicdark_section" src="img/avatar/avatar-chef-4.png">

                        <div class="nicdark_bg_greydark_alpha_gradient nicdark_position_absolute nicdark_left_0 nicdark_height_100_percentage nicdark_width_100_percentage nicdark_box_sizing_border_box">
                            
                            <div class="nicdark_position_absolute nicdark_bottom_20 nicdark_width_100_percentage nicdark_padding_botttom_0 nicdark_box_sizing_border_box nicdark_text_align_center">
                                <div class="nicdark_display_inline_block">
                                    <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-twitter-white.svg">
                                    <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-pinterest-white.svg">
                                    <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-linkedin-white.svg">
                                    <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-google-white.svg">
                                    <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-instagram-white.svg">
                                </div>
                            </div>

                        </div>

                    </div>


                </div>
                <!--END image-->

            </div>
            <div class="nicdark_float_left nicdark_width_65_percentage nicdark_width_100_percentage_all_iphone">
            

                <div class="nicdark_section nicdark_padding_left_20 nicdark_padding_left_0_all_iphone nicdark_box_sizing_border_box">

                    <h2 class="nicdark_margin_top_20_all_iphone"><strong>Mary Mgrayan</strong></h2>
                    <div class="nicdark_section nicdark_height_10"></div>
                    <h6 class="nicdark_text_transform_uppercase nicdark_color_grey nicdark_second_font">ITALIAN EXPERT</h6>
                    <div class="nicdark_section nicdark_height_20"></div>
                    <p class="nicdark_color_grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean egestas magna at porttitor vehicula nullam augue.</p>
                    <div class="nicdark_section nicdark_height_10"></div>
                    <a class="nicdark_display_inline_block nicdark_color_grey nicdark_color_greydark_hover nicdark_bg_white_hover nicdark_transition_all_08_ease nicdark_border_1_solid_grey_2 nicdark_first_font nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="single-teacher.php">KNOW ME</a>
                </div>


            </div>
        </div>
        <!--END teacher-->

    </div>




    <div class="grid grid_6">
        
        <!--START teacher-->
        <div class="nicdark_section">
            <div class="nicdark_float_left nicdark_width_35_percentage nicdark_width_100_percentage_all_iphone">
            
                <!--START image-->
                <div class="nicdark_section nicdark_box_sizing_border_box">

                    <div class="nicdark_section nicdark_position_relative">
                            
                        <img alt="" class="nicdark_section" src="img/avatar/avatar-chef-5.png">

                        <div class="nicdark_bg_greydark_alpha_gradient nicdark_position_absolute nicdark_left_0 nicdark_height_100_percentage nicdark_width_100_percentage nicdark_box_sizing_border_box">
                            
                            <div class="nicdark_position_absolute nicdark_bottom_20 nicdark_width_100_percentage nicdark_padding_botttom_0 nicdark_box_sizing_border_box nicdark_text_align_center">
                                <div class="nicdark_display_inline_block">
                                    <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-twitter-white.svg">
                                    <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-pinterest-white.svg">
                                    <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-linkedin-white.svg">
                                    <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-google-white.svg">
                                    <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-instagram-white.svg">
                                </div>
                            </div>

                        </div>

                    </div>


                </div>
                <!--END image-->

            </div>
            <div class="nicdark_float_left nicdark_width_65_percentage nicdark_width_100_percentage_all_iphone">
            

                <div class="nicdark_section nicdark_padding_left_20 nicdark_padding_left_0_all_iphone nicdark_box_sizing_border_box">

                    <h2 class="nicdark_margin_top_20_all_iphone"><strong>Hanna Sprite</strong></h2>
                    <div class="nicdark_section nicdark_height_10"></div>
                    <h6 class="nicdark_text_transform_uppercase nicdark_color_grey nicdark_second_font">ASIAN TEACHER</h6>
                    <div class="nicdark_section nicdark_height_20"></div>
                    <p class="nicdark_color_grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean egestas magna at porttitor vehicula nullam augue.</p>
                    <div class="nicdark_section nicdark_height_10"></div>
                    <a class="nicdark_display_inline_block nicdark_color_grey nicdark_color_greydark_hover nicdark_bg_white_hover nicdark_transition_all_08_ease nicdark_border_1_solid_grey_2 nicdark_first_font nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="single-teacher.php">KNOW ME</a>
                </div>


            </div>
        </div>
        <!--END teacher-->

    </div>



</div>
<!--end container-->



</div>