<div class="nicdark_section">

    <div class="nicdark_container nicdark_clearfix">

        <div class="grid grid_3 ">
        
            <img alt="" width="50" src="img/icons/icon-award-color.svg">
            <div class="nicdark_section nicdark_height_20"></div>
            <h2><strong>National Awards</strong></h2>
            <div class="nicdark_section nicdark_height_20"></div>
            <p>Phasellus enim libero, blandit vel sapien vitae, condimentum ultricies magna et. Quisque euismod orci ut et lobortis.</p>
            <div class="nicdark_section nicdark_height_20"></div>
            <a class="nicdark_display_inline_block nicdark_color_grey nicdark_border_1_solid_grey nicdark_first_font nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="#">READ MORE</a>

        </div>

        <div class="grid grid_3 ">
        
            <img alt="" width="50" src="img/icons/icon-graduation-color.svg">
            <div class="nicdark_section nicdark_height_20"></div>
            <h2><strong>Best Teachers</strong></h2>
            <div class="nicdark_section nicdark_height_20"></div>
            <p>Phasellus enim libero, blandit vel sapien vitae, condimentum ultricies magna et. Quisque euismod orci ut et lobortis.</p>
            <div class="nicdark_section nicdark_height_20"></div>
            <a class="nicdark_display_inline_block nicdark_color_grey nicdark_border_1_solid_grey nicdark_first_font nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="#">READ MORE</a>

        </div>

        <div class="grid grid_3 ">
        
            <img alt="" width="50" src="img/icons/icon-graph-color.svg">
            <div class="nicdark_section nicdark_height_20"></div>
            <h2><strong>Many Courses</strong></h2>
            <div class="nicdark_section nicdark_height_20"></div>
            <p>Phasellus enim libero, blandit vel sapien vitae, condimentum ultricies magna et. Quisque euismod orci ut et lobortis.</p>
            <div class="nicdark_section nicdark_height_20"></div>
            <a class="nicdark_display_inline_block nicdark_color_grey nicdark_border_1_solid_grey nicdark_first_font nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="#">READ MORE</a>

        </div>

        <div class="grid grid_3 ">
        
            <img alt="" width="50" src="img/icons/icon-support-color.svg">
            <div class="nicdark_section nicdark_height_20"></div>
            <h2><strong>24 H Support</strong></h2>
            <div class="nicdark_section nicdark_height_20"></div>
            <p>Phasellus enim libero, blandit vel sapien vitae, condimentum ultricies magna et. Quisque euismod orci ut et lobortis.</p>
            <div class="nicdark_section nicdark_height_20"></div>
            <a class="nicdark_display_inline_block nicdark_color_grey nicdark_border_1_solid_grey nicdark_first_font nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="#">READ MORE</a>

        </div>



    </div>

</div>