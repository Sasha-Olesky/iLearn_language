<!--START bottom pagination-->
<div class="nicdark_section nicdark_bg_grey nicdark_border_top_1_solid_grey">

    <!--start nicdark_container-->
    <div class="nicdark_container nicdark_clearfix">
    

        <div class="grid grid_12">
            
            <div class="nicdark_width_33_percentage nicdark_float_left nicdark_text_align_left">
                <img alt="" class="" width="20" src="img/icons/icon-prev-grey.svg">
            </div>

            <div class="nicdark_width_33_percentage nicdark_float_left nicdark_text_align_center">
                <a href="blog-standard.php"><img alt="" class="" width="20" src="img/icons/icon-grid-grey.svg"></a>
            </div>

            <div class="nicdark_width_33_percentage nicdark_float_left nicdark_text_align_right">
                <img alt="" class="" width="20" src="img/icons/icon-next-grey.svg">
            </div>

        </div>


    </div>
    <!--end container-->

</div>
<!--END bottom pagination-->