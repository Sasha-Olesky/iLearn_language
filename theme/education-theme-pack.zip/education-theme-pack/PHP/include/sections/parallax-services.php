<div class="nicdark_section nicdark_background_size_cover nicdark_background_position_center_bottom" style="background-image:url(img/parallax/img17.png);">
    <div class="nicdark_section nicdark_bg_greydark_alpha_6">

        
        <div class="nicdark_container nicdark_clearfix">


            <div class="nicdark_section nicdark_height_80"></div>


            <div class="grid grid_6 ">
        
                <!--START service-->
                <div class="nicdark_section nicdark_position_relative  nicdark_border_radius_3 nicdark_padding_20 nicdark_box_sizing_border_box">
                    <img alt="" class="nicdark_position_absolute" width="50" src="img/icons/icon-phone-white.svg">
                    <div class="nicdark_section nicdark_padding_left_70 nicdark_box_sizing_border_box">
                        <h2 class="nicdark_color_white"><strong>Free Call Support</strong></h2>
                        <div class="nicdark_section nicdark_height_20"></div>
                        <p class="nicdark_color_white">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean egestas magna at porttitor vehicula nullam augue.</p>
                        <div class="nicdark_section nicdark_height_20"></div>
                        <a class="nicdark_display_inline_block nicdark_color_white nicdark_first_font nicdark_border_1_solid_white nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="#">READ MORE</a>

                    </div>
                </div>
                <!--END services-->

            </div>


            <div class="grid grid_6 ">
        
                <!--START service-->
                <div class="nicdark_section nicdark_position_relative nicdark_border_radius_3 nicdark_padding_20 nicdark_box_sizing_border_box">
                    <img alt="" class="nicdark_position_absolute" width="50" src="img/icons/icon-percentage-white.svg">
                    <div class="nicdark_section nicdark_padding_left_70 nicdark_box_sizing_border_box">
                        <h2 class="nicdark_color_white"><strong>The Best Discount</strong></h2>
                        <div class="nicdark_section nicdark_height_20"></div>
                        <p class="nicdark_color_white">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean egestas magna at porttitor vehicula nullam augue.</p>
                        <div class="nicdark_section nicdark_height_20"></div>
                        <a class="nicdark_display_inline_block nicdark_color_white nicdark_first_font nicdark_border_1_solid_white nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="#">READ MORE</a>

                    </div>
                </div>
                <!--END services-->

            </div>


            <div class="nicdark_section nicdark_height_80"></div>

    
        </div>
        

    </div>
</div>