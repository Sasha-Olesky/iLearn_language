<div class="nicdark_width_50_percentage nicdark_width_100_percentage_all_iphone nicdark_float_left ">
    <p class="nicdark_padding_10 nicdark_padding_0_all_iphone nicdark_padding_left_0"><span class="nicdark_font_size_70 nicdark_float_left nicdark_padding_28 nicdark_line_height_30 nicdark_first_font"><strong>A</strong></span>ivamus volutpat eros pulvinar velit laoreet, sit amet egestas erat dignissim. Sed quis rutrum tellus, sit amet viverra felis. Cras sagittis sem sit amet urna feugiat rutrum. Nam nulla ipsum, venenatis malesuada felis quis, ultricies convallis neque. Pellentesque tristique fringilla tempus.</p>
</div>
<div class="nicdark_width_50_percentage nicdark_width_100_percentage_all_iphone nicdark_float_left">
    <p class="nicdark_padding_10 nicdark_padding_0_all_iphone nicdark_padding_right_0">Vivamus volutpat eros pulvinar velit laoreet, sit amet egestas erat dignissim. Sed quis rutrum tellus, sit amet viverra felis. Cras sagittis sem sit amet urna feugiat rutrum. Nam nulla ipsum, venenatis malesuada felis quis, ultricies convallis neque. Pellentesque tristique fringilla tempus.</p>
</div>

<div class="nicdark_width_100_percentage nicdark_float_left">
    <div class="nicdark_section nicdark_height_40"></div>
    <h3><strong>Our Latest Recipies</strong></h3>
    <div class="nicdark_section nicdark_height_20"></div>
    <p>Vivamus volutpat eros pulvinar velit laoreet, sit amet egestas erat dignissim. Sed quis rutrum tellus, sit amet viverra felis. Cras sagittis sem sit amet urna feugiat rutrum. Nam nulla ipsum, venenatis malesuada felis quis, ultricies convallis neque. Pellentesque tristique fringilla tempus. Vivamus bibendum nibh in dolor pharetra, a euismod nulla dignissim. Aenean viverra tincidunt nibh, in imperdiet nunc. Suspendisse eu ante pretium, consectetur leo at, congue quam. Nullam hendrerit porta ante vitae tristique. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Vestibulum ligula libero, feugiat faucibus mattis eget, pulvinar et ligula.</p>

    <div class="nicdark_section nicdark_height_20"></div>

    <div class="nicdark_width_50_percentage nicdark_padding_right_10 nicdark_box_sizing_border_box nicdark_float_left">
        <img alt="" class="nicdark_section" src="img/parallax/img3.png">    
    </div>
    <div class="nicdark_width_50_percentage nicdark_padding_left_10 nicdark_box_sizing_border_box nicdark_float_left">
        <img alt="" class="nicdark_section" src="img/parallax/img4.png">    
    </div>
    

    <div class="nicdark_section nicdark_height_50"></div>
    <h3><strong>Special Guest Interview</strong></h3>
    <div class="nicdark_section nicdark_height_20"></div>
    <p>Vivamus volutpat eros pulvinar velit laoreet, sit amet egestas erat dignissim. Sed quis rutrum tellus, sit amet viverra felis. Cras sagittis sem sit amet urna feugiat rutrum. Nam nulla ipsum, venenatis malesuada felis quis, ultricies convallis neque. Pellentesque tristique fringilla tempus. Vivamus bibendum nibh in dolor pharetra, a euismod nulla dignissim. Aenean viverra tincidunt nibh, in imperdiet nunc. Suspendisse eu ante pretium, consectetur leo at, congue quam. Nullam hendrerit porta ante vitae tristique. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Vestibulum ligula libero, feugiat faucibus mattis eget, pulvinar et ligula.</p>


    <div class="nicdark_section nicdark_height_50"></div>

    <div class="nicdark_section">
        <a class="nicdark_display_inline_block nicdark_padding_8 nicdark_first_font nicdark_margin_right_10 nicdark_color_greydark nicdark_padding_left_0" href="#">Tag :</a>
        <a class="nicdark_display_inline_block nicdark_font_size_13 nicdark_border_1_solid_grey nicdark_padding_8 nicdark_border_radius_3 nicdark_margin_10" href="#"># Vegan Food</a>
        <a class="nicdark_display_inline_block nicdark_font_size_13 nicdark_border_1_solid_grey nicdark_padding_8 nicdark_border_radius_3 nicdark_margin_10" href="#"># Recipies</a>
        <a class="nicdark_display_inline_block nicdark_font_size_13 nicdark_border_1_solid_grey nicdark_padding_8 nicdark_border_radius_3 nicdark_margin_10" href="#">Vegetarian</a>
        <a class="nicdark_display_inline_block nicdark_font_size_13 nicdark_border_1_solid_grey nicdark_padding_8 nicdark_border_radius_3 nicdark_margin_10" href="#">Fruit</a>
        <a class="nicdark_display_inline_block nicdark_font_size_13 nicdark_border_1_solid_grey nicdark_padding_8 nicdark_border_radius_3 nicdark_margin_10" href="#"># Italian Food</a>
        <a class="nicdark_display_inline_block nicdark_font_size_13 nicdark_border_1_solid_grey nicdark_padding_8 nicdark_border_radius_3 nicdark_margin_10" href="#"># Pizza</a>
        <a class="nicdark_display_inline_block nicdark_font_size_13 nicdark_border_1_solid_grey nicdark_padding_8 nicdark_border_radius_3 nicdark_margin_10" href="#">Lasagne</a>
    </div>

    <div class="nicdark_section nicdark_height_30"></div>

    <div class="nicdark_section">
        <img alt="" width="40" class="nicdark_margin_right_10" src="img/icons/icon-facebook-color.svg">
        <img alt="" width="40" class="nicdark_margin_right_10" src="img/icons/icon-twitter-color.svg">
        <img alt="" width="40" class="nicdark_margin_right_10" src="img/icons/icon-pinterest-color.svg">
        <img alt="" width="40" class="nicdark_margin_right_10" src="img/icons/icon-linkedin-color.svg">
        <img alt="" width="40" class="nicdark_margin_right_10" src="img/icons/icon-google-color.svg">
        <img alt="" width="40" class="nicdark_margin_right_10" src="img/icons/icon-mail-color.svg">
    </div>
</div>


<div class="nicdark_section nicdark_height_50"></div>


<div class="nicdark_section nicdark_border_top_1_solid_grey ">
    
    <div class="nicdark_section nicdark_height_50"></div>
    <h3><strong>2 Comments</strong></h3>
    <div class="nicdark_section nicdark_height_40"></div>
    
    <!--START comment preview-->
    <div class="nicdark_section">
        <div class="nicdark_display_table nicdark_float_left">
            <img alt="" class="nicdark_margin_right_10 nicdark_display_table_cell nicdark_vertical_align_middle nicdark_border_radius_100_percentage" width="40" src="img/avatar/avatar-chef-1.png">
            <p class="  nicdark_display_table_cell nicdark_vertical_align_middle "><span class="nicdark_color_greydark nicdark_first_font nicdark_margin_right_20"><strong>John Doe</strong></span>September 4, 2015 at 1:24 pm</p>
        </div>

        <div class="nicdark_section nicdark_height_20"></div>
        <div class="nicdark_section">
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. In et ipsum sit amet ex pulvinar mattis. Pellentesque vitae purus viverra, aliquet lacus in, fringilla massa. Suspendisse ac est a nisi aliquet sollicitudin. Interdum et malesuada fames.</p>
        </div>
        <div class="nicdark_section nicdark_height_20"></div>

        <div class="nicdark_section">
            <a class="nicdark_display_inline_block nicdark_color_white nicdark_first_font nicdark_bg_green nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="#">REPLY</a>
        </div>

    </div>
    <!--END comment preview-->

    <div class="nicdark_section nicdark_height_40"></div>

    <!--START comment preview-->
    <div class="nicdark_section">
        <div class="nicdark_display_table nicdark_float_left">
            <img alt="" class="nicdark_margin_right_10 nicdark_display_table_cell nicdark_vertical_align_middle nicdark_border_radius_100_percentage" width="40" src="img/avatar/avatar-chef-2.png">
            <p class="  nicdark_display_table_cell nicdark_vertical_align_middle "><span class="nicdark_color_greydark nicdark_first_font nicdark_margin_right_20"><strong>John Doe</strong></span>September 4, 2015 at 1:24 pm</p>
        </div>

        <div class="nicdark_section nicdark_height_20"></div>
        <div class="nicdark_section">
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. In et ipsum sit amet ex pulvinar mattis. Pellentesque vitae purus viverra, aliquet lacus in, fringilla massa. Suspendisse ac est a nisi aliquet sollicitudin. Interdum et malesuada fames.</p>
        </div>
        <div class="nicdark_section nicdark_height_20"></div>

        <div class="nicdark_section">
            <a class="nicdark_display_inline_block nicdark_color_white nicdark_first_font nicdark_bg_green nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="#">REPLY</a>
        </div>

    </div>
    <!--END comment preview-->

    <div class="nicdark_section nicdark_height_40"></div>

</div>




<div class="nicdark_section nicdark_border_top_1_solid_grey ">
    
    <div class="nicdark_section nicdark_height_50"></div>
    <h3><strong>Leave a Comment</strong></h3>
    <div class="nicdark_section nicdark_height_40"></div>
    
    


    <div class="nicdark_section nicdark_box_sizing_border_box">

        <!--form-->
        <div class="nicdark_section">
            <div class="nicdark_width_50_percentage nicdark_padding_10 nicdark_padding_left_0 nicdark_box_sizing_border_box nicdark_float_left">
                <input class="nicdark_padding_left_0 nicdark_background_none nicdark_border_top_width_0 nicdark_border_bottom_width_2 nicdark_border_right_width_0 nicdark_border_left_width_0" type="text" placeholder="Name">
            </div>
            <div class="nicdark_width_50_percentage nicdark_padding_10 nicdark_padding_right_0 nicdark_box_sizing_border_box nicdark_float_left">
                <input class="nicdark_padding_left_0 nicdark_background_none nicdark_border_top_width_0 nicdark_border_bottom_width_2 nicdark_border_right_width_0 nicdark_border_left_width_0" type="text" placeholder="Surname">
            </div>
        </div>
        <div class="nicdark_section">
            <div class="nicdark_width_50_percentage nicdark_padding_10 nicdark_padding_left_0 nicdark_box_sizing_border_box nicdark_float_left">
                <input class="nicdark_padding_left_0 nicdark_background_none nicdark_border_top_width_0 nicdark_border_bottom_width_2 nicdark_border_right_width_0 nicdark_border_left_width_0" type="text" placeholder="Email">
            </div>
            <div class="nicdark_width_50_percentage nicdark_padding_10 nicdark_padding_right_0 nicdark_box_sizing_border_box nicdark_float_left">
                <input class="nicdark_padding_left_0 nicdark_background_none nicdark_border_top_width_0 nicdark_border_bottom_width_2 nicdark_border_right_width_0 nicdark_border_left_width_0" type="text" placeholder="Subject">
            </div>
        </div>
        <div class="nicdark_section">
            <div class="nicdark_width_100_percentage nicdark_padding_10 nicdark_padding_right_0 nicdark_padding_left_0 nicdark_box_sizing_border_box nicdark_float_left">
                <textarea rows="7" class="nicdark_padding_left_0 nicdark_background_none nicdark_border_top_width_0 nicdark_border_bottom_width_2 nicdark_border_right_width_0 nicdark_border_left_width_0" placeholder="Message"></textarea>
            </div>
        </div>
        <div class="nicdark_section">
            <div class="nicdark_width_100_percentage nicdark_padding_10 nicdark_padding_right_0 nicdark_padding_left_0 nicdark_box_sizing_border_box nicdark_float_left">
                <a class="nicdark_display_inline_block nicdark_text_align_center nicdark_box_sizing_border_box  nicdark_color_white nicdark_bg_orange nicdark_first_font nicdark_padding_10_20 nicdark_border_radius_3 " href="#">SEND NOW</a>   
            </div>
        </div>
        <!--form-->

    </div>



</div>