<div class="nicdark_section nicdark_background_size_cover nicdark_background_position_center_bottom" style="background-image:url(img/parallax/img4.png);">
    <div class="nicdark_section nicdark_bg_greydark_alpha">

        
        <div class="nicdark_container nicdark_clearfix">


            <div class="nicdark_section nicdark_height_80"></div>

            <div class="grid grid_6 nicdark_position_relative">
                <img alt="" class="nicdark_position_absolute" width="55" src="img/icons/icon-check-white.svg">
                <h1 class="nicdark_color_white nicdark_font_size_40 nicdark_padding_left_80 nicdark_line_height_50"><strong><span class="nicdark_border_bottom_4_solid_white">Doing the right thing,</span><br> at the right time.</strong></h1>    
            </div>

            <div class="nicdark_section nicdark_height_1"></div>

            <div class="grid grid_4 ">
        
                <div class="nicdark_padding_20">    
                    <h1 class="nicdark_font_size_40 nicdark_color_white"><strong><span class="nicdark_color_f1f1f1 nicdark_font_size_25">01.</span> Experience</strong></h1>
                    <div class="nicdark_section nicdark_height_20"></div>
                    <p class="nicdark_color_white">Phasellus enim libero, blandit vel sapien vitae, condimentum ultricies magna et. Quisque euismod orci ut et lobortis.</p>
                </div>

            </div>


            <div class="grid grid_4 ">
        
                <div class="nicdark_padding_20">    
                    <h1 class="nicdark_font_size_40 nicdark_color_white"><strong><span class="nicdark_color_f1f1f1 nicdark_font_size_25">02.</span> Education</strong></h1>
                    <div class="nicdark_section nicdark_height_20"></div>
                    <p class="nicdark_color_white">Phasellus enim libero, blandit vel sapien vitae, condimentum ultricies magna et. Quisque euismod orci ut et lobortis.</p>
                </div>

            </div>


            <div class="grid grid_4 ">
        
                <div class="nicdark_padding_20">    
                    <h1 class="nicdark_font_size_40 nicdark_color_white"><strong><span class="nicdark_color_f1f1f1 nicdark_font_size_25">03.</span> Certificate</strong></h1>
                    <div class="nicdark_section nicdark_height_20"></div>
                    <p class="nicdark_color_white">Phasellus enim libero, blandit vel sapien vitae, condimentum ultricies magna et. Quisque euismod orci ut et lobortis.</p>
                </div>

            </div>

            <div class="nicdark_section nicdark_height_80"></div>

    
        </div>
        

    </div>
</div>