<div class="nicdark_section nicdark_background_size_cover nicdark_background_position_center_bottom" style="background-image:url(img/parallax/img2.png);">

    <div class="nicdark_section nicdark_bg_greydark_alpha_4">


        <div class="nicdark_section nicdark_height_100"></div>


        <!--start nicdark_container-->
        <div class="nicdark_container nicdark_clearfix">


            <div class="grid grid_6">
                <div class="nicdark_section nicdark_height_70"></div>
                <h1 class="nicdark_color_white nicdark_second_font">NEXT COURSE <span class="nicdark_border_bottom_4_solid_white">SUSHI WOK</span></h1>
                <div class="nicdark_section nicdark_height_20"></div>
                <h1 class="nicdark_color_white nicdark_font_size_60"><strong><a class="nicdark_first_font nicdark_color_white" href="single-course.php">Available Now</a></strong></h1>
                <div class="nicdark_section nicdark_height_40"></div>


                <div class="nicdark_section">
                    <div class="nicdark_width_33_percentage nicdark_width_100_percentage_all_iphone nicdark_float_left nicdark_text_align_center_all_iphone"> 
                        <div class=" nicdark_display_inline_block ">
                            <h1 class="nicdark_color_white nicdark_font_size_40 nicdark_padding_20_25">12</h1>
                            <h5 class="nicdark_bg_white nicdark_padding_5 nicdark_border_radius_3 nicdark_text_align_center">TEACHERS</h5>
                        </div>
                    </div> 
                    <div class="nicdark_width_33_percentage nicdark_width_100_percentage_all_iphone nicdark_float_left nicdark_text_align_center_all_iphone"> 
                        <div class=" nicdark_display_inline_block ">
                            <h1 class="nicdark_color_white nicdark_font_size_40 nicdark_padding_20_25">50</h1>
                            <h5 class="nicdark_bg_white nicdark_padding_5 nicdark_border_radius_3 nicdark_text_align_center">ATTENDEES</h5>
                        </div>
                    </div> 
                    <div class="nicdark_width_33_percentage nicdark_width_100_percentage_all_iphone nicdark_float_left nicdark_text_align_center_all_iphone"> 
                        <div class=" nicdark_display_inline_block ">
                            <h1 class="nicdark_color_white nicdark_font_size_40 nicdark_padding_20_25">15</h1>
                            <h5 class="nicdark_bg_white nicdark_padding_5 nicdark_border_radius_3 nicdark_text_align_center">DAYS</h5>
                        </div>
                    </div>    
                </div>

            </div>

            <div class="grid grid_1">
                <div class="nicdark_section nicdark_height_1"></div>
            </div>

            <div class="grid grid_5">
                
                <!--form-->
                <div class="nicdark_section nicdark_bg_white">

                  <div class="nicdark_section nicdark_padding_20 nicdark_box_sizing_border_box nicdark_bg_grey nicdark_border_bottom_1_solid_grey nicdark_text_align_center">
                    <h6 class="nicdark_second_font nicdark_bg_orange nicdark_padding_5 nicdark_border_radius_3 nicdark_color_white nicdark_display_inline_block">LAST 7 SEATS</h6>
                    <div class="nicdark_section nicdark_height_5"></div>
                    <h1 class=""><strong>Register Now</strong></h1>
                  </div>
                  <div class="nicdark_section nicdark_padding_20_50 nicdark_box_sizing_border_box">
                    
                    <div class="nicdark_section">
                        <div class="nicdark_width_50_percentage nicdark_width_100_percentage_all_iphone nicdark_padding_10 nicdark_box_sizing_border_box nicdark_float_left">
                            <input class="nicdark_padding_left_0 nicdark_background_none nicdark_border_top_width_0 nicdark_border_bottom_width_2 nicdark_border_right_width_0 nicdark_border_left_width_0" type="text" placeholder="Name">
                        </div>
                        <div class="nicdark_width_50_percentage nicdark_width_100_percentage_all_iphone nicdark_padding_10 nicdark_box_sizing_border_box nicdark_float_left">
                            <input class="nicdark_padding_left_0 nicdark_background_none nicdark_border_top_width_0 nicdark_border_bottom_width_2 nicdark_border_right_width_0 nicdark_border_left_width_0" type="text" placeholder="Surname">
                        </div>
                    </div>
                    <div class="nicdark_section">
                        <div class="nicdark_width_50_percentage nicdark_width_100_percentage_all_iphone nicdark_padding_10 nicdark_box_sizing_border_box nicdark_float_left">
                            <input class="nicdark_padding_left_0 nicdark_background_none nicdark_border_top_width_0 nicdark_border_bottom_width_2 nicdark_border_right_width_0 nicdark_border_left_width_0" type="text" placeholder="Email">
                        </div>
                        <div class="nicdark_width_50_percentage nicdark_width_100_percentage_all_iphone nicdark_padding_10 nicdark_box_sizing_border_box nicdark_float_left">
                            <input class="nicdark_padding_left_0 nicdark_background_none nicdark_border_top_width_0 nicdark_border_bottom_width_2 nicdark_border_right_width_0 nicdark_border_left_width_0" type="text" placeholder="Subject">
                        </div>
                    </div>
                    <div class="nicdark_section">
                        <div class="nicdark_width_100_percentage nicdark_padding_10 nicdark_box_sizing_border_box nicdark_float_left">
                            <textarea rows="4" class="nicdark_padding_left_0 nicdark_background_none nicdark_border_top_width_0 nicdark_border_bottom_width_2 nicdark_border_right_width_0 nicdark_border_left_width_0" placeholder="Message"></textarea>
                        </div>
                    </div>
                    <div class="nicdark_section">
                        <div class="nicdark_width_100_percentage nicdark_padding_10 nicdark_box_sizing_border_box nicdark_float_left">
                            <a class="nicdark_bg_white_hover nicdark_color_green_hover nicdark_border_2_solid_green nicdark_transition_all_08_ease nicdark_display_inline_block nicdark_text_align_center nicdark_box_sizing_border_box nicdark_width_100_percentage nicdark_color_white nicdark_bg_green nicdark_first_font nicdark_padding_10_20 nicdark_border_radius_3 " href="contact-1.php">SEND NOW</a>   
                        </div>
                    </div>

                  </div>  

                </div>
                <!--form-->

            </div>


        </div>
        <!--end container-->

        <div class="nicdark_section nicdark_height_100"></div>


    </div>

</div>