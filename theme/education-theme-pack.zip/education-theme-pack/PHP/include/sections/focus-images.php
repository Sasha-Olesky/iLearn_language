<div class="nicdark_section nicdark_padding_10 nicdark_box_sizing_border_box">
               

    <div class="nicdark_width_33_percentage nicdark_padding_10 nicdark_box_sizing_border_box nicdark_width_100_percentage_responsive nicdark_float_left">
    
        <!--START-->
        <div class="nicdark_section nicdark_position_relative">
                            
            <img alt="" class="nicdark_section" src="img/courses/img21.png">

            <div class="nicdark_bg_greydark_alpha_6 nicdark_position_absolute nicdark_left_0 nicdark_height_100_percentage nicdark_width_100_percentage nicdark_padding_30 nicdark_box_sizing_border_box">
                

                <div class="nicdark_display_table nicdark_width_100_percentage nicdark_height_100_percentage nicdark_text_align_center">
                
                    <div class="nicdark_display_table_cell nicdark_vertical_align_middle">
                    
                            <h2 class="nicdark_color_white"><a class="nicdark_color_white nicdark_first_font" href="courses.php"><strong>Courses For Adults</strong></a></h2>
                            <div class="nicdark_section nicdark_height_10"></div>
                            <h5 class="nicdark_text_transform_uppercase nicdark_color_white nicdark_second_font">42 Courses</h5>

                    </div>

                </div>


            </div>

        </div>
        <!--END-->

    </div>

    <div class="nicdark_width_33_percentage nicdark_padding_10 nicdark_box_sizing_border_box nicdark_width_100_percentage_responsive nicdark_float_left">
    
        <!--START-->
        <div class="nicdark_section nicdark_position_relative">
                            
            <img alt="" class="nicdark_section" src="img/courses/img25.png">

            <div class="nicdark_bg_greydark_alpha_6 nicdark_position_absolute nicdark_left_0 nicdark_height_100_percentage nicdark_width_100_percentage nicdark_padding_30 nicdark_box_sizing_border_box">
                

                <div class="nicdark_display_table nicdark_width_100_percentage nicdark_height_100_percentage nicdark_text_align_center">
                
                    <div class="nicdark_display_table_cell nicdark_vertical_align_middle">
                    
                            <h2 class="nicdark_color_white"><a class="nicdark_color_white nicdark_first_font" href="courses.php"><strong>Asian Cousine</strong></a></h2>
                            <div class="nicdark_section nicdark_height_10"></div>
                            <h5 class="nicdark_text_transform_uppercase nicdark_color_white nicdark_second_font">11 Courses</h5>

                    </div>

                </div>


            </div>

        </div>
        <!--END-->

    </div>

    <div class="nicdark_width_33_percentage nicdark_padding_10 nicdark_box_sizing_border_box nicdark_width_100_percentage_responsive nicdark_float_left">
    
        <!--START-->
        <div class="nicdark_section nicdark_position_relative">
                            
            <img alt="" class="nicdark_section" src="img/courses/img29.png">

            <div class="nicdark_bg_greydark_alpha_6 nicdark_position_absolute nicdark_left_0 nicdark_height_100_percentage nicdark_width_100_percentage nicdark_padding_30 nicdark_box_sizing_border_box">
                

                <div class="nicdark_display_table nicdark_width_100_percentage nicdark_height_100_percentage nicdark_text_align_center">
                
                    <div class="nicdark_display_table_cell nicdark_vertical_align_middle">
                    
                            <h2 class="nicdark_color_white"><a class="nicdark_color_white nicdark_first_font" href="courses.php"><strong>Italian Dishes</strong></a></h2>
                            <div class="nicdark_section nicdark_height_10"></div>
                            <h5 class="nicdark_text_transform_uppercase nicdark_color_white nicdark_second_font">23 Courses</h5>

                    </div>

                </div>


            </div>

        </div>
        <!--END-->

    </div>     


</div> 