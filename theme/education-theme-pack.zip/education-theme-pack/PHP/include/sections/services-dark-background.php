<div class="nicdark_section nicdark_bg_greydark">

    <div class="nicdark_section nicdark_height_50"></div>

    <!--start nicdark_container-->
        <div class="nicdark_container nicdark_clearfix">
    
        

        <div class="grid grid_4">
            <div class="nicdark_section nicdark_position_relative">
                <img alt="" class="nicdark_position_absolute" width="50" src="img/icons/icon-fish.svg">
                <div class="nicdark_section nicdark_padding_left_70 nicdark_box_sizing_border_box">
                    <h2 class="nicdark_color_white">Fish Dishes</h2>
                    <div class="nicdark_section nicdark_height_20"></div>
                    <p class="nicdark_color_grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean egestas magna at porttitor vehicula nullam augue.</p>
                </div>
            </div>
        </div>

        <div class="grid grid_4">
            <div class="nicdark_section nicdark_position_relative">
                <img alt="" class="nicdark_position_absolute" width="50" src="img/icons/icon-sushi.svg">
                <div class="nicdark_section nicdark_padding_left_70 nicdark_box_sizing_border_box">
                    <h2 class="nicdark_color_white">Sushi Courses</h2>
                    <div class="nicdark_section nicdark_height_20"></div>
                    <p class="nicdark_color_grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean egestas magna at porttitor vehicula nullam augue.</p>
                </div>
            </div>
        </div>

        <div class="grid grid_4">
            <div class="nicdark_section nicdark_position_relative">
                <img alt="" class="nicdark_position_absolute" width="50" src="img/icons/icon-dessert.svg">
                <div class="nicdark_section nicdark_padding_left_70 nicdark_box_sizing_border_box">
                    <h2 class="nicdark_color_white">Ice Cream Practice</h2>
                    <div class="nicdark_section nicdark_height_20"></div>
                    <p class="nicdark_color_grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean egestas magna at porttitor vehicula nullam augue.</p>
                </div>
            </div>
        </div>

        


   
    </div>
    <!--end container-->

    <div class="nicdark_section nicdark_height_50"></div>

</div>