<div class="nicdark_section">
    <div class="nicdark_section nicdark_bg_grey nicdark_border_top_1_solid_grey">

        <!--start nicdark_container-->
        <div class="nicdark_container nicdark_clearfix">

            <div class="nicdark_section nicdark_height_30"></div>

            <div class="grid grid_2">
                <img alt="" class="nicdark_width_100_percentage" src="img/partner/logo1.png">  
            </div>
            <div class="grid grid_2">
                <img alt="" class="nicdark_width_100_percentage" src="img/partner/logo4.png">  
            </div>
            <div class="grid grid_2">
                <img alt="" class="nicdark_width_100_percentage" src="img/partner/logo3.png">  
            </div>
            <div class="grid grid_2">
                <img alt="" class="nicdark_width_100_percentage" src="img/partner/logo2.png">  
            </div>
            <div class="grid grid_2">
                <img alt="" class="nicdark_width_100_percentage" src="img/partner/logo5.png">  
            </div>
            <div class="grid grid_2">
                <img alt="" class="nicdark_width_100_percentage" src="img/partner/logo6.png">  
            </div>
            

            <div class="nicdark_section nicdark_height_30"></div>

    
        </div>
        <!--end container-->

    </div>
</div>