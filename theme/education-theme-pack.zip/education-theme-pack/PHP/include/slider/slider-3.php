<div class="nicdark_section nicdark_background_size_cover nicdark_background_position_center_bottom" style="background-image:url(img/parallax/img32.png);">

    <div class="nicdark_section nicdark_bg_greydark_alpha_gradient_5">

        
        <div class="nicdark_section nicdark_height_250"></div>

        <!--start nicdark_container-->
        <div class="nicdark_container nicdark_clearfix">


            <div class="grid grid_8">

                
                
                <strong class="nicdark_color_white nicdark_font_size_70 nicdark_font_size_40_responsive nicdark_line_height_40_responsive nicdark_first_font nicdark_display_block">Education</strong>

                <div class="nicdark_section nicdark_height_1"></div>

                <!--START typed words-->
                <div class="nicdark_section nicdark_display_none_all_responsive">
                    

                    <strong class="nicdark_color_white nicdark_font_size_40 nicdark_first_font">Learning how to </strong>

                    <div class="nicdark_typed_strings">

                        <p><strong class="nicdark_color_white nicdark_font_size_40 nicdark_first_font">make a Pizza</strong></p>
                        <p><strong class="nicdark_color_white nicdark_font_size_40 nicdark_first_font">bake a Cake</strong></p>

                    </div>
                    <span class="nicdark_typed nicdark_padding_botttom_5" style="white-space:pre;"></span>
                
                </div>
                <!--END typed words-->



                <div class="nicdark_section nicdark_height_30"></div>

                <p class="nicdark_color_white nicdark_font_size_20 nicdark_line_height_30">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean egestas magna at porttitor vehicula. Nullam augue augue, dignissim id bibendum id, consequat et leo. Curabitur viverra tincidunt nulla nec tempor nullam augue augue.</p>
                
                <div class="nicdark_section nicdark_height_30"></div>

                <a class="nicdark_display_inline_block nicdark_margin_left_0 nicdark_text_align_center nicdark_box_sizing_border_box nicdark_color_white nicdark_border_2_solid_white nicdark_first_font nicdark_padding_10_20 nicdark_border_radius_3 nicdark_margin_10" href="about-us.php">ABOUT</a>
                <a class="nicdark_display_inline_block nicdark_text_align_center nicdark_box_sizing_border_box nicdark_color_white nicdark_border_2_solid_white  nicdark_first_font nicdark_padding_10_20 nicdark_border_radius_3 nicdark_margin_10" href="courses.php">COURSES</a>

            </div>

        </div>
        <!--end container-->


        <div class="nicdark_section nicdark_height_250"></div>


    </div>

</div>