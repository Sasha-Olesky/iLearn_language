<div class="nicdark_section nicdark_background_size_cover nicdark_background_position_center" style="background-image:url(img/parallax/img41.png);">

    <div class="nicdark_section nicdark_bg_greydark_alpha_gradient_2">

        
        <div class="nicdark_section nicdark_height_570"></div>

        <!--start nicdark_container-->
        <div class="nicdark_container nicdark_clearfix nicdark_display_none_all_iphone">


            <div class="grid grid_12">

                
                
                <strong class="nicdark_color_white nicdark_font_size_60 nicdark_first_font">In our School you can</strong>

                <!--START typed words-->
                <div class="nicdark_section ">
                    

                    <strong class="nicdark_color_white nicdark_font_size_40 nicdark_first_font">learn </strong>

                    <div class="nicdark_typed_strings">

                        <p><strong class="nicdark_color_white nicdark_font_size_40 nicdark_first_font">how to make a pizza</strong></p>
                        <p><strong class="nicdark_color_white nicdark_font_size_40 nicdark_first_font">the best fish dishes</strong></p>

                    </div>
                    <span class="nicdark_typed nicdark_padding_botttom_5" style="white-space:pre;"></span>
                
                </div>
                <!--END typed words-->

            </div>

        </div>
        <!--end container-->


        <div class="nicdark_section nicdark_height_50"></div>


    </div>

</div>