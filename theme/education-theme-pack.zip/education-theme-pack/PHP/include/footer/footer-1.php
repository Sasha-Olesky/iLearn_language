<div class="nicdark_section nicdark_bg_greydark">

    <div class="nicdark_section nicdark_height_50"></div>

    <!--start nicdark_container-->
        <div class="nicdark_container nicdark_clearfix">
    
        
        <div class="grid grid_3">
            <img width="200" class="" src="img/logo-white.svg">
            <div class="nicdark_section nicdark_height_20"></div>
            <p class="nicdark_color_grey">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor massa.</p>
        
            <div class="nicdark_section nicdark_height_30"></div>
            <h3 class="nicdark_color_white">Newsletter</h3>
            <div class="nicdark_section nicdark_height_20"></div>

            <div class="nicdark_section">
                <div class="nicdark_width_70_percentage nicdark_padding_10 nicdark_padding_left_0 nicdark_box_sizing_border_box nicdark_float_left">
                    <input class="nicdark_padding_left_0 nicdark_background_none nicdark_border_top_width_0 nicdark_border_right_width_0 nicdark_border_left_width_0 nicdark_border_1_solid_grey_2" type="text" placeholder="Email">
                </div>
                <div class="nicdark_width_30_percentage nicdark_padding_10 nicdark_box_sizing_border_box nicdark_float_left">
                    <input class="nicdark_bg_green nicdak_text_align_center nicdark_color_white nicdark_border_0 nicdark_padding_10 nicdark_border_radius_3" type="submit" value="SEND">
                </div>
            </div>

        </div>

        <div class="grid grid_3">
            <h3 class="nicdark_color_white">Recent Posts</h3>
            <div class="nicdark_section nicdark_height_20"></div>
            
            <div class="nicdark_section nicdark_position_relative">
                <div class="nicdark_section nicdark_height_10"></div>
                <img class="nicdark_position_absolute nicdark_top_10 nicdark_left_0" width="70" height="60" src="img/courses/img1.png">
                <div class="nicdark_section nicdark_padding_left_90 nicdark_box_sizing_border_box">
                    <h4 class="nicdark_color_white nicdark_second_font">Fish Dishes</h4>
                    <div class="nicdark_section nicdark_height_10"></div>
                    <p class="nicdark_color_grey nicdark_font_size_13">15 December 2016</p>
                    <div class="nicdark_section nicdark_height_10"></div>
                    <p class="nicdark_color_grey nicdark_font_size_13">By : John Doe</p>
                </div>
                <div class="nicdark_section nicdark_height_10"></div>
            </div>

            <div class="nicdark_section nicdark_height_10"></div>

            <div class="nicdark_section nicdark_position_relative">
                <div class="nicdark_section nicdark_height_10"></div>
                <img class="nicdark_position_absolute nicdark_top_10 nicdark_left_0" width="70" height="60" src="img/courses/img1.png">
                <div class="nicdark_section nicdark_padding_left_90 nicdark_box_sizing_border_box">
                    <h4 class="nicdark_color_white nicdark_second_font">Fish Dishes</h4>
                    <div class="nicdark_section nicdark_height_10"></div>
                    <p class="nicdark_color_grey nicdark_font_size_13">15 December 2016</p>
                    <div class="nicdark_section nicdark_height_10"></div>
                    <p class="nicdark_color_grey nicdark_font_size_13">By : John Doe</p>
                </div>
                <div class="nicdark_section nicdark_height_10"></div>
            </div>

            <div class="nicdark_section nicdark_height_10"></div>

            <div class="nicdark_section nicdark_position_relative">
                <div class="nicdark_section nicdark_height_10"></div>
                <img class="nicdark_position_absolute nicdark_top_10 nicdark_left_0" width="70" height="60" src="img/courses/img1.png">
                <div class="nicdark_section nicdark_padding_left_90 nicdark_box_sizing_border_box">
                    <h4 class="nicdark_color_white nicdark_second_font">Fish Dishes</h4>
                    <div class="nicdark_section nicdark_height_10"></div>
                    <p class="nicdark_color_grey nicdark_font_size_13">15 December 2016</p>
                    <div class="nicdark_section nicdark_height_10"></div>
                    <p class="nicdark_color_grey nicdark_font_size_13">By : John Doe</p>
                </div>
                <div class="nicdark_section nicdark_height_10"></div>
            </div>

            
        </div>

        <div class="grid grid_3">
            <h3 class="nicdark_color_white">Next Events</h3>
            <div class="nicdark_section nicdark_height_20"></div>
            
            <div class="nicdark_section nicdark_position_relative">
                <div class="nicdark_section nicdark_height_10"></div>

                <div class="nicdark_position_absolute nicdark_top_10 nicdark_left_0 nicdark_padding_10 nicdark_box_sizing_border_box nicdark_text_align_center nicdark_bg_orange  nicdark_display_inline_block nicdark_width_70">
                    <h2 class="nicdark_color_white">10</h2>
                    <div class="nicdark_section nicdark_height_5"></div>
                    <p class="nicdark_text_align_center nicdark_color_white nicdark_font_size_12">MAY</p>
                </div>

                <div class="nicdark_section nicdark_padding_left_90 nicdark_box_sizing_border_box">
                    <h4 class="nicdark_color_white nicdark_second_font">Course Presentation</h4>
                    <div class="nicdark_section nicdark_height_10"></div>
                    <p class="nicdark_color_grey nicdark_font_size_13">On : 15 December 2016</p>
                    <div class="nicdark_section nicdark_height_10"></div>
                    <p class="nicdark_color_grey nicdark_font_size_13">By : John Doe</p>
                </div>
                <div class="nicdark_section nicdark_height_10"></div>
            </div>

            <div class="nicdark_section nicdark_height_10"></div>

            <div class="nicdark_section nicdark_position_relative">
                <div class="nicdark_section nicdark_height_10"></div>

                <div class="nicdark_position_absolute nicdark_top_10 nicdark_left_0 nicdark_padding_10 nicdark_box_sizing_border_box nicdark_text_align_center nicdark_bg_orange nicdark_display_inline_block nicdark_width_70">
                    <h2 class="nicdark_color_white">10</h2>
                    <div class="nicdark_section nicdark_height_5"></div>
                    <p class="nicdark_text_align_center nicdark_color_white nicdark_font_size_12">MAY</p>
                </div>

                <div class="nicdark_section nicdark_padding_left_90 nicdark_box_sizing_border_box">
                    <h4 class="nicdark_color_white nicdark_second_font">Course Presentation</h4>
                    <div class="nicdark_section nicdark_height_10"></div>
                    <p class="nicdark_color_grey nicdark_font_size_13">On : 15 December 2016</p>
                    <div class="nicdark_section nicdark_height_10"></div>
                    <p class="nicdark_color_grey nicdark_font_size_13">By : John Doe</p>
                </div>
                <div class="nicdark_section nicdark_height_10"></div>
            </div>

            <div class="nicdark_section nicdark_height_10"></div>

            <div class="nicdark_section nicdark_position_relative">
                <div class="nicdark_section nicdark_height_10"></div>

                <div class="nicdark_position_absolute nicdark_top_10 nicdark_left_0 nicdark_padding_10 nicdark_box_sizing_border_box nicdark_text_align_center nicdark_bg_orange  nicdark_display_inline_block nicdark_width_70">
                    <h2 class="nicdark_color_white">10</h2>
                    <div class="nicdark_section nicdark_height_5"></div>
                    <p class="nicdark_text_align_center nicdark_color_white nicdark_font_size_12">MAY</p>
                </div>

                <div class="nicdark_section nicdark_padding_left_90 nicdark_box_sizing_border_box">
                    <h4 class="nicdark_color_white nicdark_second_font">Course Presentation</h4>
                    <div class="nicdark_section nicdark_height_10"></div>
                    <p class="nicdark_color_grey nicdark_font_size_13">On : 15 December 2016</p>
                    <div class="nicdark_section nicdark_height_10"></div>
                    <p class="nicdark_color_grey nicdark_font_size_13">By : John Doe</p>
                </div>
                <div class="nicdark_section nicdark_height_10"></div>
            </div>


        </div>

        <div class="grid grid_3">
            <h3 class="nicdark_color_white">Instagram</h3>
            <div class="nicdark_section nicdark_height_20"></div>
            <img width="83" height="83" class="nicdark_margin_5 nicdark_margin_left_0" src="img/courses/img1.png"> 
            <img width="83" height="83" class="nicdark_margin_5" src="img/courses/img2.png"> 
            <img width="83" height="83" class="nicdark_margin_5" src="img/courses/img3.png"> 
            <img width="83" height="83" class="nicdark_margin_5 nicdark_margin_left_0" src="img/courses/img4.png"> 
            <img width="83" height="83" class="nicdark_margin_5" src="img/courses/img1.png"> 
            <img width="83" height="83" class="nicdark_margin_5" src="img/courses/img2.png">

            <div class="nicdark_section nicdark_height_30"></div>

            <img width="30" class="nicdark_margin_right_10" src="img/icons/icon-facebook.svg">
            <img width="30" class="nicdark_margin_right_10" src="img/icons/icon-twitter.svg">
            <img width="30" class="nicdark_margin_right_10" src="img/icons/icon-pinterest.svg">
            <img width="30" class="nicdark_margin_right_10" src="img/icons/icon-linkedin.svg">
            <img width="30" class="nicdark_margin_right_10" src="img/icons/icon-youtube.svg">
               
        </div>

   
    </div>
    <!--end container-->

    <div class="nicdark_section nicdark_height_50"></div>

</div>

<div class="nicdark_section nicdark_bg_greydark">

    <!--start nicdark_container-->
        <div class="nicdark_container nicdark_clearfix">
    
        
        <div class="grid grid_6">
            <p class="nicdark_color_grey nicdark_font_size_14">© Copyright 2016 CleanThemes.net</p>
        </div>

        <div class="grid grid_6 nicdark_text_align_right ">

            <div class="nicdark_navigation_copyright">
                <ul>
                    <li>
                        <a href="#">HOME</a>
                    </li>
                    <li>
                        <a href="#">ABOUT US</a>
                    </li>
                    <li>
                        <a href="#">SERVICES</a>
                    </li>
                    <li>
                        <a href="#">COURSES</a>
                    </li>
                    <li>
                        <a href="#">CONTACT</a>
                    </li>
                </ul>
            </div>
            
        </div>

   
    </div>
    <!--end container-->

</div>