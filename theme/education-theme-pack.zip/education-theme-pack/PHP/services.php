<?php include "include/header/header.php"; ?>







                <?php include "include/header/navigation-2.php"; ?>


                       
                <div class="nicdark_section nicdark_background_size_cover nicdark_background_position_center_bottom" style="background-image:url(img/parallax/img41.png);">

                    <div class="nicdark_section nicdark_bg_greydark_alpha_gradient_2">

                        


                        <!--start nicdark_container-->
                        <div class="nicdark_container nicdark_clearfix">


                            <div class="nicdark_section nicdark_height_200"></div>


                            <div class="grid grid_12">

                                
                                
                                <strong class="nicdark_color_white nicdark_font_size_60 nicdark_first_font">Services</strong>
                                <div class="nicdark_section nicdark_height_20"></div>

                            </div>



                        </div>
                        <!--end container-->

                    </div>

                </div>




               
                    <div class="nicdark_section nicdark_bg_grey nicdark_border_bottom_1_solid_grey">

                        <!--start nicdark_container-->
                        <div class="nicdark_container nicdark_clearfix">

                            <div class="grid grid_12">


                                
                                <a href="#">Home</a>
                                <img alt="" class="nicdark_margin_left_10 nicdark_margin_right_10" width="10" src="img/icons/icon-next-grey.svg">
                                <a href="#">Pages</a>
                                <img alt="" class="nicdark_margin_left_10 nicdark_margin_right_10" width="10" src="img/icons/icon-next-grey.svg">
                                <a href="#">Services</a>
                                


                            </div>

                    
                        </div>
                        <!--end container-->

                    </div>




                    <div class="nicdark_section nicdark_height_50"></div>


                    <?php include "include/sections/services-left-icon-btn.php"; ?>


                    <div class="nicdark_section nicdark_height_50"></div>


                    

                    <div class="nicdark_section ">

                        <div class="nicdark_container nicdark_clearfix">

                            <div class="grid grid_12">

                                <h1 class="nicdark_font_size_50"><strong>Our Prices</strong></h1>
                                <div class="nicdark_section nicdark_height_10"></div>
                                <h3 class=" nicdark_color_grey">See Our Packages</h3>

                            </div>

                            
                            <?php include "include/sections/prices.php"; ?>
                            

                        </div>

                    </div>



                   
                    <div class="nicdark_section nicdark_height_50"></div>


                    <?php include "include/sections/parallax-half-image.php"; ?>
                

                    <div class="nicdark_section nicdark_height_40"></div>






                    <div class="nicdark_section ">

                        

                        <div class="nicdark_container nicdark_clearfix">

                            <div class="grid grid_12">

                                <h1 class="nicdark_font_size_50"><strong>Our Services</strong></h1>
                                <div class="nicdark_section nicdark_height_10"></div>
                                <h3 class=" nicdark_color_grey">See Our Packages</h3>
                                <div class="nicdark_section nicdark_height_20"></div>

                            </div>

                            <div class="grid grid_4 ">
                            
                                <!--START service-->
                                <div class="nicdark_section nicdark_position_relative">
                                    <img alt="" class="nicdark_position_absolute" width="50" src="img/icons/restaurant-elements/icon-waiter-grey.svg">
                                    <div class="nicdark_section nicdark_padding_left_70 nicdark_box_sizing_border_box">
                                        <h2><strong>Best Certificate</strong></h2>
                                        <div class="nicdark_section nicdark_height_20"></div>
                                        <p class="">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean egestas magna at porttitor vehicula nullam augue.</p>
                                        <div class="nicdark_section nicdark_height_20"></div>
                                        <a class="nicdark_display_inline_block nicdark_color_white nicdark_first_font nicdark_bg_green nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="#">READ MORE</a>

                                    </div>
                                </div>
                                <!--END services-->

                            </div>

                            <div class="grid grid_4 ">
                            
                                <!--START service-->
                                <div class="nicdark_section nicdark_position_relative">
                                    <img alt="" class="nicdark_position_absolute" width="50" src="img/icons/restaurant-elements/icon-dinner-grey.svg">
                                    <div class="nicdark_section nicdark_padding_left_70 nicdark_box_sizing_border_box">
                                        <h2><strong>National Awards</strong></h2>
                                        <div class="nicdark_section nicdark_height_20"></div>
                                        <p class="">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean egestas magna at porttitor vehicula nullam augue.</p>
                                        <div class="nicdark_section nicdark_height_20"></div>
                                        <a class="nicdark_display_inline_block nicdark_color_white nicdark_first_font nicdark_bg_green nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="#">READ MORE</a>
                                    </div>
                                </div>
                                <!--END services-->

                            </div>

                            <div class="grid grid_4 ">
                            
                                <!--START service-->
                                <div class="nicdark_section nicdark_position_relative">
                                    <img alt="" class="nicdark_position_absolute" width="50" src="img/icons/restaurant-elements/icon-open-grey.svg">
                                    <div class="nicdark_section nicdark_padding_left_70 nicdark_box_sizing_border_box">
                                        <h2><strong>Qualifier Teacher</strong></h2>
                                        <div class="nicdark_section nicdark_height_20"></div>
                                        <p class="">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean egestas magna at porttitor vehicula nullam augue.</p>
                                        <div class="nicdark_section nicdark_height_20"></div>
                                        <a class="nicdark_display_inline_block nicdark_color_white nicdark_first_font nicdark_bg_green nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="#">READ MORE</a>
                                    </div>
                                </div>
                                <!--END services-->

                            </div>

                            <div class="nicdark_section nicdark_height_20"></div>


                            <div class="grid grid_4 ">
                            
                                <!--START service-->
                                <div class="nicdark_section nicdark_position_relative">
                                    <img alt="" class="nicdark_position_absolute" width="50" src="img/icons/restaurant-elements/icon-salver-grey.svg">
                                    <div class="nicdark_section nicdark_padding_left_70 nicdark_box_sizing_border_box">
                                        <h2><strong>Dedicated Courses</strong></h2>
                                        <div class="nicdark_section nicdark_height_20"></div>
                                        <p class="">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean egestas magna at porttitor vehicula nullam augue.</p>
                                        <div class="nicdark_section nicdark_height_20"></div>
                                        <a class="nicdark_display_inline_block nicdark_color_white nicdark_first_font nicdark_bg_green nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="#">READ MORE</a>
                                    </div>
                                </div>
                                <!--END services-->

                            </div>



                            <div class="grid grid_4 ">
                            
                                <!--START service-->
                                <div class="nicdark_section nicdark_position_relative">
                                    <img alt="" class="nicdark_position_absolute" width="50" src="img/icons/restaurant-elements/icon-vegetarian-grey.svg">
                                    <div class="nicdark_section nicdark_padding_left_70 nicdark_box_sizing_border_box">
                                        <h2><strong>Over 4 k Stuedents</strong></h2>
                                        <div class="nicdark_section nicdark_height_20"></div>
                                        <p class="">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean egestas magna at porttitor vehicula nullam augue.</p>
                                        <div class="nicdark_section nicdark_height_20"></div>
                                        <a class="nicdark_display_inline_block nicdark_color_white nicdark_first_font nicdark_bg_green nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="#">READ MORE</a>
                                    </div>
                                </div>
                                <!--END services-->

                            </div>

                            <div class="grid grid_4 ">
                            
                                <!--START service-->
                                <div class="nicdark_section nicdark_position_relative">
                                    <img alt="" class="nicdark_position_absolute" width="50" src="img/icons/restaurant-elements/icon-wifi-connection-grey.svg">
                                    <div class="nicdark_section nicdark_padding_left_70 nicdark_box_sizing_border_box">
                                        <h2><strong>24 H Support</strong></h2>
                                        <div class="nicdark_section nicdark_height_20"></div>
                                        <p class="">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean egestas magna at porttitor vehicula nullam augue.</p>
                                        <div class="nicdark_section nicdark_height_20"></div>
                                        <a class="nicdark_display_inline_block nicdark_color_white nicdark_first_font nicdark_bg_green nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="#">READ MORE</a>
                                    </div>
                                </div>
                                <!--END services-->

                            </div>

                        
                    
                        </div>

                    </div>



                    <div class="nicdark_section nicdark_height_50"></div>



                    <?php include "include/sections/parallax-contact.php"; ?>


                
                    <?php include "include/footer/footer-2.php"; ?>




            </div>
        </div>


        
        <?php include "include/footer/footer.php"; ?>