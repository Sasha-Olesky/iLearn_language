<?php include "include/header/header.php"; ?>


        <?php include "include/header/navigation-4.php"; ?>


        <?php include "include/slider/slider-2.php"; ?>


        <?php include "include/sections/focus-images.php"; ?>
       

        <div class="nicdark_section nicdark_height_30"></div>



        <div class="nicdark_section ">

            <!--start nicdark_container-->
            <div class="nicdark_container nicdark_clearfix">


                <div class="grid grid_12">
                    <h1 class="nicdark_font_size_50"><strong>Our Courses</strong></h1>
                    <div class="nicdark_section nicdark_height_10"></div>
                    <h3 class=" nicdark_color_grey">The Best In Our School</h3>
                </div>
                
                <?php include "include/sections/courses-3.php"; ?>

            </div>
            <!--end container-->

        </div>
        
            

        <div class="nicdark_section nicdark_height_50"></div>

        
        <?php include "include/sections/parallax-half-image.php"; ?>


        <?php include "include/sections/logos-dark.php"; ?>


        <div class="nicdark_section nicdark_height_50"></div>


        <?php include "include/sections/blog.php"; ?>
        

        <div class="nicdark_section nicdark_height_50"></div>  


        <?php include "include/sections/parallax-contact.php"; ?>


        <?php include "include/footer/footer-2.php"; ?>


    </div>
</div>


        
<?php include "include/footer/footer.php"; ?>