<?php include "include/header/header.php"; ?>


        <?php include "include/header/navigation-5.php"; ?>

               
        <?php include "include/slider/slider-3.php"; ?>


        <div class="nicdark_section nicdark_height_50"></div>


        <?php include "include/sections/courses-4.php"; ?>


        <div class="nicdark_section nicdark_height_50"></div>


        <?php include "include/sections/parallax-services.php"; ?>


        <div class="nicdark_section nicdark_height_50"></div>


        <?php include "include/sections/focus-teachers.php"; ?>
            

        <div class="nicdark_section nicdark_height_50"></div>


        <?php include "include/sections/prices.php"; ?>              


        <div class="nicdark_section nicdark_height_50"></div>


        <?php include "include/sections/parallax-right-form.php"; ?> 


        <?php include "include/sections/logos-dark.php"; ?> 


        <?php include "include/footer/footer-2.php"; ?>


    </div>
</div>



<?php include "include/footer/footer.php"; ?>