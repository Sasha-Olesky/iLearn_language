<?php include "include/header/header.php"; ?>







                <?php include "include/header/navigation-2.php"; ?>






                       
                <div class="nicdark_section nicdark_background_size_cover nicdark_background_position_center_bottom" style="background-image:url(img/parallax/img4.png);">

                    <div class="nicdark_section nicdark_bg_greydark_alpha_gradient_2">

                        


                        <!--start nicdark_container-->
                        <div class="nicdark_container nicdark_clearfix">


                            <div class="nicdark_section nicdark_height_200"></div>

                            <div class="grid grid_12">
                                <strong class="nicdark_color_white nicdark_font_size_60 nicdark_first_font nicdark_font_size_40_responsive">Courses Comparision</strong>
                                <div class="nicdark_section nicdark_height_20"></div>
                            </div>

                            


                        </div>
                        <!--end container-->

                    </div>

                </div>




               
                <div class="nicdark_section nicdark_bg_grey nicdark_border_bottom_1_solid_grey">

                    <!--start nicdark_container-->
                    <div class="nicdark_container nicdark_clearfix">

                        <div class="grid grid_12">


                            
                            <a href="#">Home</a>
                            <img alt="" class="nicdark_margin_left_10 nicdark_margin_right_10" width="10" src="img/icons/icon-next-grey.svg">
                            <a href="#">Pages</a>
                            <img alt="" class="nicdark_margin_left_10 nicdark_margin_right_10" width="10" src="img/icons/icon-next-grey.svg">
                            <a href="#">Compare</a>
                            


                        </div>

                
                    </div>
                    <!--end container-->

                </div>




                <div class="nicdark_section nicdark_height_50"></div>



                    
                <div class="nicdark_section ">

                    <!--start nicdark_container-->
                    <div class="nicdark_container nicdark_clearfix">

                        <div class="grid grid_12 ">

                            <!--START table-->
                            <table class="nicdark_display_none_all_responsive">
                                <tr>
                                    <td class="nicdark_padding_10 nicdark_width_25_percentage">
                                        <a class="nicdark_display_inline_block nicdark_color_white nicdark_bg_orange nicdark_padding_5 nicdark_border_radius_3 nicdark_font_size_12" href="#">COMPARE</a>
                                        <div class="nicdark_section nicdark_height_10"></div>
                                        <h1 class="nicdark_font_size_50"><strong>Compare Dishes</strong></h1>   
                                    </td>
                                    <td class="nicdark_padding_10 nicdark_width_25_percentage">

                                        <!--start image-->
                                        <div class="nicdark_section nicdark_position_relative">
                                            
                                            <img alt="" class="nicdark_section" src="img/courses/img1.png">

                                            <div class="nicdark_bg_greydark_alpha_gradient nicdark_position_absolute nicdark_left_0 nicdark_height_100_percentage nicdark_width_100_percentage nicdark_padding_20 nicdark_box_sizing_border_box">
                                                <div class="nicdark_position_absolute nicdark_right_20 nicdark_bottom_20">
                                                    <img alt="" width="20" src="img/icons/icon-trash.svg">   
                                                </div>

                                            </div>

                                        </div>
                                        <!--END image-->

                                        <div class="nicdark_section nicdark_height_20"></div>

                                        <table class="nicdark_section">
                                            <tbody>
                                                <tr>
                                                    <td><h3>Learn Sushi</h3></td>
                                                    <td class="nicdark_text_align_right">
                                                        <a class="nicdark_display_inline_block nicdark_color_white nicdark_bg_green nicdark_first_font nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="#">USD 150</a>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>


                                    </td>
                                    <td class="nicdark_padding_10 nicdark_width_25_percentage">

                                        <!--start image-->
                                        <div class="nicdark_section nicdark_position_relative">
                                            
                                            <img alt="" class="nicdark_section" src="img/courses/img2.png">

                                            <div class="nicdark_bg_greydark_alpha_gradient nicdark_position_absolute nicdark_left_0 nicdark_height_100_percentage nicdark_width_100_percentage nicdark_padding_20 nicdark_box_sizing_border_box">
                                                <div class="nicdark_position_absolute nicdark_right_20 nicdark_bottom_20">
                                                    <img alt="" width="20" src="img/icons/icon-trash.svg">   
                                                </div>

                                            </div>

                                        </div>
                                        <!--END image-->

                                        <div class="nicdark_section nicdark_height_20"></div>

                                        <table class="nicdark_section">
                                            <tbody>
                                                <tr>
                                                    <td><h3>Italian Pizza</h3></td>
                                                    <td class="nicdark_text_align_right">
                                                        <a class="nicdark_display_inline_block nicdark_color_white nicdark_bg_red nicdark_first_font nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="#">FREE</a>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>


                                    </td>
                                    <td class="nicdark_padding_10 nicdark_width_25_percentage">

                                        <!--start image-->
                                        <div class="nicdark_section nicdark_position_relative">
                                            
                                            <img alt="" class="nicdark_section" src="img/courses/img3.png">

                                            <div class="nicdark_bg_greydark_alpha_gradient nicdark_position_absolute nicdark_left_0 nicdark_height_100_percentage nicdark_width_100_percentage nicdark_padding_20 nicdark_box_sizing_border_box">
                                                <div class="nicdark_position_absolute nicdark_right_20 nicdark_bottom_20">
                                                    <img alt="" width="20" src="img/icons/icon-trash.svg">   
                                                </div>

                                            </div>

                                        </div>
                                        <!--END image-->

                                        <div class="nicdark_section nicdark_height_20"></div>

                                        <table class="nicdark_section">
                                            <tbody>
                                                <tr>
                                                    <td><h3>Learn Pasta</h3></td>
                                                    <td class="nicdark_text_align_right">
                                                        <a class="nicdark_display_inline_block nicdark_color_white nicdark_bg_green nicdark_first_font nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="#">USD 150</a>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>

                                    </td>
                                </tr>
                            </table>
                            <!--END table-->



                            <div class="nicdark_width_25_percentage nicdark_display_none_all_responsive nicdark_width_100_percentage_responsive nicdark_float_left nicdark_padding_10 nicdark_box_sizing_border_box">

                                <!--START table-->
                                <table class="nicdark_section">
                                    <tr class="nicdark_border_bottom_2_solid_grey">
                                        <td class="nicdark_padding_10">
                                            <p class=" nicdark_color_greydark">Max Availability</p>    
                                        </td>
                                    </tr>
                                    <tr  class="nicdark_border_bottom_2_solid_grey">
                                        <td class="nicdark_padding_10">
                                            <p class=" nicdark_color_greydark">Teacher</p>    
                                        </td>
                                    </tr>
                                    <tr  class="nicdark_border_bottom_2_solid_grey">
                                        <td class="nicdark_padding_10">
                                            <p class=" nicdark_color_greydark">Start Date</p>    
                                        </td>
                                    </tr>
                                    <tr  class="nicdark_border_bottom_2_solid_grey">
                                        <td class="nicdark_padding_10">
                                            <p class=" nicdark_color_greydark">Category</p>    
                                        </td>
                                    </tr>
                                    <tr class="nicdark_border_bottom_2_solid_grey">
                                        <td class="nicdark_padding_10">
                                            <p class=" nicdark_color_greydark">Location</p>    
                                        </td>
                                    </tr>
                                    <tr  class="nicdark_border_bottom_2_solid_grey">
                                        <td class="nicdark_padding_10">
                                            <p class=" nicdark_color_greydark">Typology</p>    
                                        </td>
                                    </tr>
                                    <tr  class="nicdark_border_bottom_2_solid_grey">
                                        <td class="nicdark_padding_10">
                                            <p class=" nicdark_color_greydark">Duration</p>    
                                        </td>
                                    </tr>
                                    <tr  class="nicdark_border_bottom_2_solid_grey">
                                        <td class="nicdark_padding_10">
                                            <p class=" nicdark_color_greydark">Price</p>    
                                        </td>
                                    </tr>
                                </table>
                                <!--END table-->

                            </div>





                            <div class="nicdark_width_25_percentage nicdark_width_100_percentage_responsive nicdark_float_left nicdark_padding_10 nicdark_box_sizing_border_box">

                                
                                <!--Responsive-->
                                <div class="nicdark_section nicdark_display_none nicdark_display_block_responsive">
                                    
                                    <!--image-->
                                    <div class="nicdark_section nicdark_position_relative">
                                                
                                        <img alt="" class="nicdark_section" src="img/courses/img1.png">

                                        <div class="nicdark_bg_greydark_alpha_gradient nicdark_position_absolute nicdark_left_0 nicdark_height_100_percentage nicdark_width_100_percentage nicdark_padding_20 nicdark_box_sizing_border_box">
                                            <div class="nicdark_position_absolute nicdark_right_20 nicdark_bottom_20">
                                                <img alt="" width="20" src="img/icons/icon-trash.svg">   
                                            </div>

                                        </div>

                                    </div>
                                    <!--END image-->
                                    <div class="nicdark_section nicdark_height_20"></div>
                                    <!--title-->
                                    <table class="nicdark_section">
                                        <tbody>
                                            <tr>
                                                <td><h3>Learn Sushi</h3></td>
                                                <td class="nicdark_text_align_right">
                                                    <a class="nicdark_display_inline_block nicdark_color_white nicdark_bg_green nicdark_first_font nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="#">USD 150</a>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <!--END title-->


                                </div>
                                <!--Responsive-->


                                <!--START table-->
                                <table class="nicdark_section">
                                    <tr class="nicdark_border_bottom_2_solid_grey">
                                        <td class="nicdark_padding_10">
                                            <p>20</p>    
                                        </td>
                                    </tr>
                                    <tr  class="nicdark_border_bottom_2_solid_grey">
                                        <td class="nicdark_padding_10">
                                            <p>John Doe</p>    
                                        </td>
                                    </tr>
                                    <tr  class="nicdark_border_bottom_2_solid_grey">
                                        <td class="nicdark_padding_10">
                                            <p>21/12/2016</p>    
                                        </td>
                                    </tr>
                                    <tr  class="nicdark_border_bottom_2_solid_grey">
                                        <td class="nicdark_padding_10">
                                            <p>Vegan Dishes</p>    
                                        </td>
                                    </tr>
                                    <tr class="nicdark_border_bottom_2_solid_grey">
                                        <td class="nicdark_padding_10">
                                            <p>Milan ( IT )</p>    
                                        </td>
                                    </tr>
                                    <tr  class="nicdark_border_bottom_2_solid_grey">
                                        <td class="nicdark_padding_10">
                                            <p>Free</p>    
                                        </td>
                                    </tr>
                                    <tr  class="nicdark_border_bottom_2_solid_grey">
                                        <td class="nicdark_padding_10">
                                            <p>8 Hours</p>    
                                        </td>
                                    </tr>
                                    <tr  class="nicdark_border_bottom_2_solid_grey">
                                        <td class="nicdark_padding_10">
                                            <p>20,00 $</p>    
                                        </td>
                                    </tr>
                                    <tr  class="">
                                        <td class="nicdark_padding_13_10">
                                            <div class="nicdark_section nicdark_height_20"></div>
                                            <a class="nicdark_display_inline_block nicdark_margin_right_10 nicdark_bg_grey nicdark_border_1_solid_grey nicdark_first_font nicdark_padding_5 nicdark_border_radius_3 nicdark_font_size_12" href="#">FOOD</a>  
                                            <a class="nicdark_display_inline_block nicdark_margin_right_10 nicdark_bg_grey nicdark_border_1_solid_grey nicdark_first_font nicdark_padding_5 nicdark_border_radius_3 nicdark_font_size_12" href="#">ASIAN</a> 
                                            <a class="nicdark_display_inline_block nicdark_margin_right_10 nicdark_bg_grey nicdark_border_1_solid_grey nicdark_first_font nicdark_padding_5 nicdark_border_radius_3 nicdark_font_size_12" href="#">PASTA</a>
                                        </td>
                                    </tr>
                                </table>
                                <!--END table-->


                                <div class="nicdark_section nicdark_height_5"></div>

                                <div class="nicdark_width_50_percentage nicdark_float_left">
                                    <div class="nicdark_display_table nicdark_float_left">
                                        <img alt="" class="nicdark_margin_left_10 nicdark_margin_right_10 nicdark_display_table_cell nicdark_vertical_align_middle nicdark_border_radius_100_percentage" width="25" src="img/avatar/avatar-chef-1.png">
                                        <p class="nicdark_display_table_cell nicdark_vertical_align_middle nicdark_font_size_15">John Doe</p>
                                    </div> 
                                </div>
                                <div class="nicdark_width_50_percentage nicdark_float_left nicdark_text_align_right">
                                    <div class="nicdark_section nicdark_height_3"></div>
                                    <img alt="" class="" width="15" src="img/icons/icon-star-full.svg">
                                    <img alt="" class="" width="15" src="img/icons/icon-star-full.svg">
                                    <img alt="" class="" width="15" src="img/icons/icon-star-full.svg">
                                    <img alt="" class="" width="15" src="img/icons/icon-star-half.svg">
                                    <img alt="" class="nicdark_margin_right_10" width="15" src="img/icons/icon-star.svg">
                                </div>

                            </div>




                            <div class="nicdark_width_25_percentage nicdark_width_100_percentage_responsive nicdark_float_left nicdark_padding_10 nicdark_box_sizing_border_box">

                                
                                <!--Responsive-->
                                <div class="nicdark_section nicdark_display_none nicdark_display_block_responsive">
                                    
                                    <div class="nicdark_section nicdark_height_20"></div>

                                    <!--image-->
                                    <div class="nicdark_section nicdark_position_relative">
                                                
                                        <img alt="" class="nicdark_section" src="img/courses/img2.png">

                                        <div class="nicdark_bg_greydark_alpha_gradient nicdark_position_absolute nicdark_left_0 nicdark_height_100_percentage nicdark_width_100_percentage nicdark_padding_20 nicdark_box_sizing_border_box">
                                            <div class="nicdark_position_absolute nicdark_right_20 nicdark_bottom_20">
                                                <img alt="" width="20" src="img/icons/icon-trash.svg">   
                                            </div>

                                        </div>

                                    </div>
                                    <!--END image-->
                                    <div class="nicdark_section nicdark_height_20"></div>
                                    <!--title-->
                                    <table class="nicdark_section">
                                        <tbody>
                                            <tr>
                                                <td><h3>Maccheroni Course</h3></td>
                                                <td class="nicdark_text_align_right">
                                                    <a class="nicdark_display_inline_block nicdark_color_white nicdark_bg_green nicdark_first_font nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="#">USD 150</a>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <!--END title-->


                                </div>


                                <!--START table-->
                                <table class="nicdark_section">
                                     <tr class="nicdark_border_bottom_2_solid_grey">
                                        <td class="nicdark_padding_10">
                                            <p>80</p>    
                                        </td>
                                    </tr>
                                    <tr  class="nicdark_border_bottom_2_solid_grey">
                                        <td class="nicdark_padding_10">
                                            <p>Jenny Black</p>    
                                        </td>
                                    </tr>
                                    <tr  class="nicdark_border_bottom_2_solid_grey">
                                        <td class="nicdark_padding_10">
                                            <p>24/03/2016</p>    
                                        </td>
                                    </tr>
                                    <tr  class="nicdark_border_bottom_2_solid_grey">
                                        <td class="nicdark_padding_10">
                                            <p>Asian Dishes</p>    
                                        </td>
                                    </tr>
                                    <tr class="nicdark_border_bottom_2_solid_grey">
                                        <td class="nicdark_padding_10">
                                            <p>New York ( US )</p>    
                                        </td>
                                    </tr>
                                    <tr  class="nicdark_border_bottom_2_solid_grey">
                                        <td class="nicdark_padding_10">
                                            <p>Premium</p>    
                                        </td>
                                    </tr>
                                    <tr  class="nicdark_border_bottom_2_solid_grey">
                                        <td class="nicdark_padding_10">
                                            <p>24 Hours</p>    
                                        </td>
                                    </tr>
                                    <tr  class="nicdark_border_bottom_2_solid_grey">
                                        <td class="nicdark_padding_10">
                                            <p>70,00 $</p>    
                                        </td>
                                    </tr>
                                    <tr  class="">
                                        <td class="nicdark_padding_13_10">
                                            <div class="nicdark_section nicdark_height_20"></div>
                                            <a class="nicdark_display_inline_block nicdark_margin_right_10 nicdark_bg_grey nicdark_border_1_solid_grey nicdark_first_font nicdark_padding_5 nicdark_border_radius_3 nicdark_font_size_12" href="#">FREE</a> 
                                            <a class="nicdark_display_inline_block nicdark_margin_right_10 nicdark_bg_grey nicdark_border_1_solid_grey nicdark_first_font nicdark_padding_5 nicdark_border_radius_3 nicdark_font_size_12" href="#">PASTA</a> 
                                            <a class="nicdark_display_inline_block nicdark_margin_right_10 nicdark_bg_grey nicdark_border_1_solid_grey nicdark_first_font nicdark_padding_5 nicdark_border_radius_3 nicdark_font_size_12" href="#">PIZZA</a>
                                        </td>
                                    </tr>
                                </table>
                                <!--END table-->


                                <div class="nicdark_section nicdark_height_10"></div>

                                <div class="nicdark_width_50_percentage nicdark_float_left">
                                    <div class="nicdark_display_table nicdark_float_left">
                                        <img alt="" class="nicdark_margin_left_10 nicdark_margin_right_10 nicdark_display_table_cell nicdark_vertical_align_middle nicdark_border_radius_100_percentage" width="25" src="img/avatar/avatar-chef-1.png">
                                        <p class="nicdark_display_table_cell nicdark_vertical_align_middle nicdark_font_size_15">John Doe</p>
                                    </div> 
                                </div>
                                <div class="nicdark_width_50_percentage nicdark_float_left nicdark_text_align_right">
                                    <div class="nicdark_section nicdark_height_3"></div>
                                    <img alt="" class="" width="15" src="img/icons/icon-star-full.svg">
                                    <img alt="" class="" width="15" src="img/icons/icon-star-full.svg">
                                    <img alt="" class="" width="15" src="img/icons/icon-star-full.svg">
                                    <img alt="" class="" width="15" src="img/icons/icon-star-full.svg">
                                    <img alt="" class="nicdark_margin_right_10" width="15" src="img/icons/icon-star.svg">
                                </div>

                            </div>



                            <div class="nicdark_width_25_percentage nicdark_width_100_percentage_responsive nicdark_float_left nicdark_padding_10 nicdark_box_sizing_border_box">

                                   
                                <!--Responsive-->
                                <div class="nicdark_section nicdark_display_none nicdark_display_block_responsive">
                                    
                                    <div class="nicdark_section nicdark_height_20"></div>

                                    <!--image-->
                                    <div class="nicdark_section nicdark_position_relative">
                                                
                                        <img alt="" class="nicdark_section" src="img/courses/img3.png">

                                        <div class="nicdark_bg_greydark_alpha_gradient nicdark_position_absolute nicdark_left_0 nicdark_height_100_percentage nicdark_width_100_percentage nicdark_padding_20 nicdark_box_sizing_border_box">
                                            <div class="nicdark_position_absolute nicdark_right_20 nicdark_bottom_20">
                                                <img alt="" width="20" src="img/icons/icon-trash.svg">   
                                            </div>

                                        </div>

                                    </div>
                                    <!--END image-->
                                    <div class="nicdark_section nicdark_height_20"></div>
                                    <!--title-->
                                    <table class="nicdark_section">
                                        <tbody>
                                            <tr>
                                                <td><h3>Learn Sushi</h3></td>
                                                <td class="nicdark_text_align_right">
                                                    <a class="nicdark_display_inline_block nicdark_color_white nicdark_bg_green nicdark_first_font nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="#">USD 150</a>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <!--END title-->


                                </div> 


                                <!--START table-->
                                <table class="nicdark_section">
                                     <tr class="nicdark_border_bottom_2_solid_grey">
                                        <td class="nicdark_padding_10">
                                            <p>90</p>    
                                        </td>
                                    </tr>
                                    <tr  class="nicdark_border_bottom_2_solid_grey">
                                        <td class="nicdark_padding_10">
                                            <p>Nick Hope</p>    
                                        </td>
                                    </tr>
                                    <tr  class="nicdark_border_bottom_2_solid_grey">
                                        <td class="nicdark_padding_10">
                                            <p>08/11/2016</p>    
                                        </td>
                                    </tr>
                                    <tr  class="nicdark_border_bottom_2_solid_grey">
                                        <td class="nicdark_padding_10">
                                            <p>Vegetarian Food</p>    
                                        </td>
                                    </tr>
                                    <tr class="nicdark_border_bottom_2_solid_grey">
                                        <td class="nicdark_padding_10">
                                            <p>Sidney ( AU )</p>    
                                        </td>
                                    </tr>
                                    <tr  class="nicdark_border_bottom_2_solid_grey">
                                        <td class="nicdark_padding_10">
                                            <p>Premium</p>    
                                        </td>
                                    </tr>
                                    <tr  class="nicdark_border_bottom_2_solid_grey">
                                        <td class="nicdark_padding_10">
                                            <p>5 Hours</p>    
                                        </td>
                                    </tr>
                                    <tr  class="nicdark_border_bottom_2_solid_grey">
                                        <td class="nicdark_padding_10">
                                            <p>80,00 $</p>    
                                        </td>
                                    </tr>
                                    <tr  class="">
                                        <td class="nicdark_padding_13_10">
                                            <div class="nicdark_section nicdark_height_20"></div>
                                            <a class="nicdark_display_inline_block nicdark_margin_right_10 nicdark_bg_grey nicdark_border_1_solid_grey nicdark_first_font nicdark_padding_5 nicdark_border_radius_3 nicdark_font_size_12" href="#">SUSHI</a>  
                                            <a class="nicdark_display_inline_block nicdark_margin_right_10 nicdark_bg_grey nicdark_border_1_solid_grey nicdark_first_font nicdark_padding_5 nicdark_border_radius_3 nicdark_font_size_12" href="#">FISH</a> 
                                            <a class="nicdark_display_inline_block nicdark_margin_right_10 nicdark_bg_grey nicdark_border_1_solid_grey nicdark_first_font nicdark_padding_5 nicdark_border_radius_3 nicdark_font_size_12" href="#">CAKE</a>
                                        </td>
                                    </tr>
                                </table>
                                <!--END table-->



                                <div class="nicdark_section nicdark_height_10"></div>

                                <div class="nicdark_width_50_percentage nicdark_float_left">
                                    <div class="nicdark_display_table nicdark_float_left">
                                        <img alt="" class="nicdark_margin_left_10 nicdark_margin_right_10 nicdark_display_table_cell nicdark_vertical_align_middle nicdark_border_radius_100_percentage" width="25" src="img/avatar/avatar-chef-1.png">
                                        <p class="nicdark_display_table_cell nicdark_vertical_align_middle nicdark_font_size_15">John Doe</p>
                                    </div> 
                                </div>
                                <div class="nicdark_width_50_percentage nicdark_float_left nicdark_text_align_right">
                                    <div class="nicdark_section nicdark_height_3"></div>
                                    <img alt="" class="" width="15" src="img/icons/icon-star-full.svg">
                                    <img alt="" class="" width="15" src="img/icons/icon-star-full.svg">
                                    <img alt="" class="" width="15" src="img/icons/icon-star-full.svg">
                                    <img alt="" class="" width="15" src="img/icons/icon-star-full.svg">
                                    <img alt="" class="nicdark_margin_right_10" width="15" src="img/icons/icon-star-half.svg">
                                </div>

                            </div>

                            
                        </div>

                    </div>
                    <!--end container-->

                </div>


                <div class="nicdark_section nicdark_height_50"></div>



                <?php include "include/footer/footer-2.php"; ?>









                


            </div>
        </div>


        
        <?php include "include/footer/footer.php"; ?>