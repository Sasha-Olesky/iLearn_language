<?php include "include/header/header.php"; ?>



                


                <?php include "include/header/navigation-2.php"; ?>


  
                

                <div class="nicdark_section nicdark_background_size_cover nicdark_background_position_center_top" style="background-image:url(img/parallax/img6.png);">

                    <div class="nicdark_section nicdark_bg_greydark_alpha_gradient_2">

                        
                        <!--start nicdark_container-->
                        <div class="nicdark_container nicdark_clearfix">


                            <div class="nicdark_section nicdark_height_200"></div>

                            <div class="grid grid_12">
                                <strong class="nicdark_color_white nicdark_font_size_60 nicdark_first_font">Courses</strong>
                            </div>

                            <div class="nicdark_section nicdark_height_20"></div>


                        </div>
                        <!--end container-->

                    </div>

                </div>




                

                <div class="nicdark_section nicdark_bg_grey nicdark_border_bottom_1_solid_grey">

                    <!--start nicdark_container-->
                    <div class="nicdark_container nicdark_clearfix">

                        <div class="grid grid_12">

                            <a href="#">Home</a>
                            <img alt="" class="nicdark_margin_left_10 nicdark_margin_right_10" width="10" src="img/icons/icon-next-grey.svg">
                            <a href="#">Courses</a>
                            <img alt="" class="nicdark_margin_left_10 nicdark_margin_right_10" width="10" src="img/icons/icon-next-grey.svg">
                            <a href="#">Courses</a>
                            
                        </div>

                    </div>
                    <!--end container-->

                </div>




                <div class="nicdark_section nicdark_height_50"></div>



                    
                <div class="nicdark_section ">

                    <!--start nicdark_container-->
                    <div class="nicdark_container nicdark_clearfix">


                        <!--<div class="nicdark_width_100_percentage">

                            <div class="nicdark_section nicdark_box_sizing_border_box nicdark_padding_15">
                                <h2><strong>Find Your Course</strong></h2>
                                <div class="nicdark_section nicdark_height_20"></div>
                            </div>


                            <div class="nicdark_section nicdark_box_sizing_border_box">
                                <div class="nicdark_section">
                                
                                    <div class="nicdark_section">
                                        <div class="nicdark_width_33_percentage nicdark_padding_15 nicdark_box_sizing_border_box nicdark_float_left nicdark_position_relative">
                                            <img alt="" class="nicdark_position_absolute nicdark_top_5 nicdark_left_0 nicdark_margin_top_20 nicdark_margin_left_15" width="15" src="img/icons/icon-pen.svg">
                                            <input class="nicdark_padding_left_25 nicdark_border_width_2 nicdark_background_none nicdark_border_top_width_0 nicdark_border_right_width_0 nicdark_border_left_width_0" type="text" placeholder="Keyword">
                                        </div>
                                        <div class="nicdark_width_33_percentage nicdark_padding_15 nicdark_box_sizing_border_box nicdark_float_left nicdark_position_relative">
                                            <img alt="" class="nicdark_position_absolute nicdark_top_5 nicdark_left_0 nicdark_margin_top_20 nicdark_margin_left_15" width="15" src="img/icons/icon-list.svg">
                                            <input class="nicdark_padding_left_25 nicdark_border_width_2 nicdark_background_none nicdark_border_top_width_0 nicdark_border_right_width_0 nicdark_border_left_width_0" type="text" placeholder="Food Courses">
                                        </div>
                                        <div class="nicdark_width_33_percentage nicdark_padding_15 nicdark_box_sizing_border_box nicdark_float_left nicdark_position_relative">
                                            <img alt="" class="nicdark_position_absolute nicdark_top_5 nicdark_left_0 nicdark_margin_top_20 nicdark_margin_left_15" width="15" src="img/icons/icon-star.svg">
                                            <input class="nicdark_padding_left_25 nicdark_border_width_2 nicdark_background_none nicdark_border_top_width_0 nicdark_border_right_width_0 nicdark_border_left_width_0" type="text" placeholder="Premium">
                                        </div>
                                    </div>
                                    <div class="nicdark_section">
                                        <div class="nicdark_width_33_percentage nicdark_padding_15 nicdark_box_sizing_border_box nicdark_float_left nicdark_position_relative">
                                            <img alt="" class="nicdark_position_absolute nicdark_top_5 nicdark_left_0 nicdark_margin_top_20 nicdark_margin_left_15" width="15" src="img/icons/icon-level.svg">
                                            <input class="nicdark_padding_left_25 nicdark_border_width_2 nicdark_background_none nicdark_border_top_width_0 nicdark_border_right_width_0 nicdark_border_left_width_0" type="text" placeholder="Medium Level">
                                        </div>
                                        <div class="nicdark_width_33_percentage nicdark_padding_15 nicdark_box_sizing_border_box nicdark_float_left nicdark_position_relative">
                                            <img alt="" class="nicdark_position_absolute nicdark_top_5 nicdark_left_0 nicdark_margin_top_20 nicdark_margin_left_15" width="15" src="img/icons/icon-clock-grey.svg">
                                            <input class="nicdark_padding_left_25 nicdark_border_width_2 nicdark_background_none nicdark_border_top_width_0 nicdark_border_right_width_0 nicdark_border_left_width_0" type="text" placeholder="8 Hours">
                                        </div>

                                        <div class="nicdark_width_33_percentage nicdark_padding_15 nicdark_box_sizing_border_box nicdark_float_left nicdark_position_relative">
                                            <a class="nicdark_display_inline_block nicdark_text_align_center nicdark_box_sizing_border_box nicdark_width_100_percentage nicdark_color_white nicdark_bg_green nicdark_first_font nicdark_padding_10_20 nicdark_border_radius_3 " href="#">SEARCH</a>   
                                        </div>

                                    </div>

                                </div>


                            </div>


                        </div>-->




                        <div class="nicdark_width_100_percentage">



                            <!--START results-->
                            <div class="nicdark_section nicdark_padding_15 nicdark_box_sizing_border_box">
                                <div class="nicdark_section nicdark_box_sizing_border_box ">
                                            
                                    <div class="nicdark_width_100_percentage nicdark_float_left">
                                        <h2><strong>Showing 1-9 of 18 results</strong></h2>
                                    </div> 


                                    <div class="nicdark_section nicdark_height_10"></div>

                                    
                                    <div class="nicdark_width_70_percentage nicdark_float_left nicdark_width_100_percentage_all_iphone">

                                        <div class="nicdark_section nicdark_height_20"></div>

                                        <div class="nicdark_width_50_percentage nicdark_float_left">
                                            <div class="nicdark_section nicdark_box_sizing_border_box nicdark_float_left nicdark_position_relative nicdark_padding_right_20">
                                                <img alt="" class="nicdark_position_absolute nicdark_top_5 nicdark_left_0 nicdark_margin_top_5" width="15" src="img/icons/icon-pen.svg">
                                                <input class="nicdark_padding_left_25 nicdark_border_width_2 nicdark_background_none nicdark_border_top_width_0 nicdark_border_right_width_0 nicdark_border_left_width_0" type="text" placeholder="Keyword">
                                            </div> 
                                        </div>
                                        <div class="nicdark_width_50_percentage nicdark_float_left">
                                            <div class="nicdark_float_left nicdark_width_100_percentage_all_iphone">
                                                <a class="nicdark_bg_white_hover nicdark_color_green_hover nicdark_border_2_solid_green nicdark_transition_all_08_ease nicdark_display_inline_block nicdark_text_align_center nicdark_box_sizing_border_box nicdark_width_100_percentage nicdark_color_white nicdark_bg_green nicdark_first_font nicdark_padding_10_20 nicdark_border_radius_3 " href="courses.php">SEARCH</a>   
                                            </div>
                                        </div>
                                    </div> 

                                
                                    <div class="nicdark_width_30_percentage nicdark_float_left nicdark_text_align_right nicdark_width_100_percentage_all_iphone">

                                        <div class="nicdark_section nicdark_height_20"></div>

                                        <div class="nicdark_display_inline_block nicdark_bg_orange nicdark_border_1_solid_orange nicdark_padding_8 nicdark_margin_right_10 nicdark_border_radius_3">
                                            <a class="nicdark_tooltip_jquery" title="Advanced Settings" href="#"><img alt="" class="nicdark_float_left" width="23" src="img/icons/icon-settings-white.svg"></a>
                                        </div>

                                        <div class="nicdark_display_inline_block nicdark_bg_green nicdark_border_1_solid_green nicdark_padding_8 nicdark_margin_right_10 nicdark_border_radius_3">
                                            <a class="nicdark_tooltip_jquery" title="List View" href="#"><img alt="" class="nicdark_float_left" width="23" src="img/icons/icon-list-white.svg"></a>
                                        </div>

                                        <div class="nicdark_display_inline_block nicdark_border_1_solid_grey_2 nicdark_padding_8 nicdark_border_radius_3">
                                            <a class="nicdark_tooltip_jquery" title="Grid View" href="#"><img alt="" class="nicdark_float_left" width="23" src="img/icons/icon-grid-grey.svg"></a>
                                        </div>

                                    </div> 
                                    
                                </div>
                            </div>
                            <!--END results-->

                        

                            <?php include "include/sections/courses-3.php"; ?>

                            


                            <div class="nicdark_section nicdark_height_50"></div>


                            <div class="nicdark_section nicdark_text_align_center">
                                <a class="nicdark_display_inline_block nicdark_color_greydark nicdark_first_font nicdark_padding_10 nicdark_font_size_20" href="#"><strong>1</strong></a>
                                <a class="nicdark_display_inline_block nicdark_first_font nicdark_padding_10 nicdark_font_size_20" href="#"><strong>2</strong></a>
                                <a class="nicdark_display_inline_block nicdark_first_font nicdark_padding_10 nicdark_font_size_20" href="#"><strong>3</strong></a>
                                <a class="nicdark_display_inline_block nicdark_first_font nicdark_padding_10 nicdark_font_size_20" href="#"><strong>4</strong></a>
                                <a class="nicdark_display_inline_block nicdark_first_font nicdark_padding_10 nicdark_font_size_20" href="#"><strong>5</strong></a>                                
                            </div>


                        </div>


                    </div>
                    <!--end container-->

                </div>


                <div class="nicdark_section nicdark_height_70"></div>



                <?php include "include/footer/footer-2.php"; ?>









                


            </div>
        </div>


        
        <?php include "include/footer/footer.php"; ?>