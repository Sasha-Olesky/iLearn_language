<?php include "include/header/header.php"; ?>


        <?php include "include/header/navigation-2.php"; ?>


        <?php include "include/slider/slider-1.php"; ?>


        <?php include "include/sections/focus-blog-time-search.php"; ?>      


        <div class="nicdark_section nicdark_height_50"></div>

        
        <?php include "include/sections/courses-1.php"; ?>


        <div class="nicdark_section nicdark_height_50"></div>


        <?php include "include/sections/parallax-right-form.php"; ?>


        <?php include "include/sections/services-dark-background.php"; ?>


        <div class="nicdark_section nicdark_height_50"></div>


        <?php include "include/sections/blog.php"; ?>


        <div class="nicdark_section nicdark_height_50"></div>


        <?php include "include/sections/logos-light.php"; ?>


        <?php include "include/footer/footer-2.php"; ?>

    </div>
    <!--END nicdark_site_fullwidth-->

</div>
<!--END nicdark_site-->


        
<?php include "include/footer/footer.php"; ?>