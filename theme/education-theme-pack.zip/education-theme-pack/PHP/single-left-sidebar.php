<?php include "include/header/header.php"; ?>







                <?php include "include/header/navigation-2.php"; ?>






                       
                <div class="nicdark_section nicdark_background_size_cover nicdark_background_position_center_bottom" style="background-image:url(img/parallax/img19.png);">

                    <div class="nicdark_section nicdark_bg_greydark_alpha_gradient_2">

                        


                        <!--start nicdark_container-->
                        <div class="nicdark_container nicdark_clearfix">


                            <div class="nicdark_section nicdark_height_200"></div>


                            <div class="grid grid_12">

                                
                                
                                <strong class="nicdark_color_white nicdark_font_size_40 nicdark_first_font">New Website Online</strong>

                                <div class="nicdark_section nicdark_height_10"></div>

                                <!--START post details-->
                                <div class="nicdark_section">
                                    <div class="nicdark_display_inline_block">

                                        <div class="nicdark_section nicdark_height_10"></div>
                                        <div class="nicdark_section nicdark_position_relative nicdark_padding_right_40 nicdark_box_sizing_border_box">
                                            <img alt="" class="nicdark_position_absolute nicdark_border_radius_100_percentage" width="35" src="img/avatar/avatar-chef-1.png">
                                            <div class="nicdark_section nicdark_padding_left_45 nicdark_box_sizing_border_box">
                                                <div class="nicdark_section nicdark_height_5"></div>
                                                <h3 class="nicdark_color_white">John Doe</h3>
                                            </div>
                                        </div>
                                        <div class="nicdark_section nicdark_height_10"></div>

                                    </div>

                                    <div class="nicdark_display_inline_block">

                                        <div class="nicdark_section nicdark_height_10"></div>
                                        <div class="nicdark_section nicdark_position_relative nicdark_padding_right_40 nicdark_box_sizing_border_box">
                                            <img alt="" class="nicdark_position_absolute" width="30" src="img/icons/icon-calendar.svg">
                                            <div class="nicdark_section nicdark_padding_left_45 nicdark_box_sizing_border_box">
                                                <div class="nicdark_section nicdark_height_5"></div>
                                                <h3 class="nicdark_color_white">21 / 12 / 2017</h3>
                                            </div>
                                        </div>
                                        <div class="nicdark_section nicdark_height_10"></div>

                                    </div>

                                    <div class="nicdark_display_inline_block">

                                        <div class="nicdark_section nicdark_height_10"></div>
                                        <div class="nicdark_section nicdark_position_relative">
                                            <img alt="" class="nicdark_position_absolute" width="30" src="img/icons/icon-clock.svg">
                                            <div class="nicdark_section nicdark_padding_left_45 nicdark_box_sizing_border_box">
                                                <div class="nicdark_section nicdark_height_5"></div>
                                                <h3 class="nicdark_color_white">3 Comments</h3>
                                            </div>
                                        </div>
                                        <div class="nicdark_section nicdark_height_10"></div>

                                    </div>
                                </div>
                                <!--END post details-->

                                <div class="nicdark_section nicdark_height_10"></div>
                                

                            </div>



                        </div>
                        <!--end container-->

                    </div>

                </div>




               
                    <div class="nicdark_section nicdark_bg_grey nicdark_border_bottom_1_solid_grey">

                        <!--start nicdark_container-->
                        <div class="nicdark_container nicdark_clearfix">

                            <div class="grid grid_12">


                                
                                <a href="#">Home</a>
                                <img alt="" class="nicdark_margin_left_10 nicdark_margin_right_10" width="10" src="img/icons/icon-next-grey.svg">
                                <a href="#">Blog</a>
                                <img alt="" class="nicdark_margin_left_10 nicdark_margin_right_10" width="10" src="img/icons/icon-next-grey.svg">
                                <a href="#">Single Post</a>
                                


                            </div>

                    
                        </div>
                        <!--end container-->

                    </div>




                    <div class="nicdark_section nicdark_height_50"></div>



                    <div class="nicdark_section">

                        <!--start nicdark_container-->
                        <div class="nicdark_container nicdark_clearfix">

                                
                            <div class="grid grid_4">
                                <?php include "include/sections/sidebar-1.php"; ?>
                                <div class="nicdark_section nicdark_height_50"></div>
                            </div>

                            <div class="grid grid_8">
                                <?php include "include/sections/blog-single-content.php"; ?>
                                <div class="nicdark_section nicdark_height_50"></div>
                            </div>

                        </div>
                        <!--end container-->

                    </div>








                    <?php include "include/sections/single-bottom-pagination.php"; ?>
                






                <?php include "include/footer/footer-2.php"; ?>









                


            </div>
        </div>


        
        <?php include "include/footer/footer.php"; ?>