<?php include "include/header/header.php"; ?>







                <?php include "include/header/navigation-2.php"; ?>






                       
                <div class="nicdark_section nicdark_background_size_cover nicdark_background_position_center_bottom" style="background-image:url(img/parallax/img1.png);">

                    <div class="nicdark_section nicdark_bg_greydark_alpha_gradient_2">

                        


                        <!--start nicdark_container-->
                        <div class="nicdark_container nicdark_clearfix">


                            <div class="nicdark_section nicdark_height_200"></div>


                            <div class="grid grid_6">


                                <div class="nicdark_display_table nicdark_float_left nicdark_display_none_all_iphone">
                                            
                                    <div class="nicdark_display_table_cell nicdark_vertical_align_middle">
                                        <img alt="" class="nicdark_margin_right_20 nicdark_border_radius_100_percentage " width="150" src="img/avatar/avatar-chef-3.png">
                                    </div>

                                    <div class="nicdark_display_table_cell nicdark_vertical_align_middle">
                                        <strong class="nicdark_color_white nicdark_font_size_40 nicdark_first_font">John Doe</strong>


                                        <div class="nicdark_display_inline_block nicdark_margin_left_20">
                                            <img alt="" width="20" class="nicdark_margin_right_10" src="img/icons/icon-twitter-white.svg">
                                            <img alt="" width="20" class="nicdark_margin_right_10" src="img/icons/icon-pinterest-white.svg">
                                            <img alt="" width="20" class="nicdark_margin_right_10" src="img/icons/icon-linkedin-white.svg">
                                            <img alt="" width="20" class="nicdark_margin_right_10" src="img/icons/icon-google-white.svg">
                                            <img alt="" width="20" class="nicdark_margin_right_10" src="img/icons/icon-instagram-white.svg">
                                        </div>


                                        <div class="nicdark_section nicdark_height_5"></div>
                                        <h3 class="nicdark_color_white">Food Teacher</h3>
                                        <div class="nicdark_section nicdark_height_30"></div>
                                        <a class="nicdark_display_inline_block nicdark_color_white nicdark_border_1_solid_white nicdark_first_font nicdark_padding_10_20 nicdark_border_radius_3 nicdark_margin_right_20 nicdark_transition_all_08_ease nicdark_border_1_solid_green_hover nicdark_bg_green_hover" href="#">FOLLOW ME</a>
                                        <a class="nicdark_display_inline_block nicdark_color_white nicdark_border_1_solid_white nicdark_first_font nicdark_padding_10_20 nicdark_border_radius_3 nicdark_transition_all_08_ease nicdark_border_1_solid_green_hover nicdark_bg_green_hover" href="#">MESSAGE ME</a>
                                    </div>

                                </div>


                                <!--START responsive-->
                                <div class="nicdark_section nicdark_display_none nicdark_display_block_all_iphone nicdark_text_align_center">
                                
                                    <img alt="" class=" nicdark_border_radius_100_percentage " width="100" src="img/avatar/avatar-chef-1.png">
                                    <div class="nicdark_section nicdark_height_10"></div>

                                    <div class="nicdark_section nicdark_text_align_center">
                                        <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-twitter-white.svg">
                                        <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-pinterest-white.svg">
                                        <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-linkedin-white.svg">
                                        <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-google-white.svg">
                                        <img alt="" width="15" class="" src="img/icons/icon-instagram-white.svg">
                                    </div>

                                    <div class="nicdark_section nicdark_height_10"></div>
                                    <h2><strong class="nicdark_color_white nicdark_first_font">John Doe</strong></h2>
                                    <div class="nicdark_section nicdark_height_5"></div>
                                    <h5 class="nicdark_color_white">Food Teacher</h5>

                                    <div class="nicdark_section nicdark_height_20"></div>

                                    <a class="nicdark_display_inline_block nicdark_color_white nicdark_border_1_solid_white nicdark_first_font nicdark_padding_8 nicdark_border_radius_3 nicdark_margin_right_20 nicdark_font_size_13 nicdark_transition_all_08_ease nicdark_border_1_solid_green_hover nicdark_bg_green_hover" href="#">FOLLOW ME</a>
                                    <a class="nicdark_display_inline_block nicdark_color_white nicdark_border_1_solid_white nicdark_first_font nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13 nicdark_transition_all_08_ease nicdark_border_1_solid_green_hover nicdark_bg_green_hover" href="#">MESSAGE ME</a>

                                </div>
                                <!--END responsive-->

                                
                        
                                <div class="nicdark_section nicdark_height_20"></div>
                                

                            </div>




                            <div class="grid grid_6 nicdark_text_align_right nicdark_text_align_left_responsive nicdark_text_align_center_all_iphone">

                                <div class="nicdark_section nicdark_height_80 nicdark_display_none_all_responsive"></div>

                                <div class="nicdark_display_inline_block nicdark_text_align_center  nicdark_margin_right_40">
                                    <h1 class="nicdark_color_white nicdark_font_size_40 nicdark_font_size_20_all_iphone nicdark_line_height_20_all_iphone"><strong>12</strong></h1>
                                    <div class="nicdark_section nicdark_height_5"></div>
                                    <p class="nicdark_color_white nicdark_font_size_10_all_iphone">COURSES</p>
                                </div>

                                <div class="nicdark_display_inline_block nicdark_text_align_center nicdark_margin_right_40">
                                    <h1 class="nicdark_color_white nicdark_font_size_40 nicdark_font_size_20_all_iphone nicdark_line_height_20_all_iphone"><strong>126</strong></h1>
                                    <div class="nicdark_section nicdark_height_5"></div>
                                    <p class="nicdark_color_white nicdark_font_size_10_all_iphone">FOLLOWER</p>
                                </div>

                                <div class="nicdark_display_inline_block nicdark_text_align_center">
                                    <h1 class="nicdark_color_white nicdark_font_size_40 nicdark_font_size_20_all_iphone nicdark_line_height_20_all_iphone"><strong>4,5</strong></h1>
                                    <div class="nicdark_section nicdark_height_5"></div>
                                    <p class="nicdark_color_white nicdark_font_size_10_all_iphone">RATING</p>
                                </div>
                                 
                            </div>




                        </div>
                        <!--end container-->

                    </div>

                </div>




               
                    <div class="nicdark_section nicdark_bg_grey nicdark_border_bottom_1_solid_grey">

                        <!--start nicdark_container-->
                        <div class="nicdark_container nicdark_clearfix">

                            <div class="grid grid_12">


                                
                                <a href="#">Home</a>
                                <img alt="" class="nicdark_margin_left_10 nicdark_margin_right_10" width="10" src="img/icons/icon-next-grey.svg">
                                <a href="#">Teachers</a>
                                <img alt="" class="nicdark_margin_left_10 nicdark_margin_right_10" width="10" src="img/icons/icon-next-grey.svg">
                                <a href="#">John Doe</a>
                                


                            </div>

                    
                        </div>
                        <!--end container-->

                    </div>




                    <div class="nicdark_section nicdark_height_50"></div>



                    <div class="nicdark_section">

                        <!--start nicdark_container-->
                        <div class="nicdark_container nicdark_clearfix">

                            <div class="nicdark_width_66_percentage nicdark_width_100_percentage_responsive nicdark_float_left">

                                <div class="nicdark_section nicdark_padding_15 nicdark_box_sizing_border_box">
                                
                                    <h2><strong>Biography</strong></h2>
                                    <div class="nicdark_section nicdark_height_20"></div>

                                    <div class="nicdark_width_50_percentage nicdark_width_100_percentage_all_iphone nicdark_float_left ">
                                        <p class="nicdark_padding_10 nicdark_padding_0_all_iphone nicdark_padding_left_0"><span class="nicdark_font_size_70 nicdark_float_left nicdark_padding_28 nicdark_line_height_30 nicdark_first_font"><strong>A</strong></span>ivamus volutpat eros pulvinar velit laoreet, sit amet egestas erat dignissim. Sed quis rutrum tellus, sit amet viverra felis. Cras sagittis sem sit amet urna feugiat rutrum. Nam nulla ipsum, venenatis malesuada felis quis, ultricies convallis neque. Pellentesque tristique fringilla tempus.</p>
                                    </div>
                                    <div class="nicdark_width_50_percentage nicdark_width_100_percentage_all_iphone nicdark_float_left">
                                        <p class="nicdark_padding_10 nicdark_padding_0_all_iphone nicdark_padding_right_0">Vivamus volutpat eros pulvinar velit laoreet, sit amet egestas erat dignissim. Sed quis rutrum tellus, sit amet viverra felis. Cras sagittis sem sit amet urna feugiat rutrum. Nam nulla ipsum, venenatis malesuada felis quis, ultricies convallis neque. Pellentesque tristique fringilla tempus.</p>
                                    </div>

                                    <div class="nicdark_section nicdark_height_40"></div>


                                    <div class="nicdark_section">


                                        <!--START tab-->
                                        <div class="nicdark_tabs ui-tabs ui-widget ui-widget-content ui-corner-all">
                                            <ul class="nicdark_list_style_none nicdark_margin_0 nicdark_padding_0 nicdark_section nicdark_border_bottom_2_solid_grey ui-tabs-nav ui-helper-reset ui-helper-clearfix ui-widget-header ui-corner-all" role="tablist">
                                                <li class="nicdark_display_inline_block ui-state-default ui-corner-top ui-tabs-active ui-state-active" role="tab" tabindex="0" aria-controls="tabs-1" aria-labelledby="ui-id-1" aria-selected="true" aria-expanded="true">
                                                    <h4>
                                                        <a class="nicdark_outline_0 nicdark_padding_20 nicdark_padding_right_10 nicdark_display_inline_block nicdark_first_font nicdark_color_greydark ui-tabs-anchor" href="#tabs-1"  tabindex="-1" id="ui-id-1">My Courses</a> 
                                                        <a class="nicdark_display_inline_block nicdark_bg_grey nicdark_margin_right_20 nicdark_border_1_solid_grey nicdark_first_font nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="#">5</a>
                                                    </h4>
                                                </li>
                                                <li class="nicdark_display_inline_block ui-state-default ui-corner-top" role="tab" tabindex="-1" aria-controls="tabs-2" aria-labelledby="ui-id-2" aria-selected="false" aria-expanded="false">
                                                    <h4>
                                                        <a class="nicdark_outline_0 nicdark_padding_20 nicdark_padding_right_10 nicdark_display_inline_block nicdark_first_font nicdark_color_greydark ui-tabs-anchor" href="#tabs-2"  tabindex="-1" id="ui-id-2">Followers</a> 
                                                        <a class="nicdark_display_inline_block nicdark_bg_grey nicdark_margin_right_20 nicdark_border_1_solid_grey nicdark_first_font nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="#">9</a>
                                                    </h4>
                                                </li>
                                                <li class="nicdark_display_inline_block ui-state-default ui-corner-top" role="tab" tabindex="-1" aria-controls="tabs-3" aria-labelledby="ui-id-3" aria-selected="false" aria-expanded="false">
                                                    <h4>
                                                        <a class="nicdark_outline_0 nicdark_padding_20 nicdark_padding_right_10 nicdark_display_inline_block nicdark_first_font nicdark_color_greydark ui-tabs-anchor" href="#tabs-3"  tabindex="-1" id="ui-id-3">My Reviews</a> 
                                                        <a class="nicdark_display_inline_block nicdark_bg_grey nicdark_margin_right_20 nicdark_border_1_solid_grey nicdark_first_font nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="#">3</a>
                                                    </h4>
                                                </li>
                                            </ul>

                                            <div class="nicdark_section nicdark_height_20"></div>

                                            <div class="nicdark_section ui-tabs-panel ui-widget-content ui-corner-bottom" id="tabs-1" aria-labelledby="ui-id-1" role="tabpanel" aria-hidden="false" style="display: block;">


                                                <div class="nicdark_section nicdark_box_sizing_border_box nicdark_overflow_hidden nicdark_overflow_x_auto nicdark_cursor_move_responsive">
                                                    <table class="nicdark_section">
                                                        <thead>
                                                            <tr class="nicdark_border_bottom_1_solid_grey">
                                                                <td class="nicdark_padding_20 nicdark_width_20_percentage">
                                                                    <h6 class="nicdark_text_transform_uppercase">COURSE</h6>    
                                                                </td>
                                                                <td class="nicdark_padding_20 nicdark_width_30_percentage nicdark_display_none_all_iphone">
                                                                        
                                                                </td>
                                                                <td class="nicdark_padding_20 nicdark_width_20_percentage nicdark_display_none_all_iphone">
                                                                    <h6 class="nicdark_text_transform_uppercase">RATING</h6>    
                                                                </td>
                                                                <td class="nicdark_padding_20 nicdark_width_20_percentage">
                                                                    <h6 class="nicdark_text_transform_uppercase">PRICE</h6>    
                                                                </td>
                                                                <td class="nicdark_padding_20 nicdark_width_10_percentage">
                                                                      
                                                                </td>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <tr class="nicdark_border_bottom_1_solid_grey">
                                                                <td class="nicdark_padding_20">  
                                                                    <img alt="" class="nicdark_section" src="img/courses/img1.png"> 
                                                                </td>
                                                                <td class="nicdark_padding_20">  
                                                                    <h4><strong>Learn Sushi Food</strong></h4> 
                                                                </td>
                                                                <td class="nicdark_padding_20 nicdark_display_none_all_iphone">  
                                                                    
                                                                    <img alt="" class="" width="15" src="img/icons/icon-star-full.svg">
                                                                    <img alt="" class="" width="15" src="img/icons/icon-star-full.svg">
                                                                    <img alt="" class="" width="15" src="img/icons/icon-star-full.svg">
                                                                    <img alt="" class="" width="15" src="img/icons/icon-star-half.svg">
                                                                    <img alt="" class="nicdark_margin_right_10" width="15" src="img/icons/icon-star.svg">
                                                                    
                                                                </td>
                                                                <td class="nicdark_padding_20 nicdark_display_none_all_iphone">
                                                                    <p class="nicdark_color_greydark">$ 50,00</p>    
                                                                </td>
                                                                <td class="nicdark_padding_20">   
                                                                    <a class="nicdark_display_inline_block nicdark_color_white nicdark_bg_green nicdark_first_font nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="#">VIEW</a>
                                                                </td>
                                                            </tr>

                                                            <tr class="">
                                                                <td class="nicdark_padding_20">  
                                                                    <img alt="" class="nicdark_section" src="img/courses/img2.png"> 
                                                                </td>
                                                                <td class="nicdark_padding_20">  
                                                                    <h4><strong>Maccheroni Dishes</strong></h4> 
                                                                </td>
                                                                <td class="nicdark_padding_20 nicdark_display_none_all_iphone">  
                                                                    
                                                                    <img alt="" class="" width="15" src="img/icons/icon-star-full.svg">
                                                                    <img alt="" class="" width="15" src="img/icons/icon-star-full.svg">
                                                                    <img alt="" class="" width="15" src="img/icons/icon-star-full.svg">
                                                                    <img alt="" class="" width="15" src="img/icons/icon-star-half.svg">
                                                                    <img alt="" class="nicdark_margin_right_10" width="15" src="img/icons/icon-star.svg">
                                                                    
                                                                </td>
                                                                <td class="nicdark_padding_20 nicdark_display_none_all_iphone">
                                                                    <p class="nicdark_color_greydark">$ 30,00</p>    
                                                                </td>
                                                                <td class="nicdark_padding_20">   
                                                                    <a class="nicdark_display_inline_block nicdark_color_white nicdark_bg_green nicdark_first_font nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="#">VIEW</a>
                                                                </td>
                                                            </tr>

                                                            <tr class="">
                                                                <td class="nicdark_padding_20">  
                                                                    <img alt="" class="nicdark_section" src="img/courses/img3.png"> 
                                                                </td>
                                                                <td class="nicdark_padding_20">  
                                                                    <h4><strong>Italian Pizza Napoli</strong></h4> 
                                                                </td>
                                                                <td class="nicdark_padding_20 nicdark_display_none_all_iphone">  
                                                                    
                                                                    <img alt="" class="" width="15" src="img/icons/icon-star-full.svg">
                                                                    <img alt="" class="" width="15" src="img/icons/icon-star-full.svg">
                                                                    <img alt="" class="" width="15" src="img/icons/icon-star-full.svg">
                                                                    <img alt="" class="" width="15" src="img/icons/icon-star-half.svg">
                                                                    <img alt="" class="nicdark_margin_right_10" width="15" src="img/icons/icon-star.svg">
                                                                    
                                                                </td>
                                                                <td class="nicdark_padding_20 nicdark_display_none_all_iphone">
                                                                    <p class="nicdark_color_greydark">$ 120,00</p>    
                                                                </td>
                                                                <td class="nicdark_padding_20">   
                                                                    <a class="nicdark_display_inline_block nicdark_color_white nicdark_bg_green nicdark_first_font nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="#">VIEW</a>
                                                                </td>
                                                            </tr>

                                                            <tr class="">
                                                                <td class="nicdark_padding_20">  
                                                                    <img alt="" class="nicdark_section" src="img/courses/img4.png"> 
                                                                </td>
                                                                <td class="nicdark_padding_20">  
                                                                    <h4><strong>Pasta Spaghetti Course</strong></h4> 
                                                                </td>
                                                                <td class="nicdark_padding_20 nicdark_display_none_all_iphone">  
                                                                    
                                                                    <img alt="" class="" width="15" src="img/icons/icon-star-full.svg">
                                                                    <img alt="" class="" width="15" src="img/icons/icon-star-full.svg">
                                                                    <img alt="" class="" width="15" src="img/icons/icon-star-full.svg">
                                                                    <img alt="" class="" width="15" src="img/icons/icon-star-half.svg">
                                                                    <img alt="" class="nicdark_margin_right_10" width="15" src="img/icons/icon-star.svg">
                                                                    
                                                                </td>
                                                                <td class="nicdark_padding_20 nicdark_display_none_all_iphone">
                                                                    <p class="nicdark_color_greydark">FREE</p>    
                                                                </td>
                                                                <td class="nicdark_padding_20">   
                                                                    <a class="nicdark_display_inline_block nicdark_color_white nicdark_bg_green nicdark_first_font nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="#">VIEW</a>
                                                                </td>
                                                            </tr>



                                                        </tbody>
                                                    </table>
                                                </div>
                                    

                                            </div>

                                            


                                            <div class="nicdark_section ui-tabs-panel ui-widget-content ui-corner-bottom" id="tabs-2" aria-labelledby="ui-id-2" role="tabpanel" aria-hidden="true" style="display: none;">


                                                    <div class="nicdark_section">
                                    
                                                        
                                                        <!--START attendes-->
                                                        <div class="nicdark_section">
                                                        
                                                            <!--START preview-->
                                                        <div class="nicdark_width_25_percentage nicdark_width_50_percentage_all_iphone nicdark_padding_20 nicdark_float_left nicdark_box_sizing_border_box">
                                                            <div class="nicdark_section nicdark_box_sizing_border_box">
                                        

                                                                <div class="nicdark_section nicdark_position_relative">
                                                                        
                                                                    <img alt="" class="nicdark_section" src="img/avatar/avatar-chef-2.png">

                                                                    <div class="nicdark_bg_greydark_alpha_gradient_3 nicdark_position_absolute nicdark_left_0 nicdark_height_100_percentage nicdark_width_100_percentage nicdark_box_sizing_border_box">
                                                                        
                                                                        <div class="nicdark_position_absolute nicdark_bottom_20 nicdark_width_100_percentage nicdark_padding_botttom_0 nicdark_padding_20 nicdark_box_sizing_border_box nicdark_text_align_center">
                                                                            <h5 class="nicdark_color_white"><strong>Jane Goleman</strong></h5>
                                                                        </div>

                                                                    </div>

                                                                </div>



                                                            </div>
                                                        </div>
                                                        <!--END preview-->

                                                        <!--START preview-->
                                                        <div class="nicdark_width_25_percentage nicdark_width_50_percentage_all_iphone nicdark_padding_20 nicdark_float_left nicdark_box_sizing_border_box">
                                                            <div class="nicdark_section nicdark_box_sizing_border_box">
                                        

                                                                <div class="nicdark_section nicdark_position_relative">
                                                                        
                                                                    <img alt="" class="nicdark_section" src="img/avatar/avatar-chef-3.png">

                                                                    <div class="nicdark_bg_greydark_alpha_gradient_3 nicdark_position_absolute nicdark_left_0 nicdark_height_100_percentage nicdark_width_100_percentage nicdark_box_sizing_border_box">
                                                                        
                                                                        <div class="nicdark_position_absolute nicdark_bottom_20 nicdark_width_100_percentage nicdark_padding_botttom_0 nicdark_padding_20 nicdark_box_sizing_border_box nicdark_text_align_center">
                                                                            <h5 class="nicdark_color_white"><strong>Jane Mgrayan</strong></h5>
                                                                        </div>

                                                                    </div>

                                                                </div>



                                                            </div>
                                                        </div>
                                                        <!--END preview-->


                                                        <!--START preview-->
                                                        <div class="nicdark_width_25_percentage nicdark_width_50_percentage_all_iphone nicdark_padding_20 nicdark_float_left nicdark_box_sizing_border_box">
                                                            <div class="nicdark_section nicdark_box_sizing_border_box">
                                        

                                                                <div class="nicdark_section nicdark_position_relative">
                                                                        
                                                                    <img alt="" class="nicdark_section" src="img/avatar/avatar-chef-4.png">

                                                                    <div class="nicdark_bg_greydark_alpha_gradient_3 nicdark_position_absolute nicdark_left_0 nicdark_height_100_percentage nicdark_width_100_percentage nicdark_box_sizing_border_box">
                                                                        
                                                                        <div class="nicdark_position_absolute nicdark_bottom_20 nicdark_width_100_percentage nicdark_padding_botttom_0 nicdark_padding_20 nicdark_box_sizing_border_box nicdark_text_align_center">
                                                                            <h5 class="nicdark_color_white"><strong>Jack Johnson</strong></h5>
                                                                        </div>

                                                                    </div>

                                                                </div>



                                                            </div>
                                                        </div>
                                                        <!--END preview-->


                                                        <!--START preview-->
                                                        <div class="nicdark_width_25_percentage nicdark_width_50_percentage_all_iphone nicdark_padding_20 nicdark_float_left nicdark_box_sizing_border_box">
                                                            <div class="nicdark_section nicdark_box_sizing_border_box">
                                        

                                                                <div class="nicdark_section nicdark_position_relative">
                                                                        
                                                                    <img alt="" class="nicdark_section" src="img/avatar/avatar-chef-5.png">

                                                                    <div class="nicdark_bg_greydark_alpha_gradient_3 nicdark_position_absolute nicdark_left_0 nicdark_height_100_percentage nicdark_width_100_percentage nicdark_box_sizing_border_box">
                                                                        
                                                                        <div class="nicdark_position_absolute nicdark_bottom_20 nicdark_width_100_percentage nicdark_padding_botttom_0 nicdark_padding_20 nicdark_box_sizing_border_box nicdark_text_align_center">
                                                                            <h5 class="nicdark_color_white"><strong>Nick Hopiness</strong></h5>
                                                                        </div>

                                                                    </div>

                                                                </div>



                                                            </div>
                                                        </div>
                                                        <!--END preview-->


                                                        <!--START preview-->
                                                        <div class="nicdark_width_25_percentage nicdark_width_50_percentage_all_iphone nicdark_padding_20 nicdark_float_left nicdark_box_sizing_border_box">
                                                            <div class="nicdark_section nicdark_box_sizing_border_box">
                                        

                                                                <div class="nicdark_section nicdark_position_relative">
                                                                        
                                                                    <img alt="" class="nicdark_section" src="img/avatar/avatar-chef-6.png">

                                                                    <div class="nicdark_bg_greydark_alpha_gradient_3 nicdark_position_absolute nicdark_left_0 nicdark_height_100_percentage nicdark_width_100_percentage nicdark_box_sizing_border_box">
                                                                        
                                                                        <div class="nicdark_position_absolute nicdark_bottom_20 nicdark_width_100_percentage nicdark_padding_botttom_0 nicdark_padding_20 nicdark_box_sizing_border_box nicdark_text_align_center">
                                                                            <h5 class="nicdark_color_white"><strong>Steve Morgan</strong></h5>
                                                                        </div>

                                                                    </div>

                                                                </div>



                                                            </div>
                                                        </div>
                                                        <!--END preview-->



                                                        </div>
                                                        <!--END attendes-->
                                                        



                                                    </div>



                                                


                                            </div>
                                            

                                            <div class="nicdark_section ui-tabs-panel ui-widget-content ui-corner-bottom" id="tabs-3" aria-labelledby="ui-id-3" role="tabpanel" aria-hidden="true" style="display: none;">

                                                <div class="nicdark_section">
                                
                                                    <div class="nicdark_section nicdark_height_20"></div>

                                                    <div class="nicdark_section">

                                                        <div class="nicdark_width_30_percentage nicdark_width_100_percentage_all_iphone nicdark_border_radius_3 nicdark_float_left nicdark_text_align_center nicdark_bg_greydark nicdark_padding_30 nicdark_box_sizing_border_box">

                                                            <h1 class="nicdark_font_size_70 nicdark_color_white"><strong>5</strong></h1>

                                                            <div class="nicdark_section nicdark_height_20"></div>

                                                            <div class="nicdark_section ">
                                                                <img alt="" class="" width="15" src="img/icons/icon-star-full-yellow.svg">
                                                                <img alt="" class="" width="15" src="img/icons/icon-star-full-yellow.svg">
                                                                <img alt="" class="" width="15" src="img/icons/icon-star-full-yellow.svg">
                                                                <img alt="" class="" width="15" src="img/icons/icon-star-full-yellow.svg">
                                                                <img alt="" class="nicdark_margin_right_10" width="15" src="img/icons/icon-star-full-yellow.svg">
                                                            </div>

                                                            <p>3 Ratings</p>

                                                        </div>


                                                        <div class="nicdark_width_70_percentage nicdark_width_100_percentage_all_iphone nicdark_padding_left_40 nicdark_padding_left_0_all_iphone nicdark_float_left nicdark_box_sizing_border_box">

                                                            <div class=" nicdark_border_radius_3 nicdark_section nicdark_border_1_solid_grey nicdark_padding_20 nicdark_box_sizing_border_box">
                                                                <table class="nicdark_section">
                                                                    <tr>
                                                                        <td class="nicdark_width_20_percentage "><h5><strong>5 Stars</strong></h5></td>
                                                                        <td class="nicdark_width_70_percentage "><div class="nicdark_section nicdark_bg_yellow nicdark_height_10 nicdark_border_radius_3"></div></td>
                                                                        <td class="nicdark_width_10_percentage nicdark_text_align_right"><p class="nicdark_font_size_14 nicdark_line_height_30">3</p></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="nicdark_width_20_percentage "><h5><strong>4 Stars</strong></h5></td>
                                                                        <td class="nicdark_width_70_percentage "><div class="nicdark_section nicdark_bg_grey_3 nicdark_height_10 nicdark_border_radius_3"></div></td>
                                                                        <td class="nicdark_width_10_percentage nicdark_text_align_right"><p class="nicdark_font_size_14 nicdark_line_height_30">0</p></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="nicdark_width_20_percentage "><h5><strong>3 Stars</strong></h5></td>
                                                                        <td class="nicdark_width_70_percentage "><div class="nicdark_section nicdark_bg_grey_3 nicdark_height_10 nicdark_border_radius_3"></div></td>
                                                                        <td class="nicdark_width_10_percentage nicdark_text_align_right"><p class="nicdark_font_size_14 nicdark_line_height_30">0</p></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="nicdark_width_20_percentage "><h5><strong>2 Stars</strong></h5></td>
                                                                        <td class="nicdark_width_70_percentage "><div class="nicdark_section nicdark_bg_grey_3 nicdark_height_10 nicdark_border_radius_3"></div></td>
                                                                        <td class="nicdark_width_10_percentage nicdark_text_align_right"><p class="nicdark_font_size_14 nicdark_line_height_30">0</p></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="nicdark_width_20_percentage "><h5><strong>1 Stars</strong></h5></td>
                                                                        <td class="nicdark_width_70_percentage "><div class="nicdark_section nicdark_bg_grey_3 nicdark_height_10 nicdark_border_radius_3"></div></td>
                                                                        <td class="nicdark_width_10_percentage nicdark_text_align_right"><p class="nicdark_font_size_14 nicdark_line_height_30">0</p></td>
                                                                    </tr>
                                                                </table>
                                                            </div>

                                                        </div>



                                                    </div>


                                                    <div class="nicdark_section nicdark_height_30"></div>
                                                    
                                                    
                                                    <!--START comment preview-->
                                                    <div class="nicdark_section nicdark_border_top_1_solid_grey nicdark_padding_40_20 nicdark_box_sizing_border_box">
                                                        <div class="nicdark_display_table nicdark_float_left">
                                                            <img alt="" class="nicdark_display_none_all_iphone nicdark_margin_right_10 nicdark_display_table_cell nicdark_vertical_align_middle nicdark_border_radius_100_percentage" width="40" src="img/avatar/avatar-chef-1.png">
                                                            <p class="  nicdark_display_table_cell nicdark_vertical_align_middle "><span class="nicdark_color_greydark nicdark_first_font nicdark_margin_right_20"><strong>John Doe</strong></span></p>
                                                            
                                                            <div class="nicdark_display_table_cell nicdark_vertical_align_middle ">
                                                                <img alt="" class="" width="15" src="img/icons/icon-star-full-yellow.svg">
                                                                <img alt="" class="" width="15" src="img/icons/icon-star-full-yellow.svg">
                                                                <img alt="" class="" width="15" src="img/icons/icon-star-full-yellow.svg">
                                                                <img alt="" class="" width="15" src="img/icons/icon-star-full-yellow.svg">
                                                                <img alt="" class="nicdark_margin_right_10" width="15" src="img/icons/icon-star-full-yellow.svg">
                                                            </div>

                                                        </div>

                                                        <div class="nicdark_section nicdark_height_20"></div>
                                                        <div class="nicdark_section">
                                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. In et ipsum sit amet ex pulvinar mattis. Pellentesque vitae purus viverra, aliquet lacus in, fringilla massa. Suspendisse ac est a nisi aliquet sollicitudin. Interdum et malesuada fames.</p>
                                                        </div>

                                                    </div>
                                                    <!--END comment preview-->

                                                    <!--START comment preview-->
                                                    <div class="nicdark_section nicdark_border_top_1_solid_grey nicdark_padding_40_20 nicdark_box_sizing_border_box">
                                                        <div class="nicdark_display_table nicdark_float_left">
                                                            <img alt="" class="nicdark_display_none_all_iphone nicdark_margin_right_10 nicdark_display_table_cell nicdark_vertical_align_middle nicdark_border_radius_100_percentage" width="40" src="img/avatar/avatar-chef-2.png">
                                                            <p class="  nicdark_display_table_cell nicdark_vertical_align_middle "><span class="nicdark_color_greydark nicdark_first_font nicdark_margin_right_20"><strong>Nick Hope</strong></span></p>
                                                        
                                                            <div class="nicdark_display_table_cell nicdark_vertical_align_middle ">
                                                                <img alt="" class="" width="15" src="img/icons/icon-star-full-yellow.svg">
                                                                <img alt="" class="" width="15" src="img/icons/icon-star-full-yellow.svg">
                                                                <img alt="" class="" width="15" src="img/icons/icon-star-full-yellow.svg">
                                                                <img alt="" class="" width="15" src="img/icons/icon-star-full-yellow.svg">
                                                                <img alt="" class="nicdark_margin_right_10" width="15" src="img/icons/icon-star-full-yellow.svg">
                                                            </div>

                                                        </div>

                                                        <div class="nicdark_section nicdark_height_20"></div>
                                                        <div class="nicdark_section">
                                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. In et ipsum sit amet ex pulvinar mattis. Pellentesque vitae purus viverra, aliquet lacus in, fringilla massa. Suspendisse ac est a nisi aliquet sollicitudin. Interdum et malesuada fames.</p>
                                                        </div>

                                                    </div>
                                                    <!--END comment preview-->

                                                    <!--START comment preview-->
                                                    <div class="nicdark_section nicdark_border_top_1_solid_grey nicdark_padding_40_20 nicdark_box_sizing_border_box">
                                                        <div class="nicdark_display_table nicdark_float_left">
                                                            <img alt="" class="nicdark_display_none_all_iphone nicdark_margin_right_10 nicdark_display_table_cell nicdark_vertical_align_middle nicdark_border_radius_100_percentage" width="40" src="img/avatar/avatar-chef-3.png">
                                                            <p class="  nicdark_display_table_cell nicdark_vertical_align_middle "><span class="nicdark_color_greydark nicdark_first_font nicdark_margin_right_20"><strong>Jane Dark</strong></span></p>
                                                        
                                                            <div class="nicdark_display_table_cell nicdark_vertical_align_middle ">
                                                                <img alt="" class="" width="15" src="img/icons/icon-star-full-yellow.svg">
                                                                <img alt="" class="" width="15" src="img/icons/icon-star-full-yellow.svg">
                                                                <img alt="" class="" width="15" src="img/icons/icon-star-full-yellow.svg">
                                                                <img alt="" class="" width="15" src="img/icons/icon-star-full-yellow.svg">
                                                                <img alt="" class="nicdark_margin_right_10" width="15" src="img/icons/icon-star-full-yellow.svg">
                                                            </div>

                                                        </div>

                                                        <div class="nicdark_section nicdark_height_20"></div>
                                                        <div class="nicdark_section">
                                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. In et ipsum sit amet ex pulvinar mattis. Pellentesque vitae purus viverra, aliquet lacus in, fringilla massa. Suspendisse ac est a nisi aliquet sollicitudin. Interdum et malesuada fames.</p>
                                                        </div>

                                                    </div>
                                                    <!--END comment preview-->



                                                </div>

                                            </div>

                                        </div>
                                        <!--END tab-->


                                        <!--START Dialog-->
                                        <!--<div class="nicdark_dialog" title="Basic dialog">
                                          <p>This is an animated dialog which is useful for displaying information. The dialog window can be moved, resized and closed with the 'x' icon.</p>
                                        </div>-->
     
                                        <!--<button class="nicdark_dialog_open">Open Dialog</button>-->
                                        <!--END Dialog-->


                                    </div>
                                </div>


                                <div class="nicdark_section nicdark_height_50"></div>


                            </div>














                            <div class="nicdark_width_33_percentage nicdark_width_100_percentage_responsive nicdark_float_left">


                                <div class="nicdark_section nicdark_padding_15 nicdark_box_sizing_border_box">




                                    <table class="nicdark_section">
                                        <tbody>
                                            <tr class="nicdark_border_bottom_2_solid_grey">
                                                <td class="nicdark_padding_20 "><img alt="" class="" width="40" src="img/icons/icon-email-grey.svg"></td>
                                                <td class="nicdark_padding_20 "><h4 class=" nicdark_text_align_right">Email: hallo@johndoe.com</h4></td>
                                            </tr>
                                            <tr class="nicdark_border_bottom_2_solid_grey">
                                                <td class="nicdark_padding_20"><img alt="" class="" width="40" src="img/icons/icon-mobile-grey.svg"></td>
                                                <td class="nicdark_padding_20"><h4 class=" nicdark_text_align_right">Phone: +00 80023457</h4></td>
                                            </tr>
                                            <tr class="nicdark_border_bottom_2_solid_grey">
                                                <td class="nicdark_padding_20 "><img alt="" class="" width="40" src="img/icons/icon-skype-grey.svg"></td>
                                                <td class="nicdark_padding_20 "><h4 class=" nicdark_text_align_right">Skype: @johndoe</h4></td>
                                            </tr>
                                            <tr class="nicdark_border_bottom_2_solid_grey">
                                                <td class="nicdark_padding_20 "><img alt="" class="" width="40" src="img/icons/icon-link-grey.svg"></td>
                                                <td class="nicdark_padding_20 "><h4 class=" nicdark_text_align_right">Web: www.johndoe.com</h4></td>
                                            </tr>
                                            <tr>
                                                <td class="nicdark_padding_20 "><img alt="" class="" width="40" src="img/icons/icon-pin-grey.svg"></td>
                                                <td class="nicdark_padding_20 "><h4 class=" nicdark_text_align_right">Location: Milan ( IT )</h4></td>
                                            </tr>
                                        </tbody>
                                    </table>


                                    <div class="nicdark_section nicdark_height_40"></div>


                                    <div class="nicdark_section nicdark_bg_white nicdark_border_1_solid_grey">

                                          <div class="nicdark_section nicdark_padding_20 nicdark_box_sizing_border_box nicdark_bg_grey nicdark_border_bottom_1_solid_grey nicdark_text_align_center">
                                            
                                            
                                            <h3 class=""><strong>Contact Me</strong></h3>
                                          </div>
                                          <div class="nicdark_section nicdark_padding_10 nicdark_box_sizing_border_box">
                                            
                                            <div class="nicdark_section">
                                                <div class="nicdark_width_100_percentage nicdark_padding_10 nicdark_box_sizing_border_box nicdark_float_left">
                                                    <input class="nicdark_padding_left_0 nicdark_background_none nicdark_border_top_width_0 nicdark_border_right_width_0 nicdark_border_left_width_0" type="text" placeholder="Name">
                                                </div>
                                                
                                            </div>
                                            <div class="nicdark_section">
                                                <div class="nicdark_width_100_percentage nicdark_padding_10 nicdark_box_sizing_border_box nicdark_float_left">
                                                    <input class="nicdark_padding_left_0 nicdark_background_none nicdark_border_top_width_0 nicdark_border_right_width_0 nicdark_border_left_width_0" type="text" placeholder="Email">
                                                </div>
                                                
                                            </div>
                                            <div class="nicdark_section">
                                                <div class="nicdark_width_100_percentage nicdark_padding_10 nicdark_box_sizing_border_box nicdark_float_left">
                                                    <textarea rows="4" class="nicdark_padding_left_0 nicdark_background_none nicdark_border_top_width_0 nicdark_border_right_width_0 nicdark_border_left_width_0" placeholder="Message"></textarea>
                                                </div>
                                            </div>
                                            <div class="nicdark_section">
                                                <div class="nicdark_width_100_percentage nicdark_padding_10 nicdark_box_sizing_border_box nicdark_float_left">
                                                    <a class="nicdark_display_inline_block nicdark_text_align_center nicdark_box_sizing_border_box nicdark_width_100_percentage nicdark_color_white nicdark_bg_green nicdark_first_font nicdark_padding_10_20 nicdark_border_radius_3 " href="#">SEND NOW</a>   
                                                </div>
                                            </div>

                                          </div>  

                                        </div>


                                </div>



                                <div class="nicdark_section nicdark_height_50"></div>


                            </div>
                    
                        

                        </div>
                        <!--end container-->

                    </div>




                <?php include "include/footer/footer-2.php"; ?>









                


            </div>
        </div>


        
        <?php include "include/footer/footer.php"; ?>