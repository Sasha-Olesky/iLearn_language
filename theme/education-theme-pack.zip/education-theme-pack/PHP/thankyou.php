<?php include "include/header/header.php"; ?>


                <?php include "include/header/navigation-2.php"; ?>


  
                <div class="nicdark_section nicdark_background_size_cover nicdark_background_position_center_bottom" style="background-image:url(img/parallax/img6.png);">

                    <div class="nicdark_section nicdark_bg_greydark_alpha_gradient_2">

                        


                        <!--start nicdark_container-->
                        <div class="nicdark_container nicdark_clearfix">


                            <div class="nicdark_section nicdark_height_200"></div>

                            <div class="grid grid_12">
                                <strong class="nicdark_color_white nicdark_font_size_60 nicdark_font_size_40_responsive nicdark_first_font">Thanks For Your Order</strong>
                            </div>

                            <div class="nicdark_section nicdark_height_20"></div>


                        </div>
                        <!--end container-->

                    </div>

                </div>




               
                <div class="nicdark_section nicdark_bg_grey nicdark_border_bottom_1_solid_grey">

                    <!--start nicdark_container-->
                    <div class="nicdark_container nicdark_clearfix">

                        <div class="grid grid_12">


                            
                            <a href="#">Home</a>
                            <img alt="" class="nicdark_margin_left_10 nicdark_margin_right_10" width="10" src="img/icons/icon-next-grey.svg">
                            <a href="#">Courses</a>
                            <img alt="" class="nicdark_margin_left_10 nicdark_margin_right_10" width="10" src="img/icons/icon-next-grey.svg">
                            <a href="#">Thank you Page</a>
                            


                        </div>

                
                    </div>
                    <!--end container-->

                </div>




                <div class="nicdark_section nicdark_height_50"></div>



                    
                <div class="nicdark_section ">

                    <!--start nicdark_container-->
                    <div class="nicdark_container nicdark_clearfix">

                        <div class="grid grid_6">

                            <div class="nicdark_section nicdark_box_sizing_border_box nicdark_overflow_hidden nicdark_overflow_x_auto nicdark_cursor_move_responsive">

                                <table class="nicdark_section">
                                    <thead>
                                        <tr class="nicdark_border_bottom_2_solid_grey">
                                            <td class="nicdark_padding_20 nicdark_width_25_percentage">
                                                <h6 class="nicdark_text_transform_uppercase">Product</h6>    
                                            </td>
                                            <td class="nicdark_padding_40 nicdark_width_30_percentage">   
                                            </td>
                                            <td class="nicdark_padding_20 nicdark_width_10_percentage">
                                                <h6 class="nicdark_text_transform_uppercase">Qnt</h6>    
                                            </td>
                                            <td class="nicdark_padding_20 nicdark_width_15_percentage">
                                                <h6 class="nicdark_text_transform_uppercase">Total</h6>    
                                            </td>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr class="nicdark_border_bottom_2_solid_grey">
                                            <td class="nicdark_padding_20">
                                                <img alt="" class="nicdark_section" src="img/courses/img1.png">   
                                            </td>
                                            <td class="nicdark_padding_20"> 
                                                <h3><strong>Learn Sushi</strong></h3>  
                                            </td>
                                            <td class="nicdark_padding_20">
                                                <h3>1</h3>  
                                            </td>
                                            <td class="nicdark_padding_20">
                                                <p class="">$ 50,00</p>    
                                            </td>
                                        </tr>

                                        <tr class="nicdark_border_bottom_2_solid_grey">
                                            <td class="nicdark_padding_20">
                                                <img alt="" class="nicdark_section" src="img/courses/img2.png">   
                                            </td>
                                            <td class="nicdark_padding_20"> 
                                                <h3><strong>Maccheroni</strong></h3>  
                                            </td>
                                            <td class="nicdark_padding_20">
                                                <h3>2</h3>  
                                            </td>
                                            <td class="nicdark_padding_20">
                                                <p class="">$ 20,00</p>    
                                            </td>
                                        </tr>

                                        <tr class="">
                                            <td class="nicdark_padding_20">
                                                <img alt="" class="nicdark_section" src="img/courses/img3.png">   
                                            </td>
                                            <td class="nicdark_padding_20"> 
                                                <h3><strong>Italian Pizza</strong></h3>  
                                            </td>
                                            <td class="nicdark_padding_20">
                                                <h3>3</h3>  
                                            </td>
                                            <td class="nicdark_padding_20">
                                                <p class="">$ 80,00</p>    
                                            </td>
                                        </tr>


                                    </tbody>
                                </table>

                            </div>


                        </div>

                        <div class="grid grid_6">

                            <div class="nicdark_section nicdark_bg_grey nicdark_border_1_solid_grey nicdark_padding_20 nicdark_box_sizing_border_box  nicdark_overflow_hidden nicdark_overflow_x_auto nicdark_cursor_move_responsive">


                                
                                <table class="nicdark_section">
                                    <thead>
                                        <tr class="">
                                            <td class="nicdark_padding_20_10 nicdark_width_50_percentage">
                                                <h6 class="nicdark_text_transform_uppercase">MY DETAILS</h6>    
                                            </td>
                                            <td class="nicdark_padding_20_10 nicdark_width_50_percentage">   
                                            </td>
                                        </tr>
                                    </thead>
                                    <tbody>


                            
                                        <tr class="nicdark_border_top_2_solid_grey nicdark_border_bottom_2_solid_grey">
                                            <td class="nicdark_padding_20_10">
                                                <p>User</p>   
                                            </td>
                                            <td class="nicdark_padding_20_10 ">  
                                                <p class="nicdark_color_greydark">@buyer</p> 
                                            </td>
                                        </tr>
                                        <tr class="nicdark_border_bottom_2_solid_grey">
                                            <td class="nicdark_padding_20_10">
                                                <p>Name</p>   
                                            </td>
                                            <td class="nicdark_padding_20_10 ">  
                                                <p class="nicdark_color_greydark">John</p> 
                                            </td>
                                        </tr>
                                        <tr class="nicdark_border_bottom_2_solid_grey">
                                            <td class="nicdark_padding_20_10">
                                                <p>Surname</p>   
                                            </td>
                                            <td class="nicdark_padding_20_10 ">  
                                                <p class="nicdark_color_greydark">Doe</p> 
                                            </td>
                                        </tr>
                                        <tr class="nicdark_border_bottom_2_solid_grey">
                                            <td class="nicdark_padding_20_10">
                                                <p>Email</p>   
                                            </td>
                                            <td class="nicdark_padding_20_10 ">  
                                                <p class="nicdark_color_greydark">johndoe@gmail.com</p> 
                                            </td>
                                        </tr>
                                        <tr class="nicdark_border_bottom_2_solid_grey">
                                            <td class="nicdark_padding_20_10">
                                                <p>Country</p>   
                                            </td>
                                            <td class="nicdark_padding_20_10 ">  
                                                <p class="nicdark_color_greydark">USA</p> 
                                            </td>
                                        </tr>
                                        <tr class="nicdark_border_bottom_2_solid_grey">
                                            <td class="nicdark_padding_20_10">
                                                <p>Address</p>   
                                            </td>
                                            <td class="nicdark_padding_20_10 ">  
                                                <p class="nicdark_color_greydark">Boulevard Street 12</p> 
                                            </td>
                                        </tr>
                                        <tr class="nicdark_border_bottom_2_solid_grey">
                                            <td class="nicdark_padding_20_10">
                                                <p>City</p>   
                                            </td>
                                            <td class="nicdark_padding_20_10 ">  
                                                <p class="nicdark_color_greydark">New York</p> 
                                            </td>
                                        </tr>
                                        <tr class="nicdark_border_bottom_2_solid_grey">
                                            <td class="nicdark_padding_20_10">
                                                <p>Payment Method</p>   
                                            </td>
                                            <td class="nicdark_padding_20_10 ">  
                                                <p class="nicdark_color_greydark">Paypal</p> 
                                            </td>
                                        </tr>
                                        <tr class="">
                                            <td class="nicdark_padding_20_10">
                                                <p>Transiction ID</p>   
                                            </td>
                                            <td class="nicdark_padding_20_10 ">  
                                                <p class="nicdark_color_greydark">dgsae23e32e387e3ee3</p> 
                                            </td>
                                        </tr>

                                    </tbody>
                                </table>




                                <div class="nicdark_section">
                                        <div class="nicdark_width_100_percentage nicdark_padding_10 nicdark_box_sizing_border_box nicdark_float_left">
                                            <a class="nicdark_display_inline_block nicdark_text_align_center nicdark_box_sizing_border_box nicdark_width_100_percentage nicdark_color_white nicdark_bg_orange nicdark_first_font nicdark_padding_10_20 nicdark_border_radius_3 " href="account.php">GO TO ACCOUNT PAGE</a>   
                                        </div>
                                    </div> 


                            </div>
                        
                        </div>

                    </div>
                    <!--end container-->

                </div>


                <div class="nicdark_section nicdark_height_50"></div>



                <?php include "include/footer/footer-2.php"; ?>









                


            </div>
        </div>


        
        <?php include "include/footer/footer.php"; ?>