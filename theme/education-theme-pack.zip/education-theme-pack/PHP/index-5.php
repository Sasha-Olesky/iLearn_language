<?php include "include/header/header.php"; ?>


        <?php include "include/header/navigation-2.php"; ?>


        <?php include "include/slider/slider-5.php"; ?>


        <div class="nicdark_section nicdark_height_50"></div>

        
        <?php include "include/sections/services-left-icon.php"; ?>
        

        <div class="nicdark_section nicdark_height_50"></div>


        <?php include "include/sections/focus-search-courses.php"; ?>


        <div class="nicdark_section nicdark_height_50"></div>


        <?php include "include/sections/courses-parallax.php"; ?>


        <div class="nicdark_section nicdark_height_150"></div>


        <?php include "include/sections/teachers-light.php"; ?>  


        <div class="nicdark_section nicdark_height_50"></div>


        <?php include "include/sections/counters.php"; ?>


        <div class="nicdark_section nicdark_height_50"></div>

        
        <?php include "include/sections/blog.php"; ?> 


        <div class="nicdark_section nicdark_height_50"></div>


        <?php include "include/sections/logos-light.php"; ?> 


        <?php include "include/footer/footer-2.php"; ?>


    </div>
</div>



<?php include "include/footer/footer.php"; ?>