<?php include "include/header/header.php"; ?>







                <?php include "include/header/navigation-2.php"; ?>






                       
                <div class="nicdark_section nicdark_background_size_cover nicdark_background_position_center_bottom" style="background-image:url(img/parallax/img2.png);">

                    <div class="nicdark_section nicdark_bg_greydark_alpha_gradient_2">

                        


                        <!--start nicdark_container-->
                        <div class="nicdark_container nicdark_clearfix">


                            <div class="nicdark_section nicdark_height_200"></div>

                            <div class="grid grid_12">
                                <strong class="nicdark_color_white nicdark_font_size_60 nicdark_first_font">Teachers</strong>
                            </div>

                            <div class="nicdark_section nicdark_height_20"></div>


                        </div>
                        <!--end container-->

                    </div>

                </div>




               
                <div class="nicdark_section nicdark_bg_grey nicdark_border_bottom_1_solid_grey">

                    <!--start nicdark_container-->
                    <div class="nicdark_container nicdark_clearfix">

                        <div class="grid grid_12">


                            
                            <a href="#">Home</a>
                            <img alt="" class="nicdark_margin_left_10 nicdark_margin_right_10" width="10" src="img/icons/icon-next-grey.svg">
                            <a href="#">Teachers</a>
                        

                        </div>

                
                    </div>
                    <!--end container-->

                </div>




                <div class="nicdark_section nicdark_height_50"></div>



                    
                <div class="nicdark_section ">

                    <!--start nicdark_container-->
                    <div class="nicdark_container nicdark_clearfix">


                        <div class="nicdark_width_100_percentage">


                            <!--START preview-->
                            <div class="grid grid_3">

                                <div class="nicdark_section">
                                    
                                    <!--start preview-->
                                    <div class="nicdark_section ">
                                        
                                        <!--image-->
                                        <div class="nicdark_section nicdark_position_relative">
                                            
                                            <img alt="" class="nicdark_section" src="img/avatar/avatar-chef-2.png">

                                            <div class="nicdark_bg_greydark_alpha_gradient nicdark_position_absolute nicdark_left_0 nicdark_height_100_percentage nicdark_width_100_percentage nicdark_padding_20 nicdark_box_sizing_border_box">
                                                
                                                <div class="nicdark_position_absolute nicdark_bottom_20">
                                                    <div class="nicdark_display_inline_block">
                                                        <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-twitter-white.svg">
                                                        <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-pinterest-white.svg">
                                                        <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-linkedin-white.svg">
                                                        <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-google-white.svg">
                                                        <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-instagram-white.svg">
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                        <!--image-->


                                        <div class="nicdark_section nicdark_padding_20 nicdark_box_sizing_border_box">
                                        
                                            <h2><strong>John Mcallister</strong></h2>
                                            <div class="nicdark_section nicdark_height_10"></div> 
                                            <h6 class="nicdark_text_transform_uppercase nicdark_color_grey">Food Teacher</h6>
                                            <div class="nicdark_section nicdark_height_20"></div> 
                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean egestas magna at porttitor vehicula.</p>
                                            <div class="nicdark_section nicdark_height_20"></div> 
                                            <a class="nicdark_display_inline_block nicdark_color_white nicdark_bg_green nicdark_first_font nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="#">VIEW PROFILE</a>

                                        </div>

                                    </div>
                                    <!--start preview-->

                                </div> 

                            </div>
                            <!--END preview-->


                            <!--START preview-->
                            <div class="grid grid_3">

                                <div class="nicdark_section">
                                    
                                    <!--start preview-->
                                    <div class="nicdark_section ">
                                        
                                        <!--image-->
                                        <div class="nicdark_section nicdark_position_relative">
                                            
                                            <img alt="" class="nicdark_section" src="img/avatar/avatar-chef-3.png">

                                            <div class="nicdark_bg_greydark_alpha_gradient nicdark_position_absolute nicdark_left_0 nicdark_height_100_percentage nicdark_width_100_percentage nicdark_padding_20 nicdark_box_sizing_border_box">
                                                
                                                <div class="nicdark_position_absolute nicdark_bottom_20">
                                                    <div class="nicdark_display_inline_block">
                                                        <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-twitter-white.svg">
                                                        <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-pinterest-white.svg">
                                                        <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-linkedin-white.svg">
                                                        <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-google-white.svg">
                                                        <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-instagram-white.svg">
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                        <!--image-->


                                        <div class="nicdark_section nicdark_padding_20 nicdark_box_sizing_border_box">
                                        
                                            <h2><strong>Jack Johnson</strong></h2>
                                            <div class="nicdark_section nicdark_height_10"></div> 
                                            <h6 class="nicdark_text_transform_uppercase nicdark_color_grey">Vegan Specialist</h6>
                                            <div class="nicdark_section nicdark_height_20"></div> 
                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean egestas magna at porttitor vehicula.</p>
                                            <div class="nicdark_section nicdark_height_20"></div> 
                                            <a class="nicdark_display_inline_block nicdark_color_white nicdark_bg_green nicdark_first_font nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="#">VIEW PROFILE</a>



                                        </div>

                                    </div>
                                    <!--start preview-->

                                </div> 

                            </div>
                            <!--END preview-->


                            <!--START preview-->
                            <div class="grid grid_3">

                                <div class="nicdark_section ">
                                    
                                    <!--start preview-->
                                    <div class="nicdark_section ">
                                        
                                        <!--image-->
                                        <div class="nicdark_section nicdark_position_relative">
                                            
                                            <img alt="" class="nicdark_section" src="img/avatar/avatar-chef-4.png">

                                            <div class="nicdark_bg_greydark_alpha_gradient nicdark_position_absolute nicdark_left_0 nicdark_height_100_percentage nicdark_width_100_percentage nicdark_padding_20 nicdark_box_sizing_border_box">
                                                
                                                <div class="nicdark_position_absolute nicdark_bottom_20">
                                                    <div class="nicdark_display_inline_block">
                                                        <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-twitter-white.svg">
                                                        <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-pinterest-white.svg">
                                                        <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-linkedin-white.svg">
                                                        <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-google-white.svg">
                                                        <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-instagram-white.svg">
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                        <!--image-->


                                        <div class="nicdark_section nicdark_padding_20 nicdark_box_sizing_border_box">
                                        
                                            <h2><strong>Andrew Rossi</strong></h2>
                                            <div class="nicdark_section nicdark_height_10"></div> 
                                            <h6 class="nicdark_text_transform_uppercase nicdark_color_grey">Italian Teacher</h6>
                                            <div class="nicdark_section nicdark_height_20"></div> 
                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean egestas magna at porttitor vehicula.</p>
                                            <div class="nicdark_section nicdark_height_20"></div> 
                                            <a class="nicdark_display_inline_block nicdark_color_white nicdark_bg_green nicdark_first_font nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="#">VIEW PROFILE</a>


                                        </div>

                                    </div>
                                    <!--start preview-->

                                </div> 

                            </div>
                            <!--END preview-->


                            <!--START preview-->
                            <div class="grid grid_3">

                                <div class="nicdark_section">
                                    
                                    <!--start preview-->
                                    <div class="nicdark_section ">
                                        
                                        <!--image-->
                                        <div class="nicdark_section nicdark_position_relative">
                                            
                                            <img alt="" class="nicdark_section" src="img/avatar/avatar-chef-5.png">

                                            <div class="nicdark_bg_greydark_alpha_gradient nicdark_position_absolute nicdark_left_0 nicdark_height_100_percentage nicdark_width_100_percentage nicdark_padding_20 nicdark_box_sizing_border_box">
                                                
                                                <div class="nicdark_position_absolute nicdark_bottom_20">
                                                    <div class="nicdark_display_inline_block">
                                                        <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-twitter-white.svg">
                                                        <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-pinterest-white.svg">
                                                        <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-linkedin-white.svg">
                                                        <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-google-white.svg">
                                                        <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-instagram-white.svg">
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                        <!--image-->


                                        <div class="nicdark_section nicdark_padding_20 nicdark_box_sizing_border_box">
                                        
                                            <h2><strong>Mark Spitch</strong></h2>
                                            <div class="nicdark_section nicdark_height_10"></div> 
                                            <h6 class="nicdark_text_transform_uppercase nicdark_color_grey">Chef Manager</h6>
                                            <div class="nicdark_section nicdark_height_20"></div> 
                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean egestas magna at porttitor vehicula.</p>
                                            <div class="nicdark_section nicdark_height_20"></div> 
                                            <a class="nicdark_display_inline_block nicdark_color_white nicdark_bg_green nicdark_first_font nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="#">VIEW PROFILE</a>


                                        </div>

                                    </div>
                                    <!--start preview-->

                                </div> 

                            </div>
                            <!--END preview-->




                            <!--START preview-->
                            <div class="grid grid_3">

                                <div class="nicdark_section">
                                    
                                    <!--start preview-->
                                    <div class="nicdark_section ">
                                        
                                        <!--image-->
                                        <div class="nicdark_section nicdark_position_relative">
                                            
                                            <img alt="" class="nicdark_section" src="img/avatar/avatar-chef-6.png">

                                            <div class="nicdark_bg_greydark_alpha_gradient nicdark_position_absolute nicdark_left_0 nicdark_height_100_percentage nicdark_width_100_percentage nicdark_padding_20 nicdark_box_sizing_border_box">
                                                
                                                <div class="nicdark_position_absolute nicdark_bottom_20">
                                                    <div class="nicdark_display_inline_block">
                                                        <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-twitter-white.svg">
                                                        <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-pinterest-white.svg">
                                                        <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-linkedin-white.svg">
                                                        <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-google-white.svg">
                                                        <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-instagram-white.svg">
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                        <!--image-->


                                        <div class="nicdark_section nicdark_padding_20 nicdark_box_sizing_border_box">
                                        
                                            <h2><strong>Mark Spitch</strong></h2>
                                            <div class="nicdark_section nicdark_height_10"></div> 
                                            <h6 class="nicdark_text_transform_uppercase nicdark_color_grey">Chef Manager</h6>
                                            <div class="nicdark_section nicdark_height_20"></div> 
                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean egestas magna at porttitor vehicula.</p>
                                            <div class="nicdark_section nicdark_height_20"></div> 
                                            <a class="nicdark_display_inline_block nicdark_color_white nicdark_bg_green nicdark_first_font nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="#">VIEW PROFILE</a>


                                        </div>

                                    </div>
                                    <!--start preview-->

                                </div> 

                            </div>
                            <!--END preview-->


                            <!--START preview-->
                            <div class="grid grid_3">

                                <div class="nicdark_section">
                                    
                                    <!--start preview-->
                                    <div class="nicdark_section ">
                                        
                                        <!--image-->
                                        <div class="nicdark_section nicdark_position_relative">
                                            
                                            <img alt="" class="nicdark_section" src="img/avatar/avatar-chef-7.png">

                                            <div class="nicdark_bg_greydark_alpha_gradient nicdark_position_absolute nicdark_left_0 nicdark_height_100_percentage nicdark_width_100_percentage nicdark_padding_20 nicdark_box_sizing_border_box">
                                                
                                                <div class="nicdark_position_absolute nicdark_bottom_20">
                                                    <div class="nicdark_display_inline_block">
                                                        <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-twitter-white.svg">
                                                        <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-pinterest-white.svg">
                                                        <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-linkedin-white.svg">
                                                        <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-google-white.svg">
                                                        <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-instagram-white.svg">
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                        <!--image-->


                                        <div class="nicdark_section nicdark_padding_20 nicdark_box_sizing_border_box">
                                        
                                            <h2><strong>Mark Spitch</strong></h2>
                                            <div class="nicdark_section nicdark_height_10"></div> 
                                            <h6 class="nicdark_text_transform_uppercase nicdark_color_grey">Chef Manager</h6>
                                            <div class="nicdark_section nicdark_height_20"></div> 
                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean egestas magna at porttitor vehicula.</p>
                                            <div class="nicdark_section nicdark_height_20"></div> 
                                            <a class="nicdark_display_inline_block nicdark_color_white nicdark_bg_green nicdark_first_font nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="#">VIEW PROFILE</a>


                                        </div>

                                    </div>
                                    <!--start preview-->

                                </div> 

                            </div>
                            <!--END preview-->


                            <!--START preview-->
                            <div class="grid grid_3">

                                <div class="nicdark_section">
                                    
                                    <!--start preview-->
                                    <div class="nicdark_section ">
                                        
                                        <!--image-->
                                        <div class="nicdark_section nicdark_position_relative">
                                            
                                            <img alt="" class="nicdark_section" src="img/avatar/avatar-chef-8.png">

                                            <div class="nicdark_bg_greydark_alpha_gradient nicdark_position_absolute nicdark_left_0 nicdark_height_100_percentage nicdark_width_100_percentage nicdark_padding_20 nicdark_box_sizing_border_box">
                                                
                                                <div class="nicdark_position_absolute nicdark_bottom_20">
                                                    <div class="nicdark_display_inline_block">
                                                        <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-twitter-white.svg">
                                                        <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-pinterest-white.svg">
                                                        <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-linkedin-white.svg">
                                                        <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-google-white.svg">
                                                        <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-instagram-white.svg">
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                        <!--image-->


                                        <div class="nicdark_section nicdark_padding_20 nicdark_box_sizing_border_box">
                                        
                                            <h2><strong>Mark Spitch</strong></h2>
                                            <div class="nicdark_section nicdark_height_10"></div> 
                                            <h6 class="nicdark_text_transform_uppercase nicdark_color_grey">Chef Manager</h6>
                                            <div class="nicdark_section nicdark_height_20"></div> 
                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean egestas magna at porttitor vehicula.</p>
                                            <div class="nicdark_section nicdark_height_20"></div> 
                                            <a class="nicdark_display_inline_block nicdark_color_white nicdark_bg_green nicdark_first_font nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="#">VIEW PROFILE</a>


                                        </div>

                                    </div>
                                    <!--start preview-->

                                </div> 

                            </div>
                            <!--END preview-->



                            <!--START preview-->
                            <div class="grid grid_3">

                                <div class="nicdark_section">
                                    
                                    <!--start preview-->
                                    <div class="nicdark_section ">
                                        
                                        <!--image-->
                                        <div class="nicdark_section nicdark_position_relative">
                                            
                                            <img alt="" class="nicdark_section" src="img/avatar/avatar-chef-9.png">

                                            <div class="nicdark_bg_greydark_alpha_gradient nicdark_position_absolute nicdark_left_0 nicdark_height_100_percentage nicdark_width_100_percentage nicdark_padding_20 nicdark_box_sizing_border_box">
                                                
                                                <div class="nicdark_position_absolute nicdark_bottom_20">
                                                    <div class="nicdark_display_inline_block">
                                                        <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-twitter-white.svg">
                                                        <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-pinterest-white.svg">
                                                        <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-linkedin-white.svg">
                                                        <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-google-white.svg">
                                                        <img alt="" width="15" class="nicdark_margin_right_10" src="img/icons/icon-instagram-white.svg">
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                        <!--image-->


                                        <div class="nicdark_section nicdark_padding_20 nicdark_box_sizing_border_box">
                                        
                                            <h2><strong>Mark Spitch</strong></h2>
                                            <div class="nicdark_section nicdark_height_10"></div> 
                                            <h6 class="nicdark_text_transform_uppercase nicdark_color_grey">Chef Manager</h6>
                                            <div class="nicdark_section nicdark_height_20"></div> 
                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean egestas magna at porttitor vehicula.</p>
                                            <div class="nicdark_section nicdark_height_20"></div> 
                                            <a class="nicdark_display_inline_block nicdark_color_white nicdark_bg_green nicdark_first_font nicdark_padding_8 nicdark_border_radius_3 nicdark_font_size_13" href="#">VIEW PROFILE</a>


                                        </div>

                                    </div>
                                    <!--start preview-->

                                </div> 

                            </div>
                            <!--END preview-->




                            


                            <div class="nicdark_section nicdark_height_30"></div>


                            <div class="nicdark_section nicdark_text_align_center">
                                <a class="nicdark_display_inline_block nicdark_color_greydark nicdark_first_font nicdark_padding_10 nicdark_font_size_20" href="#"><strong>1</strong></a>
                                <a class="nicdark_display_inline_block nicdark_first_font nicdark_padding_10 nicdark_font_size_20" href="#"><strong>2</strong></a>
                                <a class="nicdark_display_inline_block nicdark_first_font nicdark_padding_10 nicdark_font_size_20" href="#"><strong>3</strong></a>
                                <a class="nicdark_display_inline_block nicdark_first_font nicdark_padding_10 nicdark_font_size_20" href="#"><strong>4</strong></a>
                                <a class="nicdark_display_inline_block nicdark_first_font nicdark_padding_10 nicdark_font_size_20" href="#"><strong>5</strong></a>                                
                            </div>


                        </div>


                    </div>
                    <!--end container-->

                </div>


                <div class="nicdark_section nicdark_height_70"></div>



                <?php include "include/footer/footer-2.php"; ?>









                


            </div>
        </div>


        
        <?php include "include/footer/footer.php"; ?>