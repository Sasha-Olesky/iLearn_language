<?php include "include/header/header.php"; ?>







                <?php include "include/header/navigation-2.php"; ?>






                       
                <div class="nicdark_section nicdark_background_size_cover nicdark_background_position_center_bottom" style="background-image:url(img/parallax/img6.png);">

                    <div class="nicdark_section nicdark_bg_greydark_alpha_gradient_2">

                        


                        <!--start nicdark_container-->
                        <div class="nicdark_container nicdark_clearfix">


                            <div class="nicdark_section nicdark_height_200"></div>

                            <div class="grid grid_12">
                                <strong class="nicdark_color_white nicdark_font_size_60 nicdark_first_font">Cart</strong>
                                <div class="nicdark_section nicdark_height_20"></div>
                            </div>



                        </div>
                        <!--end container-->

                    </div>

                </div>




               
                <div class="nicdark_section nicdark_bg_grey nicdark_border_bottom_1_solid_grey">

                    <!--start nicdark_container-->
                    <div class="nicdark_container nicdark_clearfix">

                        <div class="grid grid_12">


                            
                            <a href="#">Home</a>
                            <img alt="" class="nicdark_margin_left_10 nicdark_margin_right_10" width="10" src="img/icons/icon-next-grey.svg">
                            <a href="#">Courses</a>
                            <img alt="" class="nicdark_margin_left_10 nicdark_margin_right_10" width="10" src="img/icons/icon-next-grey.svg">
                            <a href="#">Cart</a>
                            


                        </div>

                
                    </div>
                    <!--end container-->

                </div>




                <div class="nicdark_section nicdark_height_50"></div>



                    
                <div class="nicdark_section ">

                    <!--start nicdark_container-->
                    <div class="nicdark_container nicdark_clearfix">

                        <div class="grid grid_8">

                            <div class="nicdark_section nicdark_box_sizing_border_box nicdark_overflow_hidden nicdark_overflow_x_auto nicdark_cursor_move_responsive">

                                <table class="nicdark_section">
                                    <thead>
                                        <tr class="nicdark_border_bottom_2_solid_grey">
                                            <td class="nicdark_padding_20 nicdark_width_25_percentage">
                                                <h6 class="nicdark_text_transform_uppercase">Product</h6>    
                                            </td>
                                            <td class="nicdark_padding_20 nicdark_width_30_percentage">   
                                            </td>
                                            <td class="nicdark_padding_20 nicdark_width_15_percentage">  
                                            </td>
                                            <td class="nicdark_padding_20 nicdark_width_10_percentage">
                                                <h6 class="nicdark_text_transform_uppercase">Qnt</h6>    
                                            </td>
                                            <td class="nicdark_padding_20 nicdark_width_15_percentage">
                                                <h6 class="nicdark_text_transform_uppercase">Total</h6>    
                                            </td>
                                            <td class="nicdark_padding_20 nicdark_width_5_percentage">   
                                            </td>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr class="nicdark_border_bottom_2_solid_grey">
                                            <td class="nicdark_padding_20">
                                                <img alt="" class="nicdark_section" src="img/courses/img1.png">   
                                            </td>
                                            <td class="nicdark_padding_20"> 
                                                <h3><strong>Learn Sushi</strong></h3>  
                                            </td>
                                            <td class="nicdark_padding_20">  
                                                <p>$ 50,00</p> 
                                            </td>
                                            <td class="nicdark_padding_20">
                                                <input class="nicdark_color_greydark nicdark_first_font nicdark_text_align_center nicdark_font_size_20 nicdark_bg_white nicdark_border_bottom_2_solid_grey nicdark_border_0 nicdark_padding_right_0 nicdark_padding_left_0" type="number" min="0" max="10" step="1" value="1">  
                                            </td>
                                            <td class="nicdark_padding_20">
                                                <p class="nicdark_color_greydark">$ 50,00</p>    
                                            </td>
                                            <td class="nicdark_padding_20">   
                                                <img alt="" width="15" src="img/icons/icon-remove-red.svg">
                                            </td>
                                        </tr>

                                        <tr class="nicdark_border_bottom_2_solid_grey">
                                            <td class="nicdark_padding_20">
                                                <img alt="" class="nicdark_section" src="img/courses/img2.png">   
                                            </td>
                                            <td class="nicdark_padding_20"> 
                                                <h3><strong>Maccheroni</strong></h3>  
                                            </td>
                                            <td class="nicdark_padding_20">  
                                                <p>$ 20,00</p> 
                                            </td>
                                            <td class="nicdark_padding_20">
                                                <input class="nicdark_color_greydark nicdark_first_font nicdark_text_align_center nicdark_font_size_20 nicdark_bg_white nicdark_border_bottom_2_solid_grey nicdark_border_0 nicdark_padding_right_0 nicdark_padding_left_0" type="number" min="0" max="10" step="1" value="1">  
                                            </td>
                                            <td class="nicdark_padding_20">
                                                <p class="nicdark_color_greydark">$ 20,00</p>    
                                            </td>
                                            <td class="nicdark_padding_20">   
                                                <img alt="" width="15" src="img/icons/icon-remove-red.svg">
                                            </td>
                                        </tr>

                                        <tr class="">
                                            <td class="nicdark_padding_20">
                                                <img alt="" class="nicdark_section" src="img/courses/img3.png">   
                                            </td>
                                            <td class="nicdark_padding_20"> 
                                                <h3><strong>Italian Pizza</strong></h3>  
                                            </td>
                                            <td class="nicdark_padding_20">  
                                                <p>$ 80,00</p> 
                                            </td>
                                            <td class="nicdark_padding_20">
                                                <input class="nicdark_color_greydark nicdark_first_font nicdark_text_align_center nicdark_font_size_20 nicdark_bg_white nicdark_border_bottom_2_solid_grey nicdark_border_0 nicdark_padding_right_0 nicdark_padding_left_0" type="number" min="0" max="10" step="1" value="1">  
                                            </td>
                                            <td class="nicdark_padding_20">
                                                <p class="nicdark_color_greydark">$ 80,00</p>    
                                            </td>
                                            <td class="nicdark_padding_20">   
                                                <img alt="" width="15" src="img/icons/icon-remove-red.svg">
                                            </td>
                                        </tr>


                                    </tbody>
                                </table>

                            </div>


                            <div class="nicdark_section nicdark_height_50"></div>


                            <!--START coupon-->
                            <div class="nicdark_section nicdark_border_3_dashed_grey nicdark_padding_30 nicdark_box_sizing_border_box">
                                
                                <div class="nicdark_section">
                                    <div class="nicdark_width_15_percentage nicdark_box_sizing_border_box nicdark_float_left nicdark_padding_10">
                                        <div class="nicdark_section nicdark_height_5"></div>
                                    </div>
                                    <div class="nicdark_width_50_percentage nicdark_width_100_percentage_all_iphone nicdark_box_sizing_border_box nicdark_float_left nicdark_padding_10">
                                        <input class=" nicdark_border_width_2 nicdark_background_none nicdark_border_top_width_0 nicdark_border_right_width_0 nicdark_border_left_width_0" type="text" placeholder="Insert Coupon Code">
                                    </div>
                                    <div class="nicdark_width_20_percentage nicdark_width_100_percentage_all_iphone nicdark_box_sizing_border_box nicdark_float_left nicdark_padding_10">
                                        <a class="nicdark_display_inline_block nicdark_text_align_center nicdark_box_sizing_border_box nicdark_color_white nicdark_bg_green nicdark_first_font nicdark_padding_10_20 nicdark_border_radius_3 nicdark_width_100_percentage" href="#">APPLY</a>
                                    </div>
                                    <div class="nicdark_width_15_percentage nicdark_box_sizing_border_box nicdark_float_left nicdark_padding_10">
                                        <div class="nicdark_section nicdark_height_5"></div>
                                    </div>
                                </div>   

                            </div>
                            <!--END coupon-->


                        </div>

                        <div class="grid grid_4">

                            <div class="nicdark_section nicdark_bg_grey nicdark_border_1_solid_grey nicdark_padding_20 nicdark_box_sizing_border_box">


                                <table class="nicdark_section">
                                    <thead>
                                        <tr class="nicdark_border_bottom_2_solid_grey">
                                            <td class="nicdark_padding_20 nicdark_width_50_percentage">
                                                <h6 class="nicdark_text_transform_uppercase">TOTALS</h6>    
                                            </td>
                                            <td class="nicdark_padding_20 nicdark_width_50_percentage">   
                                            </td>
                                        </tr>
                                    </thead>
                                    <tbody>
                                       
                                       <tr class="">
                                            <td class="nicdark_padding_20">  
                                                <p>Subtotal</p> 
                                            </td>
                                            <td class="nicdark_padding_20">
                                                <p class="nicdark_color_greydark">$ 50,00</p>    
                                            </td>
                                        </tr>
                                        <tr class="nicdark_border_bottom_2_solid_grey">
                                            <td class="nicdark_padding_20">  
                                                <p>Method</p> 
                                            </td>
                                            <td class="nicdark_padding_20">
                                                <p class="nicdark_color_greydark">Paypal</p>    
                                            </td>
                                        </tr>
                                        <tr class="">
                                            <td class="nicdark_padding_20">  
                                                <p>Total</p> 
                                            </td>
                                            <td class="nicdark_padding_20">
                                                <h2><strong>$ 50,00</strong></h2>    
                                            </td>
                                        </tr>

                                    </tbody>
                                </table>  


                                <div class="nicdark_section">
                                    <div class="nicdark_width_100_percentage nicdark_padding_10 nicdark_box_sizing_border_box nicdark_float_left">
                                        <a class="nicdark_display_inline_block nicdark_text_align_center nicdark_box_sizing_border_box nicdark_width_100_percentage nicdark_color_white nicdark_bg_orange nicdark_first_font nicdark_padding_10_20 nicdark_border_radius_3 " href="#">UPDATE CART</a>   
                                    </div>

                                    <div class="nicdark_width_100_percentage nicdark_padding_10 nicdark_box_sizing_border_box nicdark_float_left">
                                        <a class="nicdark_display_inline_block nicdark_text_align_center nicdark_box_sizing_border_box nicdark_width_100_percentage nicdark_color_white nicdark_bg_green nicdark_first_font nicdark_padding_10_20 nicdark_border_radius_3 " href="checkout.php">GO TO CHECKOUT</a>   
                                    </div>
                                </div> 


                            </div>
                        
                        </div>

                    </div>
                    <!--end container-->

                </div>


                <div class="nicdark_section nicdark_height_50"></div>



                <?php include "include/footer/footer-2.php"; ?>









                


            </div>
        </div>


        
        <?php include "include/footer/footer.php"; ?>